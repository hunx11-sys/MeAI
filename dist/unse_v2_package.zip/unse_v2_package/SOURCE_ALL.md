---
date: 2026-10-29
tags: [오늘의운세, 소스코드, 웹탑재]
version: v2
---

# 오늘의 운세 v2 · 소스코드 전체

> 이 문서는 `build_package.py` 가 `web/` 폴더 파일을 그대로 묶어 자동으로 만든 것입니다. 직접 고치지 말고 원본(`source/src`)을 고친 뒤 다시 빌드하세요.
> 구조와 동작 설명은 `BLUEPRINT.md`, 탑재 방법은 `README.md` 를 보세요.

| 파일 | 줄 수 | 크기 | 역할 |
|---|---:|---:|---|
| `index.html` | 205 | 16,754 B | 화면 뼈대 (대문 · 사주 · 타로 3화면 + 카드 크게 보기 창) |
| `css/unse.css` | 424 | 43,857 B | 모든 디자인 · 애니메이션 · 인쇄(PDF) · 글꼴 선언 |
| `img/card-back.svg` | 24 | 5,469 B | 타로 카드 뒷면 |
| `img/hanji.svg` | 1 | 308 B | 사주 화면 한지 결 무늬 |
| `img/zoom.svg` | 1 | 213 B | 크게 보기 돋보기 |
| `js/app.js` | 667 | 53,672 B | 화면 이동 · 사주 화면 · 타로 연출 · 크게 보기 · 저장/공유 |
| `js/fortune-text.js` | 3 | 6,605 B | 사주 운세 문구 표 (v1 과 같음) |
| `js/ie-check.js` | 37 | 2,794 B | 익스플로러 → 엣지 안내 |
| `js/saju-engine.js` | 140 | 9,860 B | 사주 계산 엔진 (v1 과 같음) |
| `js/tarot-data.js` | 141 | 23,762 B | 타로 78장 데이터 (v1 과 같음) |
| `js/tarot-img.js` | 3 | 368 B | 카드 그림 주소 78개 |

그림 · 글꼴 파일 (원문 대신 크기와 SHA-256)

| 파일 | 크기 | SHA-256 |
|---|---:|---|
| `fonts/cinzel.woff2` | 15,152 B | `436163cef8ab01eeed39b31463a0154c2c4039517a5e837469944b26631749ea` |
| `fonts/hanja.woff2` | 5,700 B | `ae3999f37cfd91c6a5f1068da5291c1a49785878eb0e9d8edaefdbd192467463` |
| `fonts/serif-ko.woff2` | 166,200 B | `8f892f90f19cf423d4e265e7cb7349678339251ae4a8d7ac8f3473cc237ec02c` |
| `img/tarot/00.webp` | 36,588 B | `2307f1c285cc1eb67389afa292582cddea6e07e6a9a93d6091ce15dba04f47dd` |
| `img/tarot/01.webp` | 32,422 B | `082e26fc001b347373dcb35e64373e149a8d1b8a086dab1bb32bfbe4540c241b` |
| `img/tarot/02.webp` | 47,714 B | `e9318c4fc90241f3aa418c3deb8ddfd8a1d7d49cfaf6fb351fbf012063d0c0c8` |
| `img/tarot/03.webp` | 45,742 B | `8c89ec3e47dc8f66339a2645bac833b8dc12e88566888226a36fc5c35d9953c6` |
| `img/tarot/04.webp` | 39,588 B | `66d1d82026d76b628deba4e27663077fd84af9087c7d979329b9312200ea8bba` |
| `img/tarot/05.webp` | 38,214 B | `db4c820f01debdb8641b947a3e3a98c21b0f4e302a4a362a1d5d03c79a7a4747` |
| `img/tarot/06.webp` | 43,568 B | `9726156088dd630850b6cc5d790c6ca2e8a394f41117cd2476e4bf69baa6b2b5` |
| `img/tarot/07.webp` | 39,088 B | `aaab77aea133e9859d46a87c51b1a042ab09fbed57af78bf5dc1c90ba6b9feef` |
| `img/tarot/08.webp` | 24,980 B | `ed141be0e4980b63c5157cb7a44a88d8554498ebfb81b66fbfaaa072cbaba56f` |
| `img/tarot/09.webp` | 19,684 B | `7d6303130e902747b9a241a92ccaa0edc60fc6f6429b9314a5d56126e8979eca` |
| `img/tarot/10.webp` | 29,792 B | `49adc74182d6982d322cacb756b0eb23b548660a4c79a882e4203284c6e7fe66` |
| `img/tarot/11.webp` | 36,356 B | `da919ed958881478f3682b33bb19e80676de1250e42aa8bf411fedb56e3b6ddf` |
| `img/tarot/12.webp` | 21,300 B | `9ff5a8a59290f2b91f9b756776cc0f47829b09bd37d9fd0ce620ac578be90ee7` |
| `img/tarot/13.webp` | 43,436 B | `9ea73f19a6591fd7353ad07c56c7a518c2d6f64cc5ec2867f755413c3619615e` |
| `img/tarot/14.webp` | 39,346 B | `96a03da2a5806fd637714dce972edb056109f683bccd866ff4d0728c07ce6681` |
| `img/tarot/15.webp` | 32,776 B | `7435103be35f9d04dc9c040006f00e47ad4c332eb68641a7fe0576533f0176e1` |
| `img/tarot/16.webp` | 28,456 B | `f153f4ddec613932456ca5aaff3abd56259b3356f395db7423f49b5ea82b55e2` |
| `img/tarot/17.webp` | 33,938 B | `c23b4136238387bebb94ffd783138db5398c496cecd52b050f6ce438324c6d69` |
| `img/tarot/18.webp` | 32,776 B | `c1f96a61f2c9df2c318952fb8c22b5993875fb91c1d2b3d4e1f5b2579b83b02f` |
| `img/tarot/19.webp` | 50,338 B | `db7f33d210ac56f7b5ac8d9579c054b05a7b54c9c1537bd45ced7bd6584afd36` |
| `img/tarot/20.webp` | 44,454 B | `2632f38af8cfd34fdf6fb9287a5837538aaed831e8161cfcd42fa84d63310fcc` |
| `img/tarot/21.webp` | 39,524 B | `bd8f3867b32749912beaed103f16349dd70f9a932a59e93dffc52d47c7ec9486` |
| `img/tarot/22.webp` | 20,824 B | `752aefa386c33505b142a63dfb2449fb2ab687764f362423bb0f584718ebf48a` |
| `img/tarot/23.webp` | 29,894 B | `8b6c30eb849bd69b0be682d1e819fae30ce112af549add33aae3cb3916095f17` |
| `img/tarot/24.webp` | 27,426 B | `a58905dba27f4c97af8b9c40cadc55236ebb2f8fa6eb3f1679d0776e703de12f` |
| `img/tarot/25.webp` | 27,822 B | `148ba1c35c86687eba9d61aa6bc754ce796b828c6873ae8e545f3d81febaf92e` |
| `img/tarot/26.webp` | 28,954 B | `a223032e9acbc754a053d42fdbc2b3308fa901292b3a83e1937e510d0609a54b` |
| `img/tarot/27.webp` | 34,690 B | `7d2a4a6243b963c66b6446a75e1a3a46b1afec9bcbc0da729294094e1c89e3ee` |
| `img/tarot/28.webp` | 22,644 B | `ce549b772a80e34c4790a27ef61b5c88ebd186cfb759a63ddb9310109a69615b` |
| `img/tarot/29.webp` | 21,836 B | `1d7e8ee2f468dc5f0e0526e88be61a1711268d81f49a381f310e31196c67b223` |
| `img/tarot/30.webp` | 30,398 B | `1b15ce747dc71d81a10318f8a3dbe13d3fa3663f7285a1df7eb134ded9cc6524` |
| `img/tarot/31.webp` | 29,450 B | `93e53b989c56bb410c06c372af49e2428410d8ffcff03cb21c80d075c4571566` |
| `img/tarot/32.webp` | 25,164 B | `cda716cad4d8bbb20a4790dbdec5189f728ae46a888957f73da74f7c427a8dea` |
| `img/tarot/33.webp` | 31,888 B | `6103393b70cc48d7fb54aa4b49c490a85f6dc2c8123f4931b608c231279a8eca` |
| `img/tarot/34.webp` | 39,754 B | `8444f08a0583dbeccd622aad0559530cf274baf80ad079ae2f6e7e5912c76344` |
| `img/tarot/35.webp` | 37,102 B | `d005123261e0c66ae0290451ac028443ada393f6184b6587cc5a293d31d1eddf` |
| `img/tarot/36.webp` | 28,744 B | `a65b1b0b8fdd6b4498cac06e29baa1b47fc687c21a9d3b330dc235801f0c2f74` |
| `img/tarot/37.webp` | 28,620 B | `65915c3d3c1e1bb46fa0e994f0ee4635ab63bf9dfe37e6102219957d9a0216b3` |
| `img/tarot/38.webp` | 31,154 B | `e23c39a60672111c8f26d82d68eb35e66c39e03df40ccef11b8a280fb4b5ec0c` |
| `img/tarot/39.webp` | 24,044 B | `89b46636cc03e1843c7f2f614b7ca99c4b8e8a9c1e4dffb73b874c5b4852fd1b` |
| `img/tarot/40.webp` | 14,514 B | `ce6639dbe4b483da279ef8d5a9038111453f90b5a53c7dcc407a6fbd8f94496d` |
| `img/tarot/41.webp` | 45,330 B | `762e6096a30cf8d38d80ce8be74baf5d97f9f4742da99c250e1309bebd4523d1` |
| `img/tarot/42.webp` | 38,650 B | `a7ff051852c24a13e4d0860ef253655f321076fd83d3d67b94ccfe10fbb67cf2` |
| `img/tarot/43.webp` | 19,978 B | `0e1d21452c7ef59438c0029bb9d1b99615ebb9b782b3d4d924d7e07c706e9d9d` |
| `img/tarot/44.webp` | 35,262 B | `44d4d33f78540ffd0942b28a55e7ad769e61f19af26133d43aa0d0d2d4be0d7b` |
| `img/tarot/45.webp` | 32,330 B | `eec19a7c66321f9dd931476186f23b5732bd2d6b21ed99b48ebb5a0250575189` |
| `img/tarot/46.webp` | 21,466 B | `9e58e7a277fff3f780736d3b0d6dc3d2b0d03a337c5de51f9508d3dc33ef16f4` |
| `img/tarot/47.webp` | 30,710 B | `8e173954c3170e50183a41734f98c89fcc11396f0cf94241d519878576262e3c` |
| `img/tarot/48.webp` | 30,958 B | `df918755876de524015dedb7003004cf85022559b2df7bd7e740dc23aff5f980` |
| `img/tarot/49.webp` | 30,160 B | `e8f2ffc16ca06a3f8bf1e90594f22ae0dfc437be80724c41c9e9e43d97a560d8` |
| `img/tarot/50.webp` | 18,176 B | `12ef0d1dc4eed85550dc5a3cf05d5cc460593a25a540a3a87b3d427b2d17d16c` |
| `img/tarot/51.webp` | 20,476 B | `512a4e49fcb7322d27016735ac8b3384d5bea9b29ecfd6737c4a56d258c8cfd0` |
| `img/tarot/52.webp` | 20,432 B | `17e374e24bf9050a12d84e37c17ef69fe86d0ffdeaa516bbe57ecb7b7c48a247` |
| `img/tarot/53.webp` | 24,508 B | `6462183629b957f20fe07de4c9bdf25d784a4ca0c1022e0801794419872d43b4` |
| `img/tarot/54.webp` | 28,670 B | `1d0d375aec0066ef35861a3137cc3c67cb1ea4d7529545ffa5a2bd4ca8811e7f` |
| `img/tarot/55.webp` | 29,728 B | `fbc8accff3573189da12dfd2d619a30f762f6a64378f0f997f9a0763376055ff` |
| `img/tarot/56.webp` | 26,046 B | `54e2582846f5415231067fbca6a5e8ef973f7519a88ec4e7015f25ab87480936` |
| `img/tarot/57.webp` | 37,490 B | `c12354636046bf206075ff73208ee831f78d73426577f2c4aefd9d78d92c9155` |
| `img/tarot/58.webp` | 27,096 B | `95711a664abe96a05b887ee98a26e18c330fcbb11c9f2785b4f8e049fde8df63` |
| `img/tarot/59.webp` | 27,296 B | `54a445dc91d38dc3a938f49f9190527191c8c8ebe04f86c5020a5b37d254c721` |
| `img/tarot/60.webp` | 23,996 B | `948895dd15a46e9c76508f9f1ab81e9e7049bbcf9f06e511cf862c6355076dea` |
| `img/tarot/61.webp` | 30,144 B | `36874422468d47b4480529fcd7696403d9ddb6ee38471e6513adfebb0ef01f6e` |
| `img/tarot/62.webp` | 26,736 B | `8203da81c171eadaa713537bc9c57c22f6dccdc72c404941c7ae854d668ca929` |
| `img/tarot/63.webp` | 29,540 B | `24f2a89f03bbb27012e8eccc1635c1f039670ee36645e0c45b311b4156476eab` |
| `img/tarot/64.webp` | 22,142 B | `373e272355ffd641f2ba187193078bbf19911ff5a1844878f0b65a9e427305e2` |
| `img/tarot/65.webp` | 24,792 B | `020d22c113aaa63e918a9ad6038a6c0568aa186d1f61f8a8b7ece43cc5621648` |
| `img/tarot/66.webp` | 37,424 B | `bd751805c73e46f55b2d8b3ad8fa9e45dda03b45b23eb8201678b3baa10ab923` |
| `img/tarot/67.webp` | 16,608 B | `a910bf60c3cd632df31576310ae7bc143ed929a5e024a2acc44321b5ecd3d163` |
| `img/tarot/68.webp` | 51,398 B | `bc161355b447e7b93c2c7df68dca57f48c717113024848a454744c9328af87df` |
| `img/tarot/69.webp` | 29,266 B | `d967189957df3bbc4cb2db106b98985aa1f8e7a9b7c0e40c3c83f7f55b3f7c23` |
| `img/tarot/70.webp` | 26,300 B | `772e4e0891c3558edeb2f0f109eb987c2e8be1b3ac29e43049dbf66229f8c7d4` |
| `img/tarot/71.webp` | 24,092 B | `926fb90560c9e02e1381252042fbafc134453f26097c1f48007ff89b88f41da8` |
| `img/tarot/72.webp` | 34,932 B | `cb4787dabc17b5e91c5bcbb7e6e5d0a258c8ee7b2881626c3666c17d9a73e7f5` |
| `img/tarot/73.webp` | 45,138 B | `acee666dd75ab332d70d63941e05791ca0046e9046c5354b69c176c66a4cfc11` |
| `img/tarot/74.webp` | 18,994 B | `109c43117637d3dd29d134cdb1b9683bb32fce422c2fb9d1396b7158b2c9276a` |
| `img/tarot/75.webp` | 21,802 B | `f9fb45d37f9bc6024d81e29f0d895f83113bd92fc083efdf9a1828a1b83f718e` |
| `img/tarot/76.webp` | 41,198 B | `05c3ff3307f0c187234f72f7ce0afb353c151dd17373b2d3cb90fda871940d1e` |
| `img/tarot/77.webp` | 34,774 B | `3e7e70e259f4bbfa8aa59cbbd8f65e5e14b91b594768ecd64dc59025c180aea3` |

## index.html

````html
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="format-detection" content="telephone=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#0d0826" id="themeColor">
<title>오늘의 운세</title>
<script src="js/ie-check.js"></script>
<link rel="stylesheet" href="css/unse.css">
</head>
<body class="v-gate">
<div class="ie-box">
  <h2 class="ie-n">엣지에서 열어 주세요</h2>
  <h2 class="ie-l">크롬이나 엣지에서 열어 주세요</h2>
  <p class="ie-n">인터넷 익스플로러에서는 오늘의 운세가 동작하지 않아요.<br>잠시 뒤 엣지로 자동으로 넘어가요. 넘어가지 않으면 아래 버튼을 눌러 주세요.</p>
  <p class="ie-l">회사 설정 때문에 엣지에서도 옛 방식(IE 모드)으로 열렸어요.<br>아래 주소를 복사해 <b>크롬</b> 주소창에 붙여 넣어 주세요.<br>자주 쓰신다면 IT 담당자에게 이 주소를 <b>IE 모드 목록에서 빼 달라고</b> 요청하세요.</p>
  <a id="ie-go" class="ie-n" href="#">엣지로 열기</a>
  <input id="ie-url" type="text" readonly aria-label="이 페이지 주소">
  <button id="ie-copy" type="button">주소 복사 (크롬에 붙여 넣기)</button>
  <small>파일로 받으셨다면: 파일 오른쪽 클릭 → 연결 프로그램 → Microsoft Edge 또는 Chrome</small>
</div>

<noscript><div class="noscript"><b>이 화면은 미리보기에서 열려 있어 동작하지 않아요.</b><br>카카오톡에서 받으셨다면 오른쪽 위 메뉴(⋯ 또는 공유) → <b>Safari로 열기</b> 또는 <b>다른 앱으로 열기 → Safari</b>를 눌러 주세요.</div></noscript>

<!-- 그림 조각 모음 (여러 화면이 함께 씀) -->
<svg class="sprite" width="0" height="0" aria-hidden="true" focusable="false">
  <defs>
    <linearGradient id="pkG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2a86"/><stop offset="1" stop-color="#1a1048"/></linearGradient>
    <linearGradient id="pkB" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a1e6a"/><stop offset="1" stop-color="#140c3a"/></linearGradient>
    <radialGradient id="sunG" cx="40%" cy="38%" r="70%"><stop offset="0" stop-color="#ff7a52"/><stop offset=".7" stop-color="#d9442f"/><stop offset="1" stop-color="#a92a1e"/></radialGradient>
    <radialGradient id="moonG" cx="38%" cy="35%" r="70%"><stop offset="0" stop-color="#fffaf0"/><stop offset="1" stop-color="#e9dcb8"/></radialGradient>
    <symbol id="iwo" viewBox="0 0 360 132">
      <!-- 일월오봉: 왼쪽 달 · 오른쪽 해 · 다섯 봉우리 · 물결 -->
      <circle cx="58" cy="40" r="23" fill="none" stroke="#e8c77a" stroke-width=".6" opacity=".45"/>
      <circle cx="58" cy="40" r="15" fill="url(#moonG)"/>
      <circle cx="302" cy="40" r="23" fill="none" stroke="#e8c77a" stroke-width=".6" opacity=".55"/>
      <circle cx="302" cy="40" r="15" fill="url(#sunG)"/>
      <g stroke="#e8c77a" stroke-width=".8" stroke-linejoin="round">
        <path d="M-4 108 Q16 94 30 80 Q48 60 66 80 Q80 94 100 108Z" fill="url(#pkB)"/>
        <path d="M260 108 Q280 94 294 80 Q312 60 330 80 Q344 94 364 108Z" fill="url(#pkB)"/>
        <path d="M52 108 Q78 82 94 60 Q112 38 130 60 Q146 82 166 108Z" fill="url(#pkB)"/>
        <path d="M194 108 Q214 82 230 60 Q248 38 266 60 Q282 82 308 108Z" fill="url(#pkB)"/>
        <path d="M110 108 Q136 74 154 44 Q168 20 180 14 Q192 20 206 44 Q224 74 250 108Z" fill="url(#pkG)"/>
      </g>
      <g fill="none" stroke="#e8c77a" stroke-width=".55" opacity=".55" stroke-linecap="round">
        <path d="M180 22 Q174 46 170 70 M180 22 Q186 46 190 70 M164 58 Q160 76 156 92 M196 58 Q200 76 204 92"/>
        <path d="M112 48 Q106 66 102 84 M248 48 Q254 66 258 84 M48 72 Q44 84 40 96 M312 72 Q316 84 320 96"/>
      </g>
      <g stroke="#f6ecd0" stroke-width=".9" opacity=".5"><path d="M139 70V104 M221 70V104"/></g>
      <rect x="-4" y="106" width="368" height="30" fill="#120a32"/>
      <g fill="none" stroke="#e8c77a" stroke-width=".8" stroke-linecap="round" opacity=".85">
        <path d="M-4 114 q9 -7 18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0"/>
        <path d="M5 124 q9 -7 18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0 t18 0" opacity=".6"/>
      </g>
      <path d="M-4 106.5H364" stroke="#e8c77a" stroke-width=".8"/>
    </symbol>
    <symbol id="spark" viewBox="0 0 12 12"><path d="M6 0l1.4 4.6L12 6l-4.6 1.4L6 12l-1.4-4.6L0 6l4.6-1.4z" fill="currentColor"/></symbol>
  </defs>
</svg>

<!-- ============ 대문 ============ -->
<section class="view" id="gate" aria-labelledby="gateTitle">
  <div class="stars-bg"></div>
  <div class="g-in">
    <div class="emblem" aria-hidden="true">
      <svg viewBox="0 0 140 140">
        <defs><mask id="emM"><rect width="140" height="140" fill="#fff"/><circle cx="86" cy="58" r="33" fill="#000"/></mask>
          <radialGradient id="emGlow" r="50%"><stop offset="0" stop-color="#f6ecd0" stop-opacity=".35"/><stop offset="1" stop-color="#f6ecd0" stop-opacity="0"/></radialGradient></defs>
        <circle cx="70" cy="70" r="70" fill="url(#emGlow)"/>
        <circle cx="70" cy="70" r="64" fill="none" stroke="#e8c77a" stroke-width=".8" opacity=".55"/>
        <circle cx="70" cy="70" r="58" fill="none" stroke="#e8c77a" stroke-width="1" stroke-dasharray="1 5" stroke-linecap="round" opacity=".9"/>
        <g stroke="#e8c77a" stroke-width=".9" stroke-linecap="round" opacity=".7">
          <path d="M70 1v7M70 132v7M1 70h7M132 70h7M21 21l5 5M114 114l5 5M21 119l5-5M114 26l5-5"/>
        </g>
        <circle cx="70" cy="70" r="40" fill="url(#moonG)" mask="url(#emM)"/>
        <g fill="#f8e7b4"><use href="#spark" x="88" y="74" width="16" height="16"/><use href="#spark" x="104" y="52" width="9" height="9"/><use href="#spark" x="96" y="98" width="7" height="7"/></g>
      </svg>
    </div>
    <p class="kick">MeAI · TODAY'S FORTUNE</p>
    <h1 id="gateTitle">오늘의 운세</h1>
    <p class="g-sub">어떤 방법으로 오늘을 볼까요?</p>
    <div class="g-today" id="gToday">오늘</div>
    <div class="orn g-orn" aria-hidden="true"><svg><use href="#spark"/></svg></div>
    <div class="g-doors">
      <button type="button" class="door door-saju" data-go="saju">
        <span class="d-art" aria-hidden="true"><svg class="iwo" viewBox="0 0 360 132"><use href="#iwo"/></svg></span><span class="seal" aria-hidden="true"><i>四</i><i>柱</i><i>八</i><i>字</i></span>
        <span class="d-body">
          <span class="d-tt">사주팔자<small>SAJU</small></span>
          <span class="d-ds">생년월일로 타고난 기운과 오늘의 운세, 대운까지 봐요</span>
          <span class="d-go">사주 보러 가기 <span aria-hidden="true">→</span></span>
        </span>
      </button>
      <button type="button" class="door door-tarot" data-go="tarot">
        <span class="d-art" aria-hidden="true"><span class="d-fan" id="gFan"></span></span>
        <span class="d-body">
          <span class="d-tt">타로점<small>TAROT</small></span>
          <span class="d-ds">78장 카드 중 4장을 직접 골라 오늘의 메시지를 들어요</span>
          <span class="d-go">카드 뽑으러 가기 <span aria-hidden="true">→</span></span>
        </span>
      </button>
    </div>
    <p class="g-foot">제작자 : 세일즈혁신TF 이헌수<br>재미로 보는 운세예요 · 입력한 정보는 이 휴대폰 밖으로 나가지 않아요</p>
  </div>
</section>

<!-- ============ 사주 ============ -->
<section class="view" id="saju">
<div class="wrap">
  <button type="button" class="back" data-go="gate"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>처음으로</button>
  <header class="hero">
    <div class="stars-bg"></div>
    <div class="topline"><span class="kick">MeAI · SAJU</span><span class="maker">제작자 : 세일즈혁신TF 이헌수</span></div>
    <h1>오늘의 사주</h1>
    <p>이름과 생년월일을 넣으면 사주팔자와 오늘의 운세가 바로 나와요</p>
    <div class="today" id="today">오늘</div>
    <svg class="iwo" viewBox="0 0 360 132" aria-hidden="true"><use href="#iwo"/></svg>
  </header>

  <section class="card" id="form">
    <div class="field"><label for="nm">이름</label><input class="inp" id="nm" type="text" placeholder="예: 정재민" autocomplete="off" enterkeyhint="next" maxlength="20"></div>
    <div class="field"><span class="lbl" id="gLbl">성별</span><div class="seg" id="gender" role="group" aria-labelledby="gLbl"><button type="button" data-v="M" class="on" aria-pressed="true">남</button><button type="button" data-v="F" aria-pressed="false">여</button></div></div>
    <div class="field"><label for="bd">생년월일 <small>(양력 숫자 8자리 · 1936~2046년, 출산 예정일도 돼요)</small></label><div class="dwrap"><input class="inp" id="bd" type="text" inputmode="numeric" enterkeyhint="done" autocomplete="off" maxlength="10" placeholder="예: 19900928"><span class="dpick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg><input type="date" id="bdPick" min="1936-01-01" max="2046-12-31" tabindex="-1" aria-label="달력에서 고르기"></span></div></div>
    <p class="hint">생년월일 숫자 8자리를 넣으면 바로 결과가 나와요 (달력 아이콘으로 골라도 돼요) · 입력한 정보는 이 휴대폰 밖으로 나가지 않아요</p>
  </section>

  <section id="result" aria-live="polite">
    <div class="card">
      <div class="who" id="who"></div>
      <div class="sec"><h3>사주팔자 <span class="tg">년·월·일 여섯 글자</span></h3><div class="pls" id="pls"></div><div id="warn"></div></div>
      <div class="sec"><h3>오행 분포 <span class="tg">상생 순서</span></h3><div class="oh-wrap" id="ohs"></div><div class="me-desc" id="meDesc"></div></div>
    </div>
    <div class="card">
      <div class="sec first"><h3><span id="fTitle">오늘의 운세</span> <span class="tg" id="tgDay"></span></h3>
        <div id="fortuneBox">
          <div class="score"><div class="ring"><svg viewBox="0 0 108 108" aria-hidden="true"><defs><linearGradient id="gr" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f3d891"/><stop offset=".55" stop-color="#d0a24a"/><stop offset="1" stop-color="#4b2fb0"/></linearGradient></defs><circle class="bg" cx="54" cy="54" r="46"/><circle class="fg" id="ringFg" cx="54" cy="54" r="46"/></svg><div class="n"><b id="scoreN">0</b><span>점</span></div></div>
            <div><div class="stars" id="stars"></div><p class="head" id="head"></p><div class="keys" id="keys"></div></div></div>
          <ul class="lines" id="lines"></ul>
          <div class="meters" id="meters"></div>
          <div class="lucky" id="lucky"></div>
        </div>
        <div class="unborn" id="unborn"></div>
      </div>
      <div class="sec"><h3>대운 <span class="tg" id="tgDu"></span></h3><div class="du" id="du"></div></div>
    </div>
    <div class="card send no-print">
      <div class="sec first"><h3>저장 · 보내기</h3>
        <div class="phone"><input class="inp" id="ph" type="tel" inputmode="numeric" placeholder="받는 분 휴대폰 번호 (선택)" maxlength="13" autocomplete="off" aria-label="받는 분 휴대폰 번호"></div>
        <div class="btns">
          <button type="button" class="btn kakao" id="bKakao"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#191600" d="M12 3C6.5 3 2 6.6 2 11c0 2.8 1.9 5.3 4.7 6.7l-1 3.6c-.1.3.3.6.6.4l4.3-2.8c.5.1.9.1 1.4.1 5.5 0 10-3.6 10-8S17.5 3 12 3z"/></svg>카톡으로 보내기</button>
          <button type="button" class="btn pdf" id="bPdf"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 14h6M9 17h4"/></svg>PDF로 저장</button>
          <button type="button" class="btn sms" id="bSms">문자로 보내기</button>
          <button type="button" class="btn copy" id="bImg">이미지로 저장</button>
        </div>
        <p class="hint">카톡으로 보내기 → 공유 창에서 <b>카카오톡</b>을 고르고 받는 분을 선택하세요. 번호를 넣으면 문자로 바로 보낼 수 있어요.</p>
      </div>
    </div>
    <button type="button" class="cross no-print" data-go="tarot"><span class="ic" aria-hidden="true"><i class="cback"></i><i class="cback"></i><i class="cback"></i></span><span><b>타로점도 볼까요?</b><small>같은 생년월일로 카드 4장을 뽑아 봐요</small></span><span class="ar" aria-hidden="true">→</span></button>
    <p class="foot">재미로 보는 사주예요 · 결정의 근거로 쓰지 마세요<br>양력 생년월일 · 한국 표준시 기준 · 년주는 입춘, 월주는 절기 기준 · 시간 없이 정오 출생으로 계산</p>
  </section>
</div>
</section>

<!-- ============ 타로 ============ -->
<section class="view" id="tarot">
<div class="stars-bg"></div>
<div class="wrap">
  <button type="button" class="back" data-go="gate"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>처음으로</button>
  <header class="t-hero">
    <div class="emb" aria-hidden="true"><svg viewBox="0 0 60 60"><defs><mask id="emT"><rect width="60" height="60" fill="#fff"/><circle cx="37" cy="25" r="14" fill="#000"/></mask></defs><circle cx="30" cy="30" r="27" fill="none" stroke="#e8c77a" stroke-width=".8" opacity=".6"/><circle cx="30" cy="30" r="17" fill="url(#moonG)" mask="url(#emT)"/><g fill="#f8e7b4"><use href="#spark" x="36" y="32" width="9" height="9"/><use href="#spark" x="44" y="20" width="5" height="5"/></g></svg></div>
    <div class="kick">MeAI · TAROT</div>
    <h1>오늘의 타로</h1>
    <p>78장 카드 중 마음이 가는 4장을 골라 보세요</p>
  </header>
  <section class="t-form">
    <div class="row">
      <div><label for="tnm">이름</label><input class="inp" id="tnm" type="text" placeholder="예: 정재민" autocomplete="off" maxlength="20"></div>
      <div><label for="tbd">생년월일</label><div class="dwrap"><input class="inp" id="tbd" type="text" inputmode="numeric" enterkeyhint="done" autocomplete="off" maxlength="10" placeholder="19900928"><span class="dpick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg><input type="date" id="tbdPick" min="1936-01-01" max="2046-12-31" tabindex="-1" aria-label="달력에서 고르기"></span></div></div>
    </div>
    <div class="t-birth" id="tBirth"></div>
    <button type="button" class="t-go" id="tGo" disabled>생년월일을 넣어 주세요</button>
  </section>

  <div class="t-stage" id="stage" tabindex="0" role="group" aria-label="카드 펼치는 자리 · Enter 키로 카드를 섞거나 한 장씩 뽑아요"></div>
  <div class="t-reads" id="reads" aria-live="polite"></div>
  <section class="t-sum" id="tsum"></section>
  <button type="button" class="cross" data-go="saju"><span class="ic" aria-hidden="true"><span class="seal"><i>四</i><i>柱</i><i>八</i><i>字</i></span></span><span><b>사주팔자도 볼까요?</b><small>같은 생년월일로 타고난 기운을 봐요</small></span><span class="ar" aria-hidden="true">→</span></button>
  <p class="t-foot">재미로 보는 타로예요 · 카드는 뽑을 때마다 새로 섞여요<br>메이저 아르카나 22장 + 마이너 아르카나 56장 · 정방향·역방향 반반 확률<br>카드 그림 : 라이더-웨이트-스미스 타로(1909, 파멜라 콜먼 스미스 그림 · 공개 저작물)</p>
</div>
</section>

<!-- 카드 크게 보기 -->
<div class="cv" id="lb" role="dialog" aria-modal="true" aria-labelledby="lbNm">
  <div class="lb-in" id="lbIn"></div>
</div>
<div class="toast" id="toast" role="status"></div>

<script src="js/fortune-text.js"></script>
<script src="js/saju-engine.js"></script>
<script src="js/tarot-data.js"></script>
<script src="js/tarot-img.js"></script>
<script src="js/app.js"></script>
</body>
</html>
````

## css/unse.css

````css
/* 오늘의 운세 v2 · 2026-10-29 · 디자인 (빌드: fortune/build_unse.py --web) */
@font-face { font-family: "UnseSerif"; src: url("../fonts/serif-ko.woff2") format("woff2"); font-weight: 400 900; font-style: normal; font-display: swap; }
@font-face { font-family: "UnseHan"; src: url("../fonts/hanja.woff2") format("woff2"); font-weight: 400 900; font-style: normal; font-display: swap; }
@font-face { font-family: "UnseCinzel"; src: url("../fonts/cinzel.woff2") format("woff2"); font-weight: 400 900; font-style: normal; font-display: swap; }
/* =====================================================================
   오늘의 운세 v2 · 디자인 토큰
   밤하늘(대문 · 타로) + 한지(사주) 두 바탕, 강조는 금색 하나. 오행 다섯 색은 사주 글자에만.
   ===================================================================== */
:root {
  --night: #0d0826; --night2: #170f3d; --night3: #241a62; --lav: #d6cdf6; --lav2: #b0a6dd; --mist: #948bbd;
  --gold: #e8c77a; --gold-hi: #f8e7b4; --gold-lo: #b8913f; --gold-dk: #7d5f22; --moon: #f6ecd0;
  --paper: #f4efe4; --card: #fffdf8; --pline: #e7ddc8; --pline2: #d6c8aa;
  --ink: #1c1730; --sub: #4b4560; --mute: #6b6580; --pur: #4b2fb0; --pur2: #2a1c6e; --pur5: #efeafb; --seal: #b3302a;
  --e0: #2f9e62; --e0b: #e7f5ec; --e1: #e0402f; --e1b: #fcebe8; --e2: #b67d00; --e2b: #fbf1d6; --e3: #5f6873; --e3b: #eceef1; --e4: #2b4a8b; --e4b: #e7edf8;
  --serif: "UnseSerif", "UnseHan", "AppleMyungjo", "Noto Serif KR", "Nanum Myeongjo", "Batang", serif;
  --han: "UnseHan", "UnseSerif", "AppleMyungjo", "Noto Serif KR", "Batang", serif;
  --cinzel: "UnseCinzel", "Trajan Pro", Georgia, serif;
  --sans: "Pretendard Variable", "Pretendard", -apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo", "Malgun Gothic", "Noto Sans KR", sans-serif;
  --spring: cubic-bezier(.16, 1, .3, 1);
}
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
html { -webkit-text-size-adjust: 100%; }
body { margin: 0; background: var(--night); color: #efeaff; font-family: var(--sans); font-size: 15px; line-height: 1.55; word-break: keep-all; overflow-wrap: anywhere; }
body.v-saju { background: var(--paper); color: var(--ink); }
button, input, select { font: inherit; color: inherit; }
button { cursor: pointer; border: 0; background: none; padding: 0; }
:focus-visible { outline: 2px solid var(--gold); outline-offset: 2px; }
body.v-saju :focus-visible { outline-color: var(--pur); }
.wrap { max-width: 560px; margin: 0 auto; padding: calc(14px + env(safe-area-inset-top)) 16px calc(32px + env(safe-area-inset-bottom)); }
.sprite { position: absolute; width: 0; height: 0; overflow: hidden; }
.sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }

/* 화면 전환: 한 번에 한 화면만 */
.view { display: none; }
body.v-gate #gate, body.v-saju #saju, body.v-tarot #tarot { display: block; animation: viewIn .5s var(--spring) both; }
@keyframes viewIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
.back { display: inline-flex; align-items: center; gap: 4px; height: 44px; padding: 0 14px 0 10px; margin-bottom: 12px; border-radius: 999px; font-size: 14px; font-weight: 700; }
.back svg { width: 18px; height: 18px; }
#saju .back { color: var(--pur2); background: var(--card); box-shadow: 0 0 0 1px var(--pline), 0 2px 8px rgba(60, 40, 10, .06); }
#tarot .back { color: var(--lav); background: rgba(255, 255, 255, .07); box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .09); }

/* 공통 장식 */
.kick { font-family: var(--cinzel); font-size: 12px; font-weight: 700; letter-spacing: .24em; color: var(--gold); }
.orn { display: flex; align-items: center; justify-content: center; gap: 10px; color: var(--gold); }
.orn::before, .orn::after { content: ''; width: 64px; height: 1px; background: linear-gradient(90deg, transparent, currentColor); opacity: .8; }
.orn::after { transform: scaleX(-1); }
.orn svg { width: 12px; height: 12px; }
.stars-bg { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
.stars-bg::before, .stars-bg::after { content: ''; position: absolute; inset: 0; }
.stars-bg::before { opacity: .85;
  background-image: radial-gradient(1.4px 1.4px at 11% 14%, #fff, transparent), radial-gradient(1px 1px at 27% 7%, #fffc, transparent), radial-gradient(1.2px 1.2px at 43% 19%, #fff9, transparent), radial-gradient(1px 1px at 62% 9%, #fff, transparent), radial-gradient(1.5px 1.5px at 81% 21%, #fffc, transparent), radial-gradient(1px 1px at 93% 5%, #fff9, transparent), radial-gradient(1.1px 1.1px at 6% 41%, #fff8, transparent), radial-gradient(1px 1px at 91% 47%, #fff9, transparent), radial-gradient(1.2px 1.2px at 19% 66%, #fff6, transparent), radial-gradient(1px 1px at 74% 78%, #fff7, transparent), radial-gradient(1px 1px at 52% 90%, #fff5, transparent), radial-gradient(1px 1px at 35% 34%, #fff6, transparent); }
.stars-bg::after { animation: twinkle 4.5s ease-in-out infinite alternate;
  background-image: radial-gradient(1.6px 1.6px at 17% 26%, #f8e7b4, transparent), radial-gradient(1.3px 1.3px at 70% 13%, #fff, transparent), radial-gradient(1.8px 1.8px at 86% 36%, #f8e7b4, transparent), radial-gradient(1.2px 1.2px at 33% 52%, #fff, transparent), radial-gradient(1.4px 1.4px at 58% 30%, #fffd, transparent), radial-gradient(1.2px 1.2px at 8% 84%, #fff, transparent), radial-gradient(1.5px 1.5px at 95% 72%, #f8e7b4, transparent); }
@keyframes twinkle { from { opacity: .25; } to { opacity: 1; } }

/* ================= 타로 카드 한 장 (앞면) =================
   크기는 --w 하나로 정한다 (글자 · 테두리가 모두 --w 비율). 가로:세로 = 100:172 (실제 타로 70x120mm)
   크림색 테두리 + 금박 선 + 1909년 원판 그림 + 한글 이름판 */
.face { --w: 80px; position: relative; display: flex; flex-direction: column; width: var(--w); height: calc(var(--w) * 1.72); padding: calc(var(--w) * .06) calc(var(--w) * .06) 0; border-radius: calc(var(--w) * .055); overflow: hidden; color: #2a1f0e;
  background: linear-gradient(160deg, #fcf6e6 0%, #f3e7c9 60%, #ead9b2 100%); box-shadow: 0 0 0 1px rgba(125, 95, 34, .4), 0 calc(var(--w) * .05) calc(var(--w) * .16) rgba(0, 0, 0, .38); }
.face::before { content: ''; position: absolute; inset: calc(var(--w) * .028); border-radius: calc(var(--w) * .035); border: 1px solid rgba(184, 145, 63, .7); pointer-events: none; }
.face .art { flex: none; width: 100%; height: calc(var(--w) * .88 * 1.6923); background: #e9dcc0 center / cover no-repeat; box-shadow: 0 0 0 1px rgba(42, 31, 14, .6); }
.face .np { position: relative; flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 0; text-align: center; line-height: 1.08; }
.face .np b { font-family: var(--serif); font-weight: 700; font-size: calc(var(--w) * .125); letter-spacing: -.02em; white-space: nowrap; }
.face .np.l1 b { font-size: calc(var(--w) * .108); }
.face .np.l2 b { font-size: calc(var(--w) * .094); letter-spacing: -.04em; }
.face .np small { display: none; margin-top: calc(var(--w) * .012); font-family: var(--cinzel); font-size: calc(var(--w) * .046); font-weight: 700; letter-spacing: .1em; color: var(--gold-dk); white-space: nowrap; text-transform: uppercase; }
.face.big .np b { font-size: calc(var(--w) * .1); }
.face.big .np.l1 b { font-size: calc(var(--w) * .092); }
.face.big .np.l2 b { font-size: calc(var(--w) * .082); }
.face.big .np small { display: block; }
.face.rev { transform: rotate(180deg); }
.face.sheen::after { content: ''; position: absolute; inset: 0; pointer-events: none; background: linear-gradient(115deg, transparent 30%, rgba(255, 246, 214, .55) 45%, transparent 60%); background-size: 260% 100%; animation: sheen 1.3s ease .1s both; mix-blend-mode: screen; }
@keyframes sheen { from { background-position: 120% 0; } to { background-position: -40% 0; } }
.cback { background: url("../img/card-back.svg") center / 100% 100%; border-radius: 6%/3.5%; box-shadow: 0 0 0 1px rgba(0, 0, 0, .35), 0 6px 16px rgba(0, 0, 0, .4); }

/* ================= 대문 ================= */
#gate { min-height: 100vh; min-height: 100dvh; position: relative; overflow: hidden; background: radial-gradient(120% 62% at 50% -6%, #3b2590 0%, #1f1554 40%, var(--night) 80%); }
.g-in { position: relative; z-index: 1; max-width: 560px; margin: 0 auto; padding: calc(26px + env(safe-area-inset-top)) 20px calc(28px + env(safe-area-inset-bottom)); text-align: center; }
.emblem { width: 128px; height: 128px; margin: 0 auto 14px; animation: moonIn 1.3s var(--spring) both; }
.emblem svg { display: block; width: 100%; height: 100%; overflow: visible; }
@keyframes moonIn { from { opacity: 0; transform: rotate(-40deg) scale(.7); } to { opacity: 1; transform: none; } }
#gate h1 { margin: 8px 0 0; font-family: var(--serif); font-size: 38px; font-weight: 700; line-height: 1.2; letter-spacing: -.01em; color: #fff; }
@supports ((-webkit-background-clip: text) or (background-clip: text)) {
  #gate h1 { background: linear-gradient(180deg, #ffffff 35%, var(--gold-hi) 100%); -webkit-background-clip: text; background-clip: text; color: transparent; }
}
.g-sub { margin: 8px 0 0; font-size: 15px; color: var(--lav); }
.g-today { display: inline-flex; align-items: center; gap: 6px; margin-top: 16px; padding: 7px 15px; border-radius: 999px; background: rgba(255, 255, 255, .07); box-shadow: inset 0 0 0 1px rgba(232, 199, 122, .28); font-size: 13px; font-weight: 600; color: #f1ebff; }
.g-today b { font-family: var(--han); font-size: 15px; font-weight: 700; color: var(--gold); }
.g-orn { margin-top: 22px; }
.g-doors { display: grid; gap: 14px; margin-top: 18px; text-align: left; }
@media (min-width: 540px) { .g-doors { grid-template-columns: 1fr 1fr; } }
.door { position: relative; display: flex; flex-direction: column; width: 100%; min-height: 244px; padding: 0 0 18px; border-radius: 24px; overflow: hidden; color: #fff; text-align: left; isolation: isolate;
  transition: transform .35s var(--spring), box-shadow .35s; animation: doorIn .8s var(--spring) both; }
.door::after { content: ''; position: absolute; inset: 0; border-radius: inherit; pointer-events: none; box-shadow: inset 0 0 0 1px rgba(232, 199, 122, .4); }
.door:nth-child(1) { animation-delay: .2s; } .door:nth-child(2) { animation-delay: .34s; }
@keyframes doorIn { from { opacity: 0; transform: translateY(26px) scale(.97); } to { opacity: 1; transform: none; } }
@media (hover: hover) { .door:hover { transform: translateY(-4px); } }
.door:active { transform: scale(.98); }
.door-saju { background: linear-gradient(170deg, #3a2389 0%, #23145c 55%, #150b3a 100%); box-shadow: 0 18px 40px rgba(20, 8, 60, .55); }
.door-tarot { background: linear-gradient(170deg, #1d2a6e 0%, #16194b 55%, #0d0b2c 100%); box-shadow: 0 18px 40px rgba(6, 6, 30, .6); }
.d-art { position: relative; height: 134px; overflow: hidden; }
.d-art .iwo { position: absolute; left: 0; bottom: 0; width: 100%; height: auto; }
.seal { position: absolute; right: 18px; bottom: 20px; display: flex; flex-direction: column; flex-wrap: wrap-reverse; align-content: center; justify-content: center; gap: 0 1px; width: 46px; height: 46px; padding: 3px; border-radius: 6px; background: var(--seal); color: #fff1e4;
  font-family: var(--han); font-size: 15px; font-weight: 700; line-height: 1; transform: rotate(4deg); box-shadow: inset 0 0 0 2px rgba(255, 241, 228, .55), 0 6px 14px rgba(0, 0, 0, .3); }
.seal i { font-style: normal; display: block; width: 18px; height: 19px; text-align: center; line-height: 19px; }
.d-fan { position: absolute; left: 50%; top: 18px; width: 0; height: 0; }
.d-fan .face { position: absolute; left: -33px; top: 0; --w: 66px; transform-origin: 50% 150%; transition: transform .45s var(--spring); }
.d-fan .face:nth-child(1) { transform: rotate(-17deg); } .d-fan .face:nth-child(3) { transform: rotate(17deg); }
.d-fan .face:nth-child(2) { z-index: 1; transform: translateY(-4px); }
@media (hover: hover) { .door:hover .d-fan .face:nth-child(1) { transform: rotate(-25deg); } .door:hover .d-fan .face:nth-child(3) { transform: rotate(25deg); } .door:hover .d-fan .face:nth-child(2) { transform: translateY(-10px); } }
.door-tarot .d-art { -webkit-mask-image: linear-gradient(#000 62%, transparent); mask-image: linear-gradient(#000 62%, transparent); }
.d-body { position: relative; z-index: 3; display: block; padding: 4px 18px 0; }
.d-tt { display: flex; align-items: baseline; gap: 8px; font-family: var(--serif); font-size: 23px; font-weight: 700; }
.d-tt small { font-family: var(--cinzel); font-size: 12px; font-weight: 700; letter-spacing: .18em; color: var(--gold); }
.d-ds { display: block; margin-top: 4px; font-size: 14px; line-height: 1.55; color: rgba(255, 255, 255, .8); }
.d-go { display: inline-flex; align-items: center; gap: 6px; margin-top: 14px; height: 40px; padding: 0 16px; border-radius: 999px; font-size: 14px; font-weight: 700; color: #2a1d00; background: linear-gradient(180deg, #f6dc98, #d6aa4f); box-shadow: 0 6px 16px rgba(214, 170, 79, .25); }
.door-saju .d-go { color: var(--pur2); background: linear-gradient(180deg, #fffaf0, #efe3c6); box-shadow: 0 6px 16px rgba(0, 0, 0, .2); }
.door.chosen { transform: scale(1.03); box-shadow: 0 0 0 2px rgba(248, 231, 180, .7), 0 24px 50px rgba(0, 0, 0, .45); }
#gate.leaving .door:not(.chosen) { opacity: 0; transform: scale(.95); transition: all .3s; }
.g-foot { margin-top: 26px; font-size: 12px; line-height: 1.7; color: rgba(214, 205, 246, .62); }

/* ================= 사주 (한지 바탕) ================= */
#saju { min-height: 100vh; min-height: 100dvh; background-color: var(--paper);
  background-image: url("../img/hanji.svg"); }
.hero { position: relative; overflow: hidden; border-radius: 24px; padding: 22px 20px 0; color: #fff; background: radial-gradient(120% 90% at 50% 0%, #3d2793 0%, #22165c 52%, #120a35 100%); box-shadow: 0 16px 36px rgba(30, 18, 80, .28); }
.hero .stars-bg::after { animation: none; }
.hero .topline { position: relative; z-index: 1; display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap; }
.hero .maker { font-size: 12px; font-weight: 600; color: #e7dfff; background: rgba(255, 255, 255, .12); padding: 3px 10px; border-radius: 999px; white-space: nowrap; }
.hero h1 { position: relative; margin: 6px 0 0; font-family: var(--serif); font-size: 30px; font-weight: 700; letter-spacing: -.01em; }
.hero p { position: relative; margin: 6px 0 0; font-size: 14px; color: #e4dcff; }
.hero .today { position: relative; display: inline-flex; align-items: center; gap: 6px; margin-top: 12px; padding: 6px 12px; border-radius: 999px; background: rgba(255, 255, 255, .1); box-shadow: inset 0 0 0 1px rgba(232, 199, 122, .25); font-size: 13px; font-weight: 600; }
.hero .today b { font-family: var(--han); font-size: 15px; color: var(--gold); }
.hero .iwo { position: relative; display: block; width: calc(100% + 40px); height: auto; margin: 10px -20px 0; }

.card { margin-top: 14px; padding: 20px 18px; border-radius: 20px; background: var(--card); box-shadow: 0 0 0 1px var(--pline), 0 8px 24px rgba(90, 64, 20, .05); }
.field { margin-top: 16px; } .field:first-child { margin-top: 0; }
.field > label, .field > .lbl { display: block; margin-bottom: 7px; font-size: 13px; font-weight: 700; color: var(--sub); }
.field small { font-weight: 500; color: var(--mute); }
.inp { display: block; width: 100%; height: 50px; padding: 0 14px; border-radius: 14px; border: 1.5px solid var(--pline); background: #fff; font-size: 17px; font-weight: 600; outline: 0; -webkit-appearance: none; appearance: none; transition: border-color .2s, box-shadow .2s; }
.inp::placeholder { color: #7a7466; font-weight: 500; }
.inp:focus { border-color: var(--pur); box-shadow: 0 0 0 4px rgba(75, 47, 176, .12); }
/* 생년월일: 칸을 누르면 숫자 키패드, 오른쪽 달력 아이콘을 누르면 달력 (투명한 날짜 칸을 아이콘 위에 겹침) */
.dwrap { position: relative; }
.dwrap .inp { padding-right: 56px; letter-spacing: .02em; }
.dpick { position: absolute; right: 6px; top: 50%; width: 44px; height: 40px; margin-top: -20px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: var(--pur); background: var(--pur5); overflow: hidden; }
.dpick svg { width: 20px; height: 20px; pointer-events: none; }
.dpick input { position: absolute; inset: 0; width: 100%; height: 100%; margin: 0; padding: 0; border: 0; opacity: 0; cursor: pointer; font-size: 16px; -webkit-appearance: none; appearance: none; }
.dpick input::-webkit-calendar-picker-indicator { position: absolute; inset: 0; width: 100%; height: 100%; margin: 0; cursor: pointer; }
.seg { display: flex; gap: 4px; padding: 4px; border-radius: 14px; background: #f1ebdc; }
.seg button { flex: 1; height: 44px; border-radius: 11px; font-size: 16px; font-weight: 700; color: var(--mute); transition: background .2s, color .2s; }
.seg button.on { background: #fff; color: var(--pur2); box-shadow: 0 2px 6px rgba(60, 40, 10, .12); }
.hint { margin: 9px 2px 0; font-size: 12.5px; color: var(--mute); }

#result { display: none; }
#result.on { display: block; animation: up .55s var(--spring) both; }
@keyframes up { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: none; } }
.who { display: flex; align-items: center; gap: 16px; }
.who .tti { position: relative; flex-shrink: 0; width: 66px; height: 66px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 36px; line-height: 1;
  background: radial-gradient(circle at 35% 30%, #fffaf0, #f2e0b4); box-shadow: 0 0 0 2px var(--gold), 0 0 0 5px #fff8e8, 0 0 0 6px var(--pline2); }
.who .tti i { position: absolute; right: -7px; bottom: -5px; width: 26px; height: 26px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: var(--pur2); color: var(--gold-hi); font-family: var(--han); font-style: normal; font-size: 13px; font-weight: 700; box-shadow: 0 0 0 2px var(--card); }
.who .nm { font-family: var(--serif); font-size: 21px; font-weight: 700; line-height: 1.3; }
.who .nm small { margin-left: 6px; font-family: var(--sans); font-size: 13px; font-weight: 600; color: var(--mute); }
.who .nm small.due { color: #b25e00; font-weight: 700; }
.who .bd { margin-top: 2px; font-size: 14.5px; font-weight: 600; }
.who .bd em { font-style: normal; color: #a85200; font-weight: 700; }
.who .gz { margin-top: 1px; font-family: var(--han); font-size: 14px; color: var(--sub); letter-spacing: .02em; }

.sec { margin-top: 22px; }
.sec.first { margin-top: 0; }
.sec h3 { display: flex; align-items: center; gap: 8px; margin: 0 0 12px; font-family: var(--serif); font-size: 17px; font-weight: 700; }
.sec h3::before { content: ''; width: 7px; height: 7px; transform: rotate(45deg); background: var(--gold-lo); flex: none; }
.sec h3 .tg { font-family: var(--sans); font-size: 12px; font-weight: 700; color: var(--pur); background: var(--pur5); padding: 2px 9px; border-radius: 999px; }
.pls { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.pl { position: relative; border-radius: 16px; background: linear-gradient(180deg, #fffcf4, #faf2e1); box-shadow: 0 0 0 1px var(--pline); padding: 11px 4px 12px; text-align: center; }
.pl.me { background: linear-gradient(180deg, #fff8e4, #f8ead0); box-shadow: 0 0 0 1.5px var(--gold-lo), 0 8px 18px rgba(184, 145, 63, .2); }
.pl .lb { display: block; font-size: 12px; font-weight: 700; color: var(--mute); letter-spacing: .02em; }
.pl .god { display: block; height: 18px; font-size: 12px; font-weight: 700; color: var(--pur); }
.pl.me .god { color: var(--gold-dk); }
.pl .c { display: flex; align-items: center; justify-content: center; width: 100%; max-width: 62px; aspect-ratio: 1; margin: 6px auto 0; border-radius: 14px; font-family: var(--han); font-size: 33px; font-weight: 700; box-shadow: inset 0 0 0 1px rgba(0, 0, 0, .05); }
.pl .k { display: block; margin-top: 7px; font-size: 13px; font-weight: 700; color: var(--sub); }
.pl .el { display: block; margin-top: 1px; font-family: var(--han); font-size: 12px; color: var(--mute); letter-spacing: .12em; }
.e0 { color: var(--e0); background: var(--e0b); } .e1 { color: var(--e1); background: var(--e1b); } .e2 { color: var(--e2); background: var(--e2b); }
.e3 { color: var(--e3); background: var(--e3b); } .e4 { color: var(--e4); background: var(--e4b); }
.oh-wrap { display: flex; flex-direction: column; align-items: center; }
.ohg { display: block; width: 100%; max-width: 330px; height: auto; overflow: visible; }
.ohg text { font-family: var(--han); }
.ohg text.lbl { font-family: var(--sans); }
.oh-leg { display: flex; flex-wrap: wrap; justify-content: center; gap: 6px; margin-top: 4px; }
.oh-leg span { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 999px; font-size: 12.5px; font-weight: 700; }
.oh-leg span.zero { opacity: .5; }
.me-desc { margin-top: 12px; padding: 13px 15px; border-radius: 14px; background: linear-gradient(135deg, #f3eefc, #f8f2e6); font-size: 14px; line-height: 1.65; color: var(--pur2); }
.me-desc b { font-weight: 700; }
.me-desc .h { font-family: var(--han); font-size: 15.5px; }

.score { display: flex; align-items: center; gap: 16px; }
.ring { position: relative; width: 108px; height: 108px; flex-shrink: 0; }
.ring svg { width: 108px; height: 108px; transform: rotate(-90deg); }
.ring .bg { fill: none; stroke: #f0e7d3; stroke-width: 9; }
.ring .fg { fill: none; stroke: url(#gr); stroke-width: 9; stroke-linecap: round; transition: stroke-dashoffset 1.1s cubic-bezier(.3, 1, .4, 1); }
.ring .n { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; flex-direction: column; }
.ring .n b { font-family: var(--serif); font-size: 34px; font-weight: 700; color: var(--pur2); line-height: 1; }
.ring .n span { margin-top: 2px; font-size: 12px; font-weight: 700; color: var(--mute); }
.stars { font-size: 18px; letter-spacing: 1px; color: #e6dfcf; }
.stars i { font-style: normal; } .stars i.on { color: #e0a51f; }
.head { margin: 4px 0 0; font-family: var(--serif); font-size: 17.5px; font-weight: 700; line-height: 1.5; }
.keys { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 9px; }
.keys span { font-size: 12px; font-weight: 700; color: var(--pur); background: var(--pur5); padding: 3px 10px; border-radius: 999px; }
.keys .god { color: var(--gold-hi); background: var(--pur2); }
.lines { list-style: none; margin: 16px 0 0; padding: 0; }
.lines li { position: relative; padding: 0 0 9px 18px; font-size: 14px; line-height: 1.6; color: var(--sub); }
.lines li::before { content: ''; position: absolute; left: 3px; top: 8px; width: 6px; height: 6px; transform: rotate(45deg); background: var(--gold-lo); }
.meters { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 18px; margin-top: 8px; }
.m { display: grid; grid-template-columns: 50px 1fr 26px; align-items: center; gap: 8px; font-size: 13.5px; font-weight: 700; color: var(--sub); }
.m .tr { height: 8px; border-radius: 8px; background: #f0e8d6; overflow: hidden; }
.m .tr i { display: block; height: 100%; width: 0; border-radius: 8px; background: linear-gradient(90deg, #c8b4f2, var(--pur)); transition: width 1s cubic-bezier(.3, 1, .4, 1); }
.m b { text-align: right; color: var(--ink); font-variant-numeric: tabular-nums; }
.lucky { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-top: 16px; }
.lucky div { padding: 11px 6px 10px; border-radius: 14px; background: #faf5ea; box-shadow: inset 0 0 0 1px var(--pline); text-align: center; font-size: 12px; color: var(--mute); font-weight: 600; }
.lucky b { display: block; margin-top: 3px; font-size: 15px; color: var(--ink); }
.lucky .dot { display: inline-block; width: 12px; height: 12px; border-radius: 50%; vertical-align: -1px; margin-right: 5px; box-shadow: inset 0 0 0 1px rgba(0, 0, 0, .12); }
.unborn { display: none; padding: 16px; border-radius: 16px; background: linear-gradient(135deg, #fff6e2, #f7efff); color: #5e3a08; font-size: 14px; line-height: 1.65; }
.unborn b { color: #a85200; }
.unborn .dd { display: block; margin-bottom: 4px; font-family: var(--serif); font-size: 28px; font-weight: 700; color: var(--pur2); }
.is-unborn #fortuneBox { display: none; } .is-unborn .unborn { display: block; }
.du { display: flex; gap: 6px; overflow-x: auto; -webkit-overflow-scrolling: touch; padding: 2px 2px 6px; scrollbar-width: none; }
.du::-webkit-scrollbar { display: none; }
.du div { flex: 0 0 auto; min-width: 60px; padding: 9px 6px 8px; border-radius: 14px; background: #faf5ea; box-shadow: inset 0 0 0 1px var(--pline); text-align: center; font-size: 12px; color: var(--mute); font-weight: 600; }
.du div b { display: block; font-family: var(--han); font-size: 19px; font-weight: 700; color: var(--ink); }
.du div.cur { background: var(--pur2); color: var(--gold-hi); box-shadow: 0 6px 14px rgba(42, 28, 110, .25); }
.du div.cur b { color: #fff; }
.warn { margin-top: 10px; padding: 10px 12px; border-radius: 12px; background: #fff3e0; color: #8f4700; font-size: 13px; }

.send .btns { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }
.btn { height: 52px; border-radius: 14px; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px; transition: transform .12s; }
.btn.kakao { background: #fee500; color: #191600; }
.btn.pdf { background: var(--pur2); color: #fff; }
.btn.sms, .btn.copy { background: #fff; color: var(--ink); box-shadow: inset 0 0 0 1.5px var(--pline); }
.btn svg { width: 20px; height: 20px; }
.btn:active { transform: scale(.98); }
.phone { display: flex; gap: 8px; }
.phone .inp { flex: 1; }
.cross { display: flex; align-items: center; gap: 14px; width: 100%; margin-top: 14px; padding: 14px 16px; border-radius: 20px; text-align: left; transition: transform .12s; }
.cross:active { transform: scale(.98); }
.cross .ic { position: relative; flex-shrink: 0; width: 52px; height: 52px; display: flex; align-items: center; justify-content: center; }
.cross b { display: block; font-family: var(--serif); font-size: 16px; font-weight: 700; }
.cross small { font-size: 12.5px; opacity: .78; }
.cross .ar { margin-left: auto; font-size: 18px; font-weight: 700; }
#saju .cross { position: relative; overflow: hidden; background: linear-gradient(120deg, #1d1352, #2c2378); color: #fff; box-shadow: 0 10px 24px rgba(30, 18, 80, .2); }
#saju .cross .ic .cback { position: absolute; width: 26px; height: 45px; transform-origin: 50% 120%; }
#saju .cross .ic .cback:nth-child(1) { transform: rotate(-16deg); } #saju .cross .ic .cback:nth-child(3) { transform: rotate(16deg); }
#tarot .cross { background: rgba(255, 255, 255, .06); color: #f1ebff; box-shadow: inset 0 0 0 1px rgba(232, 199, 122, .22); }
#tarot .cross .ic .seal { position: static; width: 44px; height: 44px; font-size: 14px; transform: rotate(-3deg); }
.foot { margin: 20px 4px 0; font-size: 12px; color: var(--mute); text-align: center; line-height: 1.7; }
.toast { position: fixed; left: 50%; bottom: calc(24px + env(safe-area-inset-bottom)); transform: translate(-50%, 20px); opacity: 0; padding: 12px 18px; border-radius: 999px; background: rgba(20, 14, 44, .94); color: #fff; font-size: 14px; font-weight: 600; transition: all .3s; pointer-events: none; z-index: 999; white-space: nowrap; box-shadow: 0 8px 24px rgba(0, 0, 0, .3); }
.toast.on { opacity: 1; transform: translate(-50%, 0); }
.noscript { margin: 14px auto; max-width: 528px; padding: 16px; border-radius: 16px; background: #fff4e5; color: #8a4500; font-size: 14.5px; line-height: 1.6; }

.anim .pl { animation: flip .65s cubic-bezier(.2, 1.2, .4, 1) both; }
.anim .pl:nth-child(3) { animation-delay: .05s; } .anim .pl:nth-child(2) { animation-delay: .17s; } .anim .pl:nth-child(1) { animation-delay: .29s; }
@keyframes flip { from { opacity: 0; transform: perspective(400px) rotateY(90deg); } to { opacity: 1; transform: none; } }
.anim .ohg .node { animation: nodeIn .6s var(--spring) both; transform-box: fill-box; transform-origin: center; }
.anim .ohg .node:nth-of-type(2) { animation-delay: .06s; } .anim .ohg .node:nth-of-type(3) { animation-delay: .12s; } .anim .ohg .node:nth-of-type(4) { animation-delay: .18s; } .anim .ohg .node:nth-of-type(5) { animation-delay: .24s; }
@keyframes nodeIn { from { opacity: 0; transform: scale(.4); } to { opacity: 1; transform: none; } }
.anim .stars i.on { animation: pop .45s cubic-bezier(.3, 1.8, .5, 1) .6s both; }
.anim .stars i:nth-child(2) { animation-delay: .68s; } .anim .stars i:nth-child(3) { animation-delay: .76s; } .anim .stars i:nth-child(4) { animation-delay: .84s; } .anim .stars i:nth-child(5) { animation-delay: .92s; }
@keyframes pop { from { transform: scale(0); } 70% { transform: scale(1.35); } to { transform: none; } }

/* ================= 타로 ================= */
#tarot { position: relative; min-height: 100vh; min-height: 100dvh; background: radial-gradient(130% 50% at 50% 0%, #2c1c78 0%, #170f3d 46%, var(--night) 82%); }
#tarot > .stars-bg { height: 520px; }
#tarot .wrap { position: relative; }
.t-hero { text-align: center; padding: 2px 0 4px; }
.t-hero .emb { width: 58px; height: 58px; margin: 0 auto 6px; }
.t-hero .emb svg { width: 100%; height: 100%; overflow: visible; }
.t-hero h1 { margin: 6px 0 0; font-family: var(--serif); font-size: 31px; font-weight: 700; color: #fff; }
.t-hero p { margin: 6px 0 0; font-size: 14px; color: var(--lav); }
.t-form { margin-top: 16px; padding: 16px; border-radius: 20px; background: rgba(255, 255, 255, .055); box-shadow: inset 0 0 0 1px rgba(232, 199, 122, .18); }
.t-form .row { display: grid; grid-template-columns: 1fr 1.25fr; gap: 10px; }
.t-form label { display: block; margin-bottom: 7px; font-size: 13px; font-weight: 700; color: var(--lav); }
.t-form .inp { height: 48px; border-color: rgba(255, 255, 255, .14); background: rgba(10, 6, 30, .55); color: #fff; font-size: 16px; color-scheme: dark; }
.t-form .inp:focus { border-color: var(--gold); box-shadow: 0 0 0 4px rgba(232, 199, 122, .15); }
.t-form .inp::placeholder { color: #8f86b8; }
.t-form .dpick { color: var(--gold); background: rgba(232, 199, 122, .14); }
.t-form .dwrap .inp { padding-right: 52px; }
.t-form .dpick input { color-scheme: dark; }
.t-birth { display: none; align-items: center; gap: 12px; margin-top: 12px; padding: 10px 12px; border-radius: 16px; background: linear-gradient(120deg, rgba(232, 199, 122, .14), rgba(232, 199, 122, .05)); box-shadow: inset 0 0 0 1px rgba(232, 199, 122, .2); font-size: 13.5px; line-height: 1.55; color: #f3e6c4; }
.t-birth.on { display: flex; animation: up .45s var(--spring) both; }
.t-birth .face { flex: none; --w: 40px; }
.t-birth b { color: var(--gold); font-family: var(--serif); font-size: 15px; }
.t-go { width: 100%; height: 52px; margin-top: 12px; border-radius: 14px; font-size: 16.5px; font-weight: 700; color: #2a1d00; background: linear-gradient(180deg, #f6dc98, #d6aa4f); box-shadow: 0 8px 20px rgba(214, 170, 79, .28); transition: opacity .2s, transform .12s; }
.t-go:disabled { opacity: .38; cursor: default; box-shadow: none; }
.t-go:active:not(:disabled) { transform: scale(.98); }

.t-stage:focus-visible { outline-offset: 6px; border-radius: 12px; }
.t-stage { position: relative; margin: 20px -6px 0; height: 360px; user-select: none; -webkit-user-select: none; touch-action: manipulation; }
.t-stage::before { content: ''; position: absolute; left: 0; right: 0; top: 0; height: 78%; background: radial-gradient(closest-side, rgba(155, 108, 245, .24), transparent); pointer-events: none; }
.t-arc { position: absolute; left: 50%; border-radius: 50%; border: 1px solid rgba(232, 199, 122, .16); pointer-events: none; transform: translateX(-50%); }
.t-msg { position: absolute; left: 0; right: 0; text-align: center; pointer-events: none; transition: opacity .3s; }
.t-msg b { display: block; font-family: var(--serif); font-size: 18px; font-weight: 700; color: #fff; text-shadow: 0 2px 12px rgba(13, 8, 38, .8); }
.t-msg span { display: block; margin-top: 3px; font-size: 13px; color: #c6bdea; text-shadow: 0 2px 10px rgba(13, 8, 38, .8); }
.t-msg .cnt { display: inline-block; margin-top: 8px; padding: 3px 12px; border-radius: 999px; background: rgba(232, 199, 122, .16); color: var(--gold); font-family: var(--cinzel); font-size: 13px; font-weight: 700; letter-spacing: .08em; }
.t-slot { position: absolute; border-radius: 7px; border: 1px solid rgba(232, 199, 122, .3); background: radial-gradient(circle at 50% 45%, rgba(232, 199, 122, .1), rgba(255, 255, 255, .02) 70%); }
.t-slot::before { content: ''; position: absolute; inset: 5px; border-radius: 4px; border: 1px dashed rgba(232, 199, 122, .22); }
.t-slot .no { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); font-family: var(--cinzel); font-size: 20px; font-weight: 700; color: rgba(232, 199, 122, .45); }
.t-slab { position: absolute; text-align: center; font-size: 12px; font-weight: 700; color: #c6bdea; line-height: 1.35; white-space: nowrap; }
.t-slab em { display: block; font-style: normal; font-size: 12px; font-weight: 700; opacity: 0; transition: opacity .3s; }
.t-slab em.up { color: #9fe6bd; } .t-slab em.rv { color: #ffaaa5; }
.t-slab.on em { opacity: 1; }

.tc { position: absolute; left: 0; top: 0; transform-origin: 50% 50%; transition: transform .5s cubic-bezier(.25, .9, .3, 1), opacity .5s; will-change: transform; }
.tc .in { position: relative; width: 100%; height: 100%; transform-style: preserve-3d; -webkit-transform-style: preserve-3d; transition: transform .65s cubic-bezier(.4, .1, .2, 1); }
.tc .bk, .tc .fc { position: absolute; inset: 0; -webkit-backface-visibility: hidden; backface-visibility: hidden; }
.tc .bk { background: url("../img/card-back.svg") center / 100% 100%; border-radius: calc(var(--sw, 70px) * .05); box-shadow: 0 1px 4px rgba(0, 0, 0, .5); }
.tc .fc { --w: var(--sw, 70px); width: var(--sw, 70px); height: 100%; transform: rotateY(180deg); }
.tc .fc.rv { transform: rotateY(180deg) rotate(180deg); }
.tc.flip .in { transform: rotateY(180deg); }
.tc.sp { cursor: pointer; }
.tc.sp .in { transition: transform .18s ease; }
@media (hover: hover) { .tc.sp:hover .in { transform: translateY(-16%); } .tc.sp:hover .bk { box-shadow: 0 0 0 1.5px var(--gold), 0 0 16px rgba(232, 199, 122, .75); } }
.tc.picked { cursor: pointer; }
.tc.picked .bk { box-shadow: 0 0 0 1.5px var(--gold), 0 0 22px rgba(232, 199, 122, .8); }
.tc.dim { opacity: .16; pointer-events: none; }
.tc.glow .fc { box-shadow: 0 0 0 2px var(--gold), 0 0 30px rgba(232, 199, 122, .9); }

.t-reads { margin-top: 8px; }
.trd { margin-top: 12px; padding: 14px; border-radius: 20px; background: rgba(255, 255, 255, .055); box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .08); animation: readIn .6s var(--spring) both; transition: box-shadow .3s; }
.trd.hl { box-shadow: inset 0 0 0 1.5px var(--gold); }
@keyframes readIn { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: none; } }
.trd-h { display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: #c6bdea; }
.trd-h .n { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: var(--gold); color: #2a1d00; font-family: var(--cinzel); font-size: 12px; font-weight: 700; }
.trd-h b { color: #fff; font-family: var(--serif); font-size: 15px; }
.trd-b { display: flex; gap: 14px; margin-top: 12px; }
.trd-card { flex: none; align-self: flex-start; border-radius: 8px; }
.trd-card { position: relative; }
.trd-card .face { --w: 76px; }
.trd-card::after { content: ''; position: absolute; right: -6px; bottom: -6px; width: 26px; height: 26px; border-radius: 50%; background: var(--gold) url("../img/zoom.svg") center / 15px no-repeat; box-shadow: 0 2px 8px rgba(0, 0, 0, .4); }
.trd-nm { font-family: var(--serif); font-size: 18px; font-weight: 700; color: #fff; line-height: 1.3; }
.trd-en { display: block; margin-top: 1px; font-family: var(--cinzel); font-size: 12px; font-weight: 700; letter-spacing: .1em; color: var(--mist); text-transform: uppercase; }
.ori { display: inline-block; margin-top: 6px; padding: 1px 9px; border-radius: 999px; font-size: 12px; font-weight: 700; }
.ori.up { background: rgba(159, 230, 189, .14); color: #9fe6bd; } .ori.rv { background: rgba(255, 170, 165, .14); color: #ffaaa5; }
.trd-kw { margin-top: 6px; font-size: 13px; font-weight: 700; color: var(--gold); }
.trd p { margin: 6px 0 0; font-size: 14.5px; line-height: 1.65; color: #e7e1fa; }
.zoom { display: inline-flex; align-items: center; gap: 4px; margin-top: 6px; font-size: 12px; font-weight: 700; color: var(--lav2); }

.t-sum { display: none; position: relative; margin-top: 18px; padding: 20px 16px 18px; border-radius: 24px; overflow: hidden; background: linear-gradient(165deg, #3a2391 0%, #22155c 55%, #160d40 100%); box-shadow: 0 16px 36px rgba(0, 0, 0, .35), inset 0 0 0 1px rgba(232, 199, 122, .35); animation: up .6s var(--spring) both; }
.t-sum.on { display: block; }
.t-sum .orn { margin-bottom: 10px; }
.t-sum h3 { margin: 0; text-align: center; font-family: var(--serif); font-size: 20px; font-weight: 700; color: #fff; }
.t-sum h3 .nm { color: var(--gold-hi); }
.t-row { display: flex; justify-content: center; gap: 8px; margin: 16px 0 4px; }
.t-row button { display: flex; flex-direction: column; align-items: center; gap: 6px; font-size: 12px; font-weight: 700; color: var(--lav); }
.t-row .face { --w: 64px; }
.t-sum .one { margin: 14px 0 0; text-align: center; font-family: var(--serif); font-size: 17px; font-weight: 700; line-height: 1.55; color: var(--gold-hi); }
.t-sum ul { list-style: none; margin: 14px 0 0; padding: 0; }
.t-sum li { position: relative; padding: 0 0 9px 18px; font-size: 14px; line-height: 1.65; color: #e7e1fa; }
.t-sum li::before { content: '✦'; position: absolute; left: 0; top: 0; font-size: 12px; color: var(--gold); }
.t-sum li b { color: #fff; }
.t-sum .tags { display: flex; flex-wrap: wrap; justify-content: center; gap: 5px; margin-top: 10px; }
.t-sum .tags span { padding: 3px 10px; border-radius: 999px; background: rgba(255, 255, 255, .1); font-size: 12px; font-weight: 700; color: #f1ebff; }
.t-btns { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 14px; }
.t-btns .btn.again { background: linear-gradient(180deg, #f6dc98, #d6aa4f); color: #2a1d00; }
.t-btns .btn.timg { grid-column: 1 / -1; height: 48px; background: rgba(255, 255, 255, .08); color: #f1ebff; box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .16); font-size: 15px; }
.t-hint { margin: 9px 2px 0; font-size: 12.5px; color: #b0a6dd; }
.t-foot { margin: 20px 4px 0; font-size: 12px; color: #948bbd; text-align: center; line-height: 1.7; }

/* 카드 크게 보기 */
.cv { position: fixed; inset: 0; z-index: 900; display: none; align-items: center; justify-content: center; padding: calc(16px + env(safe-area-inset-top)) 18px calc(16px + env(safe-area-inset-bottom)); background: rgba(6, 3, 20, .82); -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); color: #efeaff; }
.cv.on { display: flex; animation: fadeIn .25s ease both; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.lb-in { width: min(100%, 400px); max-height: 100%; overflow-y: auto; text-align: center; scrollbar-width: none; }
.lb-in::-webkit-scrollbar { display: none; }
.cv .face { --w: clamp(130px, min(58vw, calc((100vh - 330px) / 1.72)), 230px); margin: 6px auto 0; animation: lbIn .6s var(--spring) both; }
.cv .face.rev { animation-name: lbInR; }
@keyframes lbIn { from { opacity: 0; transform: perspective(700px) rotateY(-70deg) scale(.85); } to { opacity: 1; transform: none; } }
@keyframes lbInR { from { opacity: 0; transform: perspective(700px) rotateY(-70deg) scale(.85) rotate(180deg); } to { opacity: 1; transform: rotate(180deg); } }
.lb-pos { font-size: 13px; font-weight: 700; color: var(--gold); }
.lb-nm { margin-top: 14px; font-family: var(--serif); font-size: 22px; font-weight: 700; color: #fff; }
.lb-en { font-family: var(--cinzel); font-size: 12px; font-weight: 700; letter-spacing: .14em; color: var(--mist); text-transform: uppercase; }
.lb-kw { margin-top: 8px; font-size: 13.5px; font-weight: 700; color: var(--gold); }
.lb-tx { margin: 8px auto 0; max-width: 340px; font-size: 15px; line-height: 1.65; color: #e7e1fa; }
.lb-x { margin-top: 16px; height: 46px; padding: 0 26px; border-radius: 999px; background: rgba(255, 255, 255, .1); box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .18); font-size: 15px; font-weight: 700; color: #fff; }

@media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation: none !important; transition: none !important; } }

/* 인쇄 · PDF (사주 결과 A4 한 장) */
@media print {
  @page { size: A4; margin: 12mm; }
  body, body.v-saju, #saju { background: #fff !important; font-size: 12px; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  #gate, #tarot, .back, .cross, .cv { display: none !important; }
  .wrap { max-width: none; padding: 0; }
  .no-print, .send, .toast, #form { display: none !important; }
  .hero { box-shadow: none; padding: 14px 18px 0; border-radius: 14px; }
  .hero h1 { font-size: 20px; } .hero .iwo { margin-top: 4px; max-height: 70px; object-fit: cover; }
  .card { box-shadow: none; border: 1px solid #e3d9c4; margin-top: 8px; padding: 12px 14px; }
  #result, #result.on { display: grid !important; grid-template-columns: 1fr 1fr; gap: 0 10px; align-items: start; animation: none; }
  #result > .foot { grid-column: 1 / -1; }
  .sec { margin-top: 10px; break-inside: avoid; }
  .anim .pl, .anim .stars i.on, .anim .ohg .node { animation: none; }
  .m .tr i { transition: none; }
  .pl .c { max-width: 44px; font-size: 23px; border-radius: 9px; }
  .pl { padding: 5px 4px 6px; } .pls { gap: 6px; }
  .who .tti { width: 48px; height: 48px; font-size: 26px; }
  .ohg { max-width: 220px; } .me-desc { padding: 8px 12px; font-size: 12px; }
  .ring, .ring svg { width: 84px; height: 84px; } .ring .n b { font-size: 26px; }
  .head { font-size: 14.5px; } .lines { margin-top: 8px; } .lines li { font-size: 12px; padding-bottom: 4px; }
  .lucky { margin-top: 8px; } .lucky div { padding: 6px; }
  .du { display: grid; grid-template-columns: repeat(5, 1fr); gap: 4px; } .du div { min-width: 0; padding: 4px 2px; font-size: 10.5px; } .du div b { font-size: 14px; }
  .foot { margin-top: 8px; font-size: 10px; }
}

.ie-box { display: none; }
.is-ie .ie-box { display: block; max-width: 520px; margin: 60px auto; padding: 28px 26px; border-radius: 18px; background: #ffffff; border: 1px solid #e5e8eb; font-family: "Malgun Gothic", sans-serif; color: #191f28; text-align: center; }
.is-ie .ie-box h2 { margin: 0 0 10px; font-size: 22px; }
.is-ie .ie-box p { margin: 0 0 18px; font-size: 15px; line-height: 1.6; color: #4e5968; }
.is-ie .ie-box a { display: inline-block; padding: 14px 26px; border-radius: 12px; background: #3182f6; color: #ffffff; font-size: 16px; font-weight: bold; text-decoration: none; }
.is-ie .ie-box small { display: block; margin-top: 14px; font-size: 13px; color: #8b95a1; }
.ie-box .ie-l { display: none; }
.ie-loop .ie-box .ie-l { display: block; } .ie-loop .ie-box .ie-n { display: none; }
.is-ie .ie-box input { display: block; width: 100%; height: 44px; margin: 0 0 10px; padding: 0 12px; border: 1px solid #d1d6db; border-radius: 10px; font-size: 13px; color: #333d4b; background: #f9fafb; }
.ie-box #ie-url, .ie-box #ie-copy { display: none; }
.ie-loop .ie-box #ie-url, .ie-loop .ie-box #ie-copy { display: block; }
.is-ie .ie-box button { width: 100%; height: 50px; border: 0; border-radius: 12px; background: #191f28; color: #ffffff; font-size: 16px; font-weight: bold; cursor: pointer; }
.is-ie .view, .is-ie .toast { display: none !important; }
````

## img/card-back.svg

````xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 172">
<defs><radialGradient id="g" cx="50%" cy="50%" r="62%"><stop offset="0" stop-color="#2b1d6e"/><stop offset=".55" stop-color="#1a1146"/><stop offset="1" stop-color="#0f0a2c"/></radialGradient>
<pattern id="p" width="6" height="6" patternUnits="userSpaceOnUse"><circle cx="3" cy="3" r=".45" fill="#e8c77a" opacity=".32"/></pattern></defs>
<rect width="100" height="172" rx="5" fill="url(#g)"/>
<rect x="6.5" y="6.5" width="87" height="159" rx="2.5" fill="url(#p)"/>
<rect x="3.2" y="3.2" width="93.6" height="165.6" rx="3.6" fill="none" stroke="#e8c77a" stroke-width="1"/>
<rect x="6.5" y="6.5" width="87" height="159" rx="2.5" fill="none" stroke="#e8c77a" stroke-width=".45" opacity=".75"/>
<g transform="translate(9 9) scale(1 1)"><path d="M0 14V4a4 4 0 0 1 4-4h10" fill="none" stroke="#e8c77a" stroke-width=".7"/><path d="M3 11V6.5A3.5 3.5 0 0 1 6.5 3H11" fill="none" stroke="#e8c77a" stroke-width=".4" opacity=".7"/><circle cx="7.5" cy="7.5" r="1.3" fill="#e8c77a"/></g><g transform="translate(91 9) scale(-1 1)"><path d="M0 14V4a4 4 0 0 1 4-4h10" fill="none" stroke="#e8c77a" stroke-width=".7"/><path d="M3 11V6.5A3.5 3.5 0 0 1 6.5 3H11" fill="none" stroke="#e8c77a" stroke-width=".4" opacity=".7"/><circle cx="7.5" cy="7.5" r="1.3" fill="#e8c77a"/></g><g transform="translate(9 163) scale(1 -1)"><path d="M0 14V4a4 4 0 0 1 4-4h10" fill="none" stroke="#e8c77a" stroke-width=".7"/><path d="M3 11V6.5A3.5 3.5 0 0 1 6.5 3H11" fill="none" stroke="#e8c77a" stroke-width=".4" opacity=".7"/><circle cx="7.5" cy="7.5" r="1.3" fill="#e8c77a"/></g><g transform="translate(91 163) scale(-1 -1)"><path d="M0 14V4a4 4 0 0 1 4-4h10" fill="none" stroke="#e8c77a" stroke-width=".7"/><path d="M3 11V6.5A3.5 3.5 0 0 1 6.5 3H11" fill="none" stroke="#e8c77a" stroke-width=".4" opacity=".7"/><circle cx="7.5" cy="7.5" r="1.3" fill="#e8c77a"/></g>
<g stroke="#e8c77a" stroke-width=".5" fill="none" opacity=".8"><path d="M50 13V31M50 141V159"/></g>
<g fill="#e8c77a"><path d="M50 9.5l1.6 2.5-1.6 2.5-1.6-2.5z"/><path d="M50 157.5l1.6 2.5-1.6 2.5-1.6-2.5z"/>
<circle cx="50" cy="19" r=".8"/><circle cx="50" cy="25.5" r=".8"/><circle cx="50" cy="146.5" r=".8"/><circle cx="50" cy="153" r=".8"/></g>
<circle cx="50" cy="86" r="36.5" fill="none" stroke="#e8c77a" stroke-width=".35" opacity=".55"/>
<path d="M78.50 86.00L83.50 86.00M77.95 91.56L80.40 92.05M76.33 96.91L80.95 98.82M73.70 101.83L75.78 103.22M70.15 106.15L73.69 109.69M65.83 109.70L67.22 111.78M60.91 112.33L62.82 116.95M55.56 113.95L56.05 116.40M50.00 114.50L50.00 119.50M44.44 113.95L43.95 116.40M39.09 112.33L37.18 116.95M34.17 109.70L32.78 111.78M29.85 106.15L26.31 109.69M26.30 101.83L24.22 103.22M23.67 96.91L19.05 98.82M22.05 91.56L19.60 92.05M21.50 86.00L16.50 86.00M22.05 80.44L19.60 79.95M23.67 75.09L19.05 73.18M26.30 70.17L24.22 68.78M29.85 65.85L26.31 62.31M34.17 62.30L32.78 60.22M39.09 59.67L37.18 55.05M44.44 58.05L43.95 55.60M50.00 57.50L50.00 52.50M55.56 58.05L56.05 55.60M60.91 59.67L62.82 55.05M65.83 62.30L67.22 60.22M70.15 65.85L73.69 62.31M73.70 70.17L75.78 68.78M76.33 75.09L80.95 73.18M77.95 80.44L80.40 79.95" stroke="#e8c77a" stroke-width=".55" stroke-linecap="round"/>
<circle cx="50" cy="86" r="26" fill="#140d38" stroke="#e8c77a" stroke-width=".9"/>
<circle cx="50" cy="86" r="23.3" fill="none" stroke="#e8c77a" stroke-width=".35"/>
<g fill="#e8c77a"><circle cx="70.28" cy="91.44" r=".7"/><circle cx="64.85" cy="100.85" r=".7"/><circle cx="55.44" cy="106.28" r=".7"/><circle cx="44.56" cy="106.28" r=".7"/><circle cx="35.15" cy="100.85" r=".7"/><circle cx="29.72" cy="91.44" r=".7"/><circle cx="29.72" cy="80.56" r=".7"/><circle cx="35.15" cy="71.15" r=".7"/><circle cx="44.56" cy="65.72" r=".7"/><circle cx="55.44" cy="65.72" r=".7"/><circle cx="64.85" cy="71.15" r=".7"/><circle cx="70.28" cy="80.56" r=".7"/></g>
<polygon points="50.00,71.00 51.99,81.20 60.61,75.39 54.80,84.01 65.00,86.00 54.80,87.99 60.61,96.61 51.99,90.80 50.00,101.00 48.01,90.80 39.39,96.61 45.20,87.99 35.00,86.00 45.20,84.01 39.39,75.39 48.01,81.20" fill="#e8c77a" opacity=".22"/>
<polygon points="50.00,73.50 51.38,82.67 58.84,77.16 53.33,84.62 62.50,86.00 53.33,87.38 58.84,94.84 51.38,89.33 50.00,98.50 48.62,89.33 41.16,94.84 46.67,87.38 37.50,86.00 46.67,84.62 41.16,77.16 48.62,82.67" fill="#e8c77a"/>
<circle cx="50" cy="86" r="3.4" fill="#140d38"/><circle cx="50" cy="86" r="1.7" fill="#e8c77a"/>
<g fill="#e8c77a"><path d="M44.30 37.58A6.20 6.20 0 1 1 55.70 37.58A5.33 5.33 0 1 0 44.30 37.58z"/><path d="M44.30 134.42A6.20 6.20 0 1 0 55.70 134.42A5.33 5.33 0 1 1 44.30 134.42z"/></g>
<g fill="#e8c77a"><polygon points="22.00,81.80 22.99,85.01 26.20,86.00 22.99,86.99 22.00,90.20 21.01,86.99 17.80,86.00 21.01,85.01"/><polygon points="78.00,81.80 78.99,85.01 82.20,86.00 78.99,86.99 78.00,90.20 77.01,86.99 73.80,86.00 77.01,85.01"/>
<polygon points="26.00,37.80 26.57,39.43 28.20,40.00 26.57,40.57 26.00,42.20 25.43,40.57 23.80,40.00 25.43,39.43"/><polygon points="74.00,37.80 74.57,39.43 76.20,40.00 74.57,40.57 74.00,42.20 73.43,40.57 71.80,40.00 73.43,39.43"/><polygon points="26.00,129.80 26.57,131.43 28.20,132.00 26.57,132.57 26.00,134.20 25.43,132.57 23.80,132.00 25.43,131.43"/><polygon points="74.00,129.80 74.57,131.43 76.20,132.00 74.57,132.57 74.00,134.20 73.43,132.57 71.80,132.00 73.43,131.43"/>
<circle cx="18" cy="62" r=".7"/><circle cx="82" cy="62" r=".7"/><circle cx="18" cy="110" r=".7"/><circle cx="82" cy="110" r=".7"/></g>
</svg>
````

## img/hanji.svg

````xml
<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240"><filter id="n"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" stitchTiles="stitch"/><feColorMatrix values="0 0 0 0 .45 0 0 0 0 .38 0 0 0 0 .25 0 0 0 .05 0"/></filter><rect width="240" height="240" filter="url(#n)"/></svg>
````

## img/zoom.svg

````xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#2a1d00" stroke-width="2.4" stroke-linecap="round"><circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5 5M10.5 8v5M8 10.5h5"/></svg>
````

## js/app.js

````js
/* 오늘의 운세 v2 · 2026-10-29 (사주팔자·타로) · 세일즈혁신TF · 빌드: fortune/build_unse.py --web */
/* 화면 이동 · 사주 화면 · 타로 연출 · 크게 보기 · 저장/공유 */
(function () {
  'use strict';
  var S = window.NZ_SAJU, TA = window.NZ_TAROT, IMG = window.NZ_TAROT_IMG || [], $ = function (id) { return document.getElementById(id); };
  var WEEK = ['일', '월', '화', '수', '목', '금', '토'], MIN_D = 19360101, MAX_D = 20461231;
  var RM = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var SANS = '"Pretendard", -apple-system, "Apple SD Gothic Neo", "Malgun Gothic", sans-serif';
  var SERIF = '"UnseSerif", "UnseHan", "AppleMyungjo", "Noto Serif KR", "Batang", serif';
  var CINZEL = '"UnseCinzel", Georgia, serif';
  function kstNow() { var k = new Date(Date.now() + 9 * 3600e3); return { y: k.getUTCFullYear(), m: k.getUTCMonth() + 1, d: k.getUTCDate(), w: WEEK[k.getUTCDay()] }; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function toast(t) { var e = $('toast'); e.textContent = t; e.classList.add('on'); clearTimeout(e._t); e._t = setTimeout(function () { e.classList.remove('on'); }, 2200); }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, RM ? Math.min(ms, 30) : ms); }); }
  function copy(t) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(t);
    return new Promise(function (res) { var ta = document.createElement('textarea'); ta.value = t; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, t.length); try { document.execCommand('copy'); } catch (e) {} ta.remove(); res(); });
  }
  /* 'YYYY-MM-DD' → {y,m,d} (1936-01-01 ~ 2046-12-31) */
  function parseD(v, quiet) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v || '')) return null;
    var a = v.split('-').map(Number), n = a[0] * 1e4 + a[1] * 100 + a[2];
    var t = new Date(Date.UTC(a[0], a[1] - 1, a[2]));
    if (t.getUTCMonth() !== a[1] - 1 || t.getUTCDate() !== a[2]) { if (!quiet) toast('없는 날짜예요 · 다시 확인해 주세요'); return null; }
    if (n < MIN_D || n > MAX_D) { if (!quiet) toast('1936년 1월 1일부터 2046년 12월 31일까지 고를 수 있어요'); return null; }
    return { y: a[0], m: a[1], d: a[2], n: n };
  }
  /* 그림 저장(캔버스)에 쓰는 글꼴은 미리 불러 둔다 (파일 안에 심은 글꼴이라 금방 끝남) */
  function fontsReady() {
    if (!document.fonts || !document.fonts.load) return Promise.resolve();
    return Promise.all([document.fonts.load('700 20px UnseSerif', '오늘의 운세'), document.fonts.load('700 20px UnseHan', '甲子'), document.fonts.load('700 20px UnseCinzel', 'TAROT')]).catch(function () {});
  }
  fontsReady();

  /* 생년월일 칸: 숫자만 쳐도 '1990-09-28' 꼴로 자동 하이픈, 8자리가 맞으면 키보드 내림. 달력 아이콘(투명 date 칸)으로 고르면 칸에 채움.
     다른 'input' 리스너보다 먼저 등록해야 정리된 값이 넘어감 */
  function bindDate(id) {
    var t = $(id), p = $(id + 'Pick');
    t.addEventListener('input', function () {
      var d = this.value.replace(/[^0-9]/g, '').slice(0, 8);
      var v = d.length > 6 ? d.slice(0, 4) + '-' + d.slice(4, 6) + '-' + d.slice(6) : d.length > 4 ? d.slice(0, 4) + '-' + d.slice(4) : d;
      if (v !== this.value) this.value = v;
      if (d.length === 8 && parseD(v, true)) { p.value = v; if (!this._fromPick) this.blur(); }
    });
    t.addEventListener('blur', function () { var n = this.value.replace(/[^0-9]/g, '').length; if (n && n < 8) toast('생년월일 숫자 8자리로 넣어 주세요 (예: 19900928)'); });
    t.addEventListener('keydown', function (e) { if (e.key === 'Enter') this.blur(); });
    p.addEventListener('click', function () { try { if (this.showPicker) this.showPicker(); } catch (e) {} });
    p.addEventListener('change', function () {
      if (!this.value) return;
      t.value = this.value; t._fromPick = true; t.dispatchEvent(new Event('input')); t.dispatchEvent(new Event('change')); t._fromPick = false;
    });
  }
  bindDate('bd'); bindDate('tbd');

  var T = kstNow(), TN = T.y * 1e4 + T.m * 100 + T.d, tp = S.pillars(T.y, T.m, T.d);
  var todayHtml = T.m + '월 ' + T.d + '일 (' + T.w + ') · <b>' + S.gz(tp.di) + '</b>일 ' + S.gzK(tp.di) + '일';
  $('gToday').innerHTML = todayHtml; $('today').innerHTML = todayHtml;

  /* ================= 타로 카드 앞면 =================
     크림색 테두리 + 1909년 원판 그림(window.NZ_TAROT_IMG, deck id 순서) + 한글 이름판.
     그림은 style 속성 대신 CSSOM 으로 넣음 (보안정책 CSP 대응) */
  function lenCls(s) { return s.length >= 7 ? ' l2' : s.length >= 5 ? ' l1' : ''; }
  function paintFace(el, c, rev) {
    el.innerHTML = '<div class="art"></div><div class="np' + lenCls(c.ko) + '"><b>' + c.ko + '</b><small>' + c.en + '</small></div>';
    if (IMG[c.id]) el.querySelector('.art').style.backgroundImage = 'url("' + IMG[c.id] + '")';
    el.setAttribute('role', 'img');
    el.setAttribute('aria-label', (c.major ? TA.ROMAN[c.no] + ' ' : '') + c.ko + ' 카드' + (rev ? ' · 역방향' : ''));
  }
  function makeFace(c, w, rev, cls) {
    var d = document.createElement('div');
    d.className = 'face' + (rev ? ' rev' : '') + (cls ? ' ' + cls : '');
    if (w) d.style.setProperty('--w', w);
    paintFace(d, c, rev);
    return d;
  }
  var imgCache = {};
  function cardImg(id) {
    if (!imgCache[id]) imgCache[id] = new Promise(function (res) {
      if (!IMG[id]) return res(null);
      var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = IMG[id];
    });
    return imgCache[id];
  }
  /* 대문 타로 문: 마법사 · 운명의 수레바퀴 · 달 */
  [1, 10, 18].forEach(function (id) { $('gFan').appendChild(makeFace(TA.deck[id], '66px')); });

  /* ================= 화면 이동 (#saju · #tarot · 대문) ================= */
  var THEME = { gate: '#0d0826', saju: '#f4efe4', tarot: '#0d0826' };
  function route() {
    var v = (location.hash || '').replace('#', '');
    if (v !== 'saju' && v !== 'tarot') v = 'gate';
    closeLb(true);
    document.body.className = 'v-' + v; $('themeColor').setAttribute('content', THEME[v]);
    $('gate').classList.remove('leaving'); [].forEach.call(document.querySelectorAll('.door'), function (d) { d.classList.remove('chosen'); });
    window.scrollTo(0, 0);
    if (v !== 'gate') carry(v);   // 주소(#saju·#tarot)로 바로 들어와도 이름·생년월일 이어받기
    if (v === 'tarot') tarotEnter();
    if (v === 'saju') sajuEnter();
  }
  /* 생년월일·이름은 두 화면이 같이 씀 */
  function carry(to) {
    var nm = to === 'saju' ? ['tnm', 'nm'] : ['nm', 'tnm'], bd = to === 'saju' ? ['tbd', 'bd'] : ['bd', 'tbd'];
    if (!$(nm[1]).value && $(nm[0]).value) $(nm[1]).value = $(nm[0]).value;
    if (!$(bd[1]).value && $(bd[0]).value) { $(bd[1]).value = $(bd[0]).value; if (parseD($(bd[1]).value, true)) $(bd[1] + 'Pick').value = $(bd[1]).value; }
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-go]'); if (!b) return;
    var to = b.getAttribute('data-go');
    if (b.classList.contains('door') && !RM) {
      b.classList.add('chosen'); $('gate').classList.add('leaving');
      setTimeout(function () { location.hash = to; }, 320);
    } else location.hash = to === 'gate' ? '' : to;
  });
  window.addEventListener('hashchange', route);

  /* ================= 사주 ================= */
  var DM = ['큰 나무처럼 곧고 시작을 잘하는 사람', '풀꽃처럼 유연하고 어디서든 잘 어울리는 사람', '태양처럼 밝고 열정이 넘치는 사람', '촛불처럼 섬세하고 따뜻한 사람', '큰 산처럼 듬직하고 믿음직한 사람',
            '너른 들처럼 포용력 있고 실속 있는 사람', '바위처럼 결단력 있고 의리 있는 사람', '보석처럼 예리하고 깔끔한 사람', '바다처럼 지혜롭고 마음이 넓은 사람', '이슬비처럼 총명하고 감성이 풍부한 사람'];
  var ECOL = [['#2f9e62', '#e7f5ec'], ['#e0402f', '#fcebe8'], ['#b67d00', '#fbf1d6'], ['#5f6873', '#eceef1'], ['#2b4a8b', '#e7edf8']];
  var st = { g: 'M', last: null };
  function sajuEnter() { if ($('bd').value && (!st.last || st.lastDate !== $('bd').value)) run(true); }
  $('gender').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    st.g = b.getAttribute('data-v'); [].forEach.call(this.children, function (x) { x.classList.toggle('on', x === b); x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); }); run(false);
  });
  ['input', 'change'].forEach(function (ev) { $('bd').addEventListener(ev, function () { run(true); }); });
  $('nm').addEventListener('input', function () { if (st.last) renderWho(); });
  $('ph').addEventListener('input', function () { var v = this.value.replace(/[^0-9]/g, '').slice(0, 11); this.value = v.length > 7 ? v.slice(0, 3) + '-' + v.slice(3, v.length - 4) + '-' + v.slice(-4) : v.length > 3 ? v.slice(0, 3) + '-' + v.slice(3) : v; });
  function name() { return $('nm').value.trim(); }
  function daysBetween(a, b) { return Math.round((Date.UTC(b.y, b.m - 1, b.d) - Date.UTC(a.y, a.m - 1, a.d)) / 864e5); }

  function run(anim) {
    var b = parseD($('bd').value); if (!b) return;
    if (anim && st.lastDate === $('bd').value) anim = false;   // 사파리는 날짜 칸을 벗어날 때도 change 를 보내므로 같은 날짜면 연출 생략
    st.lastDate = $('bd').value;
    var p = S.pillars(b.y, b.m, b.d), f = S.fortune(b.y, b.m, b.d, st.g === 'M', T.y, T.m, T.d), du = S.daeun(p, st.g === 'M');
    st.last = { b: b, p: p, f: f, du: du, unborn: b.n > TN, dday: daysBetween(T, b) };
    render(anim);
  }
  function age(b) { return T.y - b.y - ((T.m * 100 + T.d) < (b.m * 100 + b.d) ? 1 : 0); }
  function renderWho() {
    var L = st.last, p = L.p, b = L.b, nm = name();
    var tag = L.unborn ? '<small class="due">출생 예정 D-' + L.dday + '</small>' : '<small>' + (st.g === 'M' ? '남' : '여') + ' · 만 ' + age(b) + '세</small>';
    $('who').innerHTML = '<div class="tti" aria-hidden="true">' + S.ANIMAL_E[p.yb] + '<i>' + S.BR[p.yb] + '</i></div><div><div class="nm">' + (nm ? esc(nm) : (L.unborn ? '아기' : '이름 없음')) + tag + '</div>' +
      '<div class="bd">' + b.y + '년 ' + b.m + '월 ' + b.d + '일' + (L.unborn ? ' 출생 예정' : '생') + ' (양력) · <em>' + S.ANIMAL[p.yb] + '띠</em></div>' +
      '<div class="gz">' + S.gz(S.gzIndex(p.ys, p.yb)) + '년 ' + S.gz(S.gzIndex(p.ms, p.mb)) + '월 ' + S.gz(p.di) + '일</div></div>';
  }
  function tile(lb, s, b, god, me) {
    var es = S.stemEl(s), eb = S.BR_EL[b];
    return '<div class="pl' + (me ? ' me' : '') + '"><span class="lb">' + lb + '</span><span class="god">' + god + '</span>' +
      '<span class="c e' + es + '">' + S.STEM[s] + '</span><span class="c e' + eb + '">' + S.BR[b] + '</span>' +
      '<span class="k">' + S.STEM_K[s] + S.BR_K[b] + '</span><span class="el">' + S.EL_H[es] + '·' + S.EL_H[eb] + '</span></div>';
  }
  /* 오행 상생 고리: 木(위)부터 시계 방향 火 土 金 水. 바깥 원 화살표 = 상생, 안쪽 점선 별 = 상극. 동그라미 크기 = 글자 수 */
  function ohDiagram(c, ds) {
    var cx = 160, cy = 146, R = 90, P = [], h = '', k, a;
    for (k = 0; k < 5; k++) { a = (-90 + k * 72) * Math.PI / 180; P.push([cx + R * Math.cos(a), cy + R * Math.sin(a), Math.cos(a), Math.sin(a)]); }
    h += '<polygon points="' + [0, 2, 4, 1, 3].map(function (i) { return P[i][0].toFixed(1) + ',' + P[i][1].toFixed(1); }).join(' ') + '" fill="none" stroke="#dccfb3" stroke-width="1" stroke-dasharray="3 5"/>';
    h += '<circle cx="' + cx + '" cy="' + cy + '" r="' + R + '" fill="none" stroke="#e2d6bc" stroke-width="1.3"/>';
    h += '<g fill="none" stroke="#c4ab76" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">';
    for (k = 0; k < 5; k++) {
      a = -90 + k * 72 + 36; var r = a * Math.PI / 180, x = cx + R * Math.cos(r), y = cy + R * Math.sin(r);
      h += '<path d="M-4 -4.5L1.5 0L-4 4.5" transform="translate(' + x.toFixed(1) + ' ' + y.toFixed(1) + ') rotate(' + (a + 90) + ')"/>';
    }
    h += '</g>';
    var de = S.stemEl(ds);
    h += '<circle cx="' + cx + '" cy="' + cy + '" r="27" fill="#fffdf8" stroke="#d6c8aa"/><text x="' + cx + '" y="' + (cy - 7) + '" text-anchor="middle" dominant-baseline="central" font-size="21" font-weight="700" fill="' + ECOL[de][0] + '">' + S.STEM[ds] + '</text>' +
      '<text x="' + cx + '" y="' + (cy + 13) + '" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="700" fill="#736d86" class="lbl">일간</text>';
    for (k = 0; k < 5; k++) {
      var n = c[k], rr2 = 19 + Math.min(n, 4) * 4.5, q = P[k], col = ECOL[k];
      var lx = q[0] + q[2] * (rr2 + 16), ly = q[1] + q[3] * (rr2 + 13);
      h += '<g class="node"><circle cx="' + q[0].toFixed(1) + '" cy="' + q[1].toFixed(1) + '" r="' + rr2 + '" fill="' + col[1] + '" stroke="' + col[0] + '" stroke-width="' + (n ? 1.6 : 1.2) + '"' + (n ? '' : ' stroke-dasharray="3 3" opacity=".55"') + '/>' +
        '<text x="' + q[0].toFixed(1) + '" y="' + q[1].toFixed(1) + '" text-anchor="middle" dominant-baseline="central" font-size="' + Math.round(15 + Math.min(n, 4) * 2.5) + '" font-weight="700" fill="' + col[0] + '"' + (n ? '' : ' opacity=".55"') + '>' + S.EL_H[k] + '</text>' +
        '<text x="' + lx.toFixed(1) + '" y="' + ly.toFixed(1) + '" text-anchor="middle" dominant-baseline="central" font-size="13" font-weight="700" fill="' + (n ? '#4b4560' : '#77718a') + '" class="lbl">' + S.EL[k] + ' ' + n + '</text></g>';
    }
    return '<svg class="ohg" viewBox="0 0 320 292" role="img" aria-label="오행 분포 ' + c.map(function (v, i) { return S.EL[i] + ' ' + v; }).join(', ') + '">' + h + '</svg>';
  }
  function render(anim) {
    var L = st.last, p = L.p, f = L.f, d = p.ds;
    renderWho();
    $('pls').innerHTML = tile('일주', p.ds, p.db, '나 (일간)', true) + tile('월주', p.ms, p.mb, S.tenGod(d, p.ms)) + tile('년주', p.ys, p.yb, S.tenGod(d, p.ys));
    var j = p.jieToday, bef = j && j.kst.hh * 60 + j.kst.mm <= 720, ip = j && j.name === '입춘';
    $('warn').innerHTML = j ? '<div class="warn">' + j.name + ' 당일' + (L.unborn ? ' 출생 예정' : ' 출생') + '이에요. ' + j.name + ' 시각(' + pad(j.kst.hh) + ':' + pad(j.kst.mm) + ') ' +
      (bef ? '전에' : '뒤에') + ' 태어나면 ' + (ip ? '띠·년주·월주' : '월주') + '가 ' + (bef ? (ip ? '앞 해' : '앞 달') : (ip ? '다음 해' : '다음 달')) + ' 기준으로 바뀌어요 (지금은 정오 출생으로 계산).</div>' : '';
    var c = S.counts(p);
    $('ohs').innerHTML = ohDiagram(c, d);
    var mx = Math.max.apply(null, c), mn = Math.min.apply(null, c);
    $('meDesc').innerHTML = '나를 나타내는 일간은 <b class="h">' + S.STEM[d] + S.EL_H[S.stemEl(d)] + '</b>, ' + DM[d] + '이에요. ' +
      '<b>' + c.map(function (v, k) { return v === mx ? S.EL[k] : null; }).filter(Boolean).join('·') + '</b> 기운이 많고, ' +
      (mn === 0 ? '<b>' + c.map(function (v, k) { return v === 0 ? S.EL[k] : null; }).filter(Boolean).join('·') + '</b> 기운이 비어 있어요.' : '오행이 고루 있는 편이에요.');
    $('result').classList.toggle('is-unborn', L.unborn);
    $('fTitle').textContent = L.unborn ? '태어날 아기의 기운' : '오늘의 운세';
    $('tgDay').textContent = L.unborn ? 'D-' + L.dday : T.m + '/' + T.d + ' ' + S.gz(tp.di) + '일';
    if (L.unborn) {
      var le = c.indexOf(Math.min.apply(null, c));
      $('unborn').innerHTML = '<span class="dd">D-' + L.dday + '</span>' + L.b.y + '년 ' + L.b.m + '월 ' + L.b.d + '일에 태어나면 <b>' + S.ANIMAL[p.yb] + '띠</b>, 일간 <b>' + S.STEM[d] + S.EL_H[S.stemEl(d)] + '</b>의 아이예요. ' +
        DM[d] + '으로 자랄 기운이에요.<br>아직 태어나기 전이라 오늘의 운세 대신 타고난 기운을 보여 드려요. 채워 주면 좋은 기운은 <b>' + S.EL[le] + '(' + S.EL_H[le] + ')</b>이에요.';
    }
    var stars = ''; for (var i = 0; i < 5; i++) stars += '<i class="' + (i < f.stars ? 'on' : '') + '">★</i>';
    $('stars').innerHTML = stars; $('stars').setAttribute('role', 'img'); $('stars').setAttribute('aria-label', '별 5개 중 ' + f.stars + '개'); $('head').textContent = '“' + f.head + '”';
    $('keys').innerHTML = '<span class="god">' + f.god + '의 날</span>' + f.keys.map(function (k) { return '<span>#' + k + '</span>'; }).join('');
    $('lines').innerHTML = [f.dayLine, f.ttiLine, f.balLine].map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('');
    $('meters').innerHTML = [['재물', 0], ['대화', 1], ['일', 2], ['컨디션', 3]].map(function (k) { return '<div class="m"><span>' + k[0] + '</span><span class="tr"><i data-w="' + f.scores[k[1]] + '"></i></span><b>' + f.scores[k[1]] + '</b></div>'; }).join('');
    $('lucky').innerHTML = '<div>행운 색<b><i class="dot"></i>' + f.color + '</b></div><div>행운 숫자<b>' + f.number + '</b></div><div>행운 방향<b>' + f.direction + '</b></div>';
    $('lucky').querySelector('.dot').style.background = f.colorHex;   // style 속성 대신 CSSOM (보안정책 CSP 대응)
    var a = L.unborn ? -1 : age(L.b), cur = null; L.du.list.forEach(function (x) { if (x.age <= a) cur = x; });
    $('tgDu').textContent = L.du.n + '세 시작 · ' + (L.du.fwd ? '순행' : '역행');
    $('du').innerHTML = L.du.list.map(function (x) { return '<div class="' + (cur === x ? 'cur' : '') + '"><b>' + S.gz(x.i) + '</b>' + x.age + '세~</div>'; }).join('');
    var R = 46, C = 2 * Math.PI * R, fg = $('ringFg');
    fg.style.strokeDasharray = C.toFixed(1);
    var res = $('result'), first = !res.classList.contains('on');
    res.classList.add('on'); res.classList.toggle('anim', !!anim);
    if (anim || first) { fg.style.transition = 'none'; fg.style.strokeDashoffset = C; void fg.getBoundingClientRect(); fg.style.transition = ''; }
    requestAnimationFrame(function () { requestAnimationFrame(function () {
      fg.style.strokeDashoffset = (C * (1 - f.total / 100)).toFixed(1);
      [].forEach.call(document.querySelectorAll('#meters i'), function (x) { x.style.width = x.getAttribute('data-w') + '%'; });
    }); });
    var n = $('scoreN'), to = f.total, t0 = performance.now();
    if (anim || first) (function step(now) { var k = Math.min(1, (now - t0) / 900); n.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(step); })(t0); else n.textContent = to;
    if (anim && first) setTimeout(function () { res.scrollIntoView({ behavior: RM ? 'auto' : 'smooth', block: 'start' }); }, 250);
  }

  function shareText() {
    var L = st.last, p = L.p, f = L.f, b = L.b, nm = name() || (L.unborn ? '아기' : '고객');
    var head = '[오늘의 사주] ' + nm + '님\n' + b.y + '년 ' + b.m + '월 ' + b.d + '일' + (L.unborn ? ' 출생 예정' : '생') + '(양력) · ' + S.ANIMAL[p.yb] + '띠\n' +
      '사주: ' + S.gz(p.di) + '일 ' + S.gz(S.gzIndex(p.ms, p.mb)) + '월 ' + S.gz(S.gzIndex(p.ys, p.yb)) + '년\n\n';
    if (L.unborn) return head + '출생까지 D-' + L.dday + ' · 일간 ' + S.STEM[p.ds] + S.EL_H[S.stemEl(p.ds)] + ', ' + DM[p.ds] + '\n\n재미로 보는 사주예요 :)';
    return head + T.m + '월 ' + T.d + '일 오늘의 운세 ' + f.total + '점 ' + '★★★★★'.slice(0, f.stars) + '\n“' + f.head + '”\n· ' + f.dayLine + '\n· ' + f.ttiLine +
      '\n행운 색 ' + f.color + ' · 숫자 ' + f.number + ' · 방향 ' + f.direction + '\n\n재미로 보는 사주예요 :)';
  }
  function wrapText(ctx, text, x, y, maxW, lh, maxLines) {
    var line = '', lines = [];
    text.split(' ').forEach(function (w) { var t = line ? line + ' ' + w : w; if (ctx.measureText(t).width > maxW && line) { lines.push(line); line = w; } else line = t; });
    if (line) lines.push(line);
    lines.slice(0, maxLines).forEach(function (l, i) { ctx.fillText(l, x, y + i * lh); });
    return Math.min(lines.length, maxLines) * lh;
  }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function starsOn(x, W, H, n, seed) {
    for (var i = 0; i < n; i++) { x.fillStyle = 'rgba(255,255,255,' + (0.18 + ((i + seed) * 37 % 50) / 100) + ')'; x.beginPath(); x.arc((i * 173 + seed) % W, (i * 97 + seed) % H, (i % 3) * 0.8 + 0.9, 0, 7); x.fill(); }
  }
  function makeImage() {
    var L = st.last, p = L.p, f = L.f, b = L.b, nm = name() || (L.unborn ? '아기' : '고객');
    var W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    var x = cv.getContext('2d');
    x.fillStyle = '#f4efe4'; x.fillRect(0, 0, W, H);
    var g = x.createRadialGradient(W / 2, 0, 60, W / 2, 240, 760); g.addColorStop(0, '#3d2793'); g.addColorStop(0.5, '#22165c'); g.addColorStop(1, '#120a35');
    x.fillStyle = g; x.fillRect(0, 0, W, 640);
    starsOn(x, W, 600, 64, 7);
    /* 일월: 왼쪽 달 · 오른쪽 해 */
    [[884, '#f6ecd0', '#e9dcb8'], [972, '#ff7a52', '#c9392a']].forEach(function (q) {
      x.strokeStyle = 'rgba(232,199,122,.55)'; x.lineWidth = 2; x.beginPath(); x.arc(q[0], 112, 44, 0, 7); x.stroke();
      var sg = x.createRadialGradient(q[0] - 10, 100, 4, q[0], 112, 32); sg.addColorStop(0, q[1]); sg.addColorStop(1, q[2]);
      x.fillStyle = sg; x.beginPath(); x.arc(q[0], 112, 30, 0, 7); x.fill();
    });
    x.fillStyle = '#e8c77a'; x.font = '700 28px ' + CINZEL; x.fillText('MeAI · SAJU', 72, 98);
    x.fillStyle = '#fff'; x.font = '700 62px ' + SERIF; x.fillText(nm + '님의 ' + (L.unborn ? '사주' : '오늘의 사주'), 72, 176);
    x.fillStyle = '#e4dcff'; x.font = '600 31px ' + SANS; x.fillText(b.y + '년 ' + b.m + '월 ' + b.d + '일' + (L.unborn ? ' 출생 예정' : '생') + '(양력) · ' + S.ANIMAL[p.yb] + '띠 ' + S.ANIMAL_E[p.yb], 72, 232);
    var cols = [['일주', p.ds, p.db], ['월주', p.ms, p.mb], ['년주', p.ys, p.yb]], cw = 256, gap = 28, sx = (W - (cw * 3 + gap * 2)) / 2;
    cols.forEach(function (c, k) {
      var cx = sx + k * (cw + gap), y0 = 276, ch = 328;
      x.shadowColor = 'rgba(0,0,0,.35)'; x.shadowBlur = 30; x.shadowOffsetY = 10;
      var tg = x.createLinearGradient(0, y0, 0, y0 + ch); tg.addColorStop(0, k === 0 ? '#fff8e4' : '#fffcf4'); tg.addColorStop(1, k === 0 ? '#f8ead0' : '#faf2e1');
      x.fillStyle = tg; rr(x, cx, y0, cw, ch, 28); x.fill(); x.shadowColor = 'transparent';
      if (k === 0) { x.strokeStyle = '#b8913f'; x.lineWidth = 4; rr(x, cx, y0, cw, ch, 28); x.stroke(); }
      x.textAlign = 'center'; x.fillStyle = k === 0 ? '#7d5f22' : '#736d86'; x.font = '700 27px ' + SANS; x.fillText(c[0] + (k === 0 ? ' · 나' : ''), cx + cw / 2, y0 + 46);
      [[c[1], S.stemEl(c[1]), S.STEM], [c[2], S.BR_EL[c[2]], S.BR]].forEach(function (q, j) {
        var col = ECOL[q[1]]; x.fillStyle = col[1]; rr(x, cx + 50, y0 + 66 + j * 106, cw - 100, 96, 22); x.fill();
        x.fillStyle = col[0]; x.font = '700 66px ' + SERIF; x.fillText(q[2][q[0]], cx + cw / 2, y0 + 138 + j * 106);
      });
      x.fillStyle = '#4b4560'; x.font = '700 27px ' + SANS; x.fillText(S.STEM_K[c[1]] + S.BR_K[c[2]], cx + cw / 2, y0 + 304);
      x.textAlign = 'left';
    });
    x.fillStyle = '#fffdf8'; rr(x, 60, 664, W - 120, 626, 36); x.fill();
    x.strokeStyle = '#e7ddc8'; x.lineWidth = 2; rr(x, 60, 664, W - 120, 626, 36); x.stroke();
    if (L.unborn) {
      x.fillStyle = '#2a1c6e'; x.font = '700 104px ' + SERIF; x.fillText('D-' + L.dday, 110, 800);
      x.fillStyle = '#1c1730'; x.font = '700 42px ' + SERIF; var h2 = wrapText(x, '일간 ' + S.STEM[p.ds] + S.EL_H[S.stemEl(p.ds)] + ', ' + DM[p.ds], 110, 890, W - 220, 60, 3);
      x.fillStyle = '#4b4560'; x.font = '500 31px ' + SANS; wrapText(x, '아직 태어나기 전이라 오늘의 운세 대신 타고난 기운을 담았어요.', 110, 910 + h2, W - 220, 46, 3);
    } else {
      x.fillStyle = '#2a1c6e'; x.font = '700 116px ' + SERIF; x.fillText(String(f.total), 106, 794);
      var tw = x.measureText(String(f.total)).width; x.fillStyle = '#736d86'; x.font = '700 34px ' + SANS; x.fillText('점', 116 + tw, 794);
      x.fillStyle = '#e0a51f'; x.font = '40px ' + SANS; x.fillText('★★★★★'.slice(0, f.stars), 360, 752); x.fillStyle = '#e6dfcf'; x.fillText('★★★★★'.slice(f.stars), 360 + x.measureText('★★★★★'.slice(0, f.stars)).width, 752);
      x.fillStyle = '#4b2fb0'; x.font = '700 29px ' + SANS; x.fillText(T.m + '월 ' + T.d + '일 ' + S.gz(tp.di) + '일 · ' + f.god + '의 날', 360, 798);
      x.fillStyle = '#1c1730'; x.font = '700 40px ' + SERIF; var hh = wrapText(x, '“' + f.head + '”', 110, 884, W - 220, 56, 3);
      x.fillStyle = '#4b4560'; x.font = '500 30px ' + SANS; var yy = 884 + hh + 16;
      yy += wrapText(x, '· ' + f.dayLine, 110, yy, W - 220, 44, 2) + 8;
      yy += wrapText(x, '· ' + f.ttiLine, 110, yy, W - 220, 44, 2) + 14;
      x.fillStyle = '#f3eefc'; rr(x, 110, yy, W - 220, 70, 22); x.fill();
      x.fillStyle = f.colorHex; x.beginPath(); x.arc(150, yy + 35, 14, 0, 7); x.fill();
      x.fillStyle = '#2a1c6e'; x.font = '700 30px ' + SANS; x.fillText('행운 색 ' + f.color + '  ·  숫자 ' + f.number + '  ·  ' + f.direction, 178, yy + 46);
    }
    x.fillStyle = '#736d86'; x.font = '500 25px ' + SANS; x.textAlign = 'center'; x.fillText('재미로 보는 사주예요 · 양력 · 한국 표준시 기준', W / 2, H - 22); x.textAlign = 'left';
    return cv;
  }
  function toBlob(cv) { return new Promise(function (res, rej) { try { cv.toBlob(function (b) { if (b) res(b); else rej(new Error('toBlob')); }, 'image/png'); } catch (e) { rej(e); } }); }
  function sajuBlob() { return fontsReady().then(function () { return toBlob(makeImage()); }); }
  function ready() { if (!st.last) { toast('먼저 생년월일을 골라 주세요'); $('bd').focus(); return false; } return true; }
  function fileName() { var b = st.last.b; return '오늘의사주_' + (name() || '고객') + '_' + b.y + pad(b.m) + pad(b.d) + '.png'; }
  $('bKakao').addEventListener('click', function () {
    if (!ready()) return;
    var text = shareText();
    sajuBlob().then(function (blob) {
      var file = new File([blob], fileName(), { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) return navigator.share({ files: [file], text: text, title: '오늘의 사주' });
      if (navigator.share) return navigator.share({ text: text, title: '오늘의 사주' });
      return copy(text).then(function () { toast('내용을 복사했어요 · 카카오톡 대화창에 붙여 넣으세요'); });
    }).catch(function (e) { if (e && e.name !== 'AbortError') copy(text).then(function () { toast('공유가 안 돼서 내용을 복사했어요'); }); });
  });
  $('bPdf').addEventListener('click', function () {
    if (!ready()) return;
    var nm = name() || '고객', b = st.last.b, old = document.title;
    document.title = '오늘의사주_' + nm + '_' + b.y + pad(b.m) + pad(b.d);
    $('result').classList.remove('anim');
    setTimeout(function () { window.print(); setTimeout(function () { document.title = old; }, 800); }, 60);
  });
  $('bSms').addEventListener('click', function () {
    if (!ready()) return;
    var num = $('ph').value.replace(/[^0-9]/g, '');
    if (num && !/^01[016789]\d{7,8}$/.test(num)) { toast('휴대폰 번호를 다시 확인해 주세요'); $('ph').focus(); return; }
    var ios = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    location.href = 'sms:' + num + (ios ? '&' : '?') + 'body=' + encodeURIComponent(shareText());
  });
  $('bImg').addEventListener('click', function () {
    if (!ready()) return;
    sajuBlob().then(function (blob) {
      var file = new File([blob], fileName(), { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) return navigator.share({ files: [file] }).catch(function () {});
      var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = fileName(); document.body.appendChild(a); a.click(); a.remove();
      toast('이미지를 저장했어요');
    });
  });

  /* ================= 타로 =================
     흐름: 생년월일 → [카드 섞기] (가운데 더미에서 좌우로 3번 섞음) → 78장이 초승달 모양으로 펼쳐짐
           → 한 장 누를 때마다: 바깥으로 들림 → 아래 자리(1~4)로 날아감 → 뒤집힘(역방향이면 거꾸로) → 풀이 등장
           → 남은 카드는 빈자리를 메우며 다시 정렬 → 4장째에 종합 메시지
     카드 배정: 섞을 때 78장 순서를 crypto 난수로 정하고, 고른 순서대로 그 순서의 카드를 엶 (매번 새로) */
  function yeyo(w) { var c = w.charCodeAt(w.length - 1); return c >= 0xAC00 && c <= 0xD7A3 && (c - 0xAC00) % 28 ? '이에요' : '예요'; }
  function rnd(n) {
    var cr = window.crypto || window.msCrypto;
    if (cr && cr.getRandomValues) { var a = new Uint32Array(1), lim = Math.floor(4294967296 / n) * n; do { cr.getRandomValues(a); } while (a[0] >= lim); return a[0] % n; }
    return Math.floor(Math.random() * n);
  }
  function shuffledOrder() { var o = [], i; for (i = 0; i < 78; i++) o.push(i); for (i = 77; i > 0; i--) { var j = rnd(i + 1), t = o[i]; o[i] = o[j]; o[j] = t; } return o; }
  function kwHtml(txt) { return txt[0].split('·').map(function (w) { return '#' + w; }).join(' '); }
  function fullName(c) { return (c.major ? TA.ROMAN[c.no] + ' ' : '') + c.ko; }

  var TT = { phase: 'idle', cards: [], spread: [], picks: [], order: null, lock: false, G: null, built: false, birth: null };
  var stage = $('stage'), ROM = ['I', 'II', 'III', 'IV'];
  function tname() { return $('tnm').value.trim(); }

  function buildStage() {
    var h = '', i;
    for (i = 0; i < 4; i++) h += '<div class="t-slot" id="slot' + i + '"><span class="no">' + ROM[i] + '</span></div><div class="t-slab" id="slab' + i + '">' + TA.POS[i].k + '<em></em></div>';
    h += '<div class="t-msg" id="tmsg"></div>';
    for (i = 0; i < 78; i++) h += '<div class="tc" data-i="' + i + '"><div class="in"><div class="bk"></div><div class="fc face"></div></div></div>';
    stage.innerHTML = h;
    TT.cards = [].slice.call(stage.querySelectorAll('.tc'));
    TT.built = true;
  }
  /* 무대 크기에 맞춰 초승달·자리 좌표 계산 */
  function geom() {
    var W = stage.clientWidth, sw = Math.min(92, Math.floor((W - 24 - 30) / 4)), sh = Math.round(sw * 1.72);
    var k0 = 0.54, smin = 0.4, amax = 74 * Math.PI / 180, Lt = sh * k0 * smin;
    var R = Math.max(90, (W / 2 - 8) / Math.sin(amax) - Lt);
    var cy = R + sh * k0 + 16, slotsY = Math.round(cy - R * Math.cos(amax) + 24), gap = Math.round((W - 24 - sw * 4) / 3);
    var G = { W: W, sw: sw, sh: sh, k0: k0, smin: smin, amax: amax, R: R, cy: cy, slotsY: slotsY, gap: gap, H: slotsY + sh + 40 };
    stage.style.height = G.H + 'px'; stage.style.setProperty('--sw', sw + 'px');
    TT.cards.forEach(function (el) { el.style.width = sw + 'px'; el.style.height = sh + 'px'; });
    for (var i = 0; i < 4; i++) {
      var sx = 12 + i * (sw + gap), s = $('slot' + i), l = $('slab' + i);
      s.style.left = sx + 'px'; s.style.top = slotsY + 'px'; s.style.width = sw + 'px'; s.style.height = sh + 'px';
      l.style.left = (sx - 12) + 'px'; l.style.width = (sw + 24) + 'px'; l.style.top = (slotsY + sh + 7) + 'px';
    }
    var m = $('tmsg'); m.style.top = Math.round(cy - R + sh * 0.22) + 'px';
    TT.G = G; return G;
  }
  function setT(el, p) { el._p = p; el.style.transform = 'translate(' + p.x.toFixed(1) + 'px,' + p.y.toFixed(1) + 'px) rotate(' + p.r.toFixed(2) + 'deg) scale(' + p.s.toFixed(3) + ')'; }
  /* 초승달: 원호를 따라 놓되 가운데는 크고 양 끝은 작게 → 바깥 테두리가 가늘어지는 초승달 실루엣 */
  function spreadPos(i, n) {
    var G = TT.G, t = n <= 1 ? 0.5 : i / (n - 1), a = -G.amax + 2 * G.amax * t, s = G.smin + (1 - G.smin) * Math.sin(Math.PI * t);
    var L = G.sh * G.k0 * s, r = G.R + L / 2;
    return { x: G.W / 2 + r * Math.sin(a) - G.sw / 2, y: G.cy - r * Math.cos(a) - G.sh / 2, r: a * 180 / Math.PI, s: G.k0 * s };
  }
  function stackPos(i) { var G = TT.G; return { x: G.W / 2 - G.sw / 2, y: G.cy - G.R * 0.62 - G.sh / 2 - i * 0.18, r: (i % 5 - 2) * 0.6, s: G.k0 * 1.35 }; }
  function slotPos(k) { var G = TT.G; return { x: 12 + k * (G.sw + G.gap), y: G.slotsY, r: 0, s: 1 }; }
  function msg(html) { var m = $('tmsg'); m.innerHTML = html; m.style.opacity = html ? 1 : 0; }
  function counter() { return '<span class="cnt">' + TT.picks.length + ' / 4</span>'; }

  function tarotEnter() {
    if (!TT.built) { buildStage(); geom(); TT.cards.forEach(function (el, i) { el.style.transition = 'none'; setT(el, stackPos(i)); }); void stage.offsetWidth; TT.cards.forEach(function (el) { el.style.transition = ''; }); msg(''); }
    else relayout();
    tBirthUpdate();
  }
  function relayout() {
    if (!TT.built) return;
    geom();
    TT.cards.forEach(function (el) { el.style.transition = 'none'; });
    if (TT.phase === 'idle' || TT.phase === 'shuffling') TT.cards.forEach(function (el, i) { setT(el, stackPos(i)); });
    else { TT.spread.forEach(function (el, i) { setT(el, spreadPos(i, TT.spread.length)); }); TT.picks.forEach(function (p, k) { setT(p.el, slotPos(k)); }); }
    void stage.offsetWidth; TT.cards.forEach(function (el) { el.style.transition = ''; });
  }
  var rzT; window.addEventListener('resize', function () { clearTimeout(rzT); rzT = setTimeout(function () { if (document.body.className === 'v-tarot' && TT.G && stage.clientWidth !== TT.G.W) relayout(); }, 120); });

  function tBirthUpdate() {
    var b = parseD($('tbd').value, true), go = $('tGo');
    if (!b) { $('tBirth').classList.remove('on'); TT.birth = null; if (TT.phase === 'idle') { go.disabled = true; go.textContent = '생년월일을 넣어 주세요'; } return; }
    var n = TA.birthCard(b.y, b.m, b.d), c = TA.deck[n]; TT.birth = n;
    $('tBirth').innerHTML = '<span>나의 탄생 카드는 <b>' + TA.ROMAN[n] + ' ' + c.ko + '</b>' + yeyo(c.ko) + '<br>' + c.up[0] + '</span>';
    $('tBirth').insertBefore(makeFace(c, '44px'), $('tBirth').firstChild);
    $('tBirth').classList.add('on');
    if (TT.phase === 'idle') { go.disabled = false; go.textContent = '카드 섞기'; }
  }
  ['input', 'change'].forEach(function (ev) { $('tbd').addEventListener(ev, function () { if (/^\d{4}-\d{2}-\d{2}$/.test(this.value)) parseD(this.value); tBirthUpdate(); }); });

  $('tGo').addEventListener('click', function () {
    if (!TT.birth && TT.birth !== 0) { toast('먼저 생년월일을 넣어 주세요'); return; }
    if (TT.phase === 'idle') shuffle();
    else if (TT.phase === 'done' || TT.phase === 'spread') resetAndShuffle();
  });

  async function shuffle() {
    if (TT.lock) return; TT.lock = true; TT.phase = 'shuffling';
    var go = $('tGo'); go.disabled = true; go.textContent = '카드를 섞는 중…';
    msg('');
    stage.scrollIntoView({ behavior: RM ? 'auto' : 'smooth', block: 'center' });
    TT.order = shuffledOrder(); TT.picks = [];
    var G = TT.G, cards = TT.cards;
    for (var round = 0; round < 3; round++) {
      cards.forEach(function (el, i) {
        var side = ((i + round) % 2) ? 1 : -1, b = stackPos(i);
        el.style.transitionDuration = '.24s'; el.style.transitionDelay = (i % 13) * 6 + 'ms';
        setT(el, { x: b.x + side * G.sw * 0.62, y: b.y - (i % 9) * 1.2, r: side * 9, s: b.s });
      });
      await wait(320);
      cards.forEach(function (el, i) { setT(el, stackPos(i)); });
      await wait(300);
    }
    /* 초승달로 펼치기 (왼쪽 끝부터 차례로) */
    TT.spread = cards.slice();
    cards.forEach(function (el, i) { el.style.transitionDuration = '.7s'; el.style.transitionDelay = (i * 9) + 'ms'; setT(el, spreadPos(i, 78)); });
    await wait(720 + 78 * 9);
    cards.forEach(function (el) { el.style.transitionDuration = ''; el.style.transitionDelay = ''; el.classList.add('sp'); });
    TT.phase = 'spread'; TT.lock = false;
    go.disabled = false; go.textContent = '다시 섞기';
    msg('<b>마음속 질문을 떠올리고</b><span>끌리는 카드 4장을 차례로 눌러 주세요</span>' + counter());
  }

  stage.addEventListener('click', function (e) {
    var el = e.target.closest('.tc'); if (!el) return;
    if (el.classList.contains('picked')) { var k = +el.getAttribute('data-k'); if (TT.picks[k]) openLb(k); return; }
    if (TT.phase === 'spread' && el.classList.contains('sp')) pick(el);
    else if (TT.phase === 'idle' && !TT.lock) { if (TT.birth == null) { toast('먼저 생년월일을 넣어 주세요'); $('tbd').focus(); } else shuffle(); }
  });

  stage.addEventListener('keydown', function (e) {
    if (e.target !== stage || (e.key !== 'Enter' && e.key !== ' ')) return;
    e.preventDefault();
    if (TT.phase === 'spread' && !TT.lock && TT.spread.length) pick(TT.spread[Math.floor(TT.spread.length / 2)]);
    else if (TT.phase === 'idle' && !TT.lock) { if (TT.birth == null) { toast('먼저 생년월일을 넣어 주세요'); $('tbd').focus(); } else shuffle(); }
    else if (TT.phase === 'done') openLb(0);
  });

  async function pick(el) {
    if (TT.lock || TT.picks.length >= 4) return;
    TT.lock = true;
    var k = TT.picks.length, card = TA.deck[TT.order[k]], rev = rnd(2) === 1;
    TT.spread.splice(TT.spread.indexOf(el), 1);
    el.classList.remove('sp'); el.classList.add('picked'); el.setAttribute('data-k', k); el.style.zIndex = 300 + k;
    var fc = el.querySelector('.fc'); paintFace(fc, card, rev); fc.classList.toggle('rv', rev);
    var img = cardImg(card.id);
    /* ① 바깥으로 쏙 들림 */
    var p = el._p, a = p.r * Math.PI / 180;
    el.style.transitionDuration = '.22s';
    setT(el, { x: p.x + 34 * Math.sin(a), y: p.y - 34 * Math.cos(a), r: p.r, s: p.s * 1.3 });
    await wait(230);
    /* ② 남은 카드가 빈자리를 메우고, 고른 카드는 자리로 날아감 */
    TT.spread.forEach(function (c, i) { setT(c, spreadPos(i, TT.spread.length)); });
    el.style.transitionDuration = '.62s';
    setT(el, slotPos(k));
    await wait(640);
    /* ③ 뒤집기 */
    el.classList.add('flip');
    await wait(600);
    el.style.transitionDuration = '';
    el.classList.add('glow'); fc.classList.add('sheen'); setTimeout(function () { el.classList.remove('glow'); }, 900);
    var sl = $('slab' + k); sl.querySelector('em').textContent = rev ? '역방향' : '정방향'; sl.querySelector('em').className = rev ? 'rv' : 'up'; sl.classList.add('on');
    TT.picks.push({ el: el, card: card, rev: rev, img: img });
    addReading(k);
    TT.lock = false;
    if (TT.picks.length === 4) finish();
    else msg('<b>' + ['', '좋아요, 두 번째 카드를', '세 번째 카드를', '마지막 한 장을'][TT.picks.length] + '</b><span>' + TA.POS[TT.picks.length].k + ' · ' + TA.POS[TT.picks.length].d + '</span>' + counter());
  }

  function addReading(k) {
    var P = TT.picks[k], c = P.card, txt = P.rev ? c.rv : c.up, pos = TA.POS[k];
    var div = document.createElement('article'); div.className = 'trd'; div.id = 'trd' + k;
    div.innerHTML = '<div class="trd-h"><span class="n">' + (k + 1) + '</span><b>' + pos.k + '</b> · ' + pos.d + '</div>' +
      '<div class="trd-b"><button type="button" class="trd-card" data-k="' + k + '" aria-label="' + c.ko + ' 카드 크게 보기"></button><div>' +
      '<div class="trd-nm">' + fullName(c) + '</div><span class="trd-en">' + c.en + '</span>' +
      '<span class="ori ' + (P.rev ? 'rv' : 'up') + '">' + (P.rev ? '역방향' : '정방향') + '</span>' +
      '<div class="trd-kw">' + kwHtml(txt) + '</div><p>' + txt[1] + '</p></div></div>';
    div.querySelector('.trd-card').appendChild(makeFace(c, '76px', P.rev));
    $('reads').appendChild(div);
  }

  function summary() {
    var P = TT.picks, majors = P.filter(function (p) { return p.card.major; }), revs = P.filter(function (p) { return p.rev; }).length;
    var sc = [0, 0, 0, 0]; P.forEach(function (p) { if (!p.card.major) sc[p.card.suit]++; });
    var top = sc.indexOf(Math.max.apply(null, sc)), lines = [];
    if (majors.length >= 2) lines.push('메이저 카드가 ' + majors.length + '장이나 나왔어요. 오늘 일어나는 일은 생각보다 오래, 크게 영향을 줄 수 있어요.');
    else if (majors.length === 1) { var mj = majors[0]; lines.push('오늘의 중심은 메이저 카드 <b>「' + mj.card.ko + '」</b>. ' + (mj.rev ? '「' + mj.card.rv[0].split('·')[0] + '」 쪽으로 기울지 않게 조심하세요.' : '「' + mj.card.up[0].split('·')[0] + '」의 기운을 믿고 움직이세요.')); }
    else lines.push('모두 마이너 카드예요. 큰 사건보다 일상의 작은 선택이 쌓여 흐름을 만드는 날이에요.');
    if (sc[top] >= 2) lines.push(TA.SUIT_SUM[top]);
    lines.push(revs === 0 ? '모든 카드가 정방향이에요. 막힘 없이 흐르는 기운이니 망설이지 말고 움직이세요.' : revs <= 2 ? '역방향이 ' + revs + '장 있어요. 살짝 엇박자가 나는 부분만 점검하면 충분해요.' : '역방향이 ' + revs + '장이에요. 속도를 늦추고 한 번 돌아보면 오히려 길이 보여요.');
    var bc = TA.deck[TT.birth], hit = P.some(function (p) { return p.card.id === TT.birth; });
    lines.push(hit ? '<b>탄생 카드 ' + bc.ko + '</b>가 직접 나왔어요! 오늘은 나다움이 가장 큰 무기예요.' : '나의 탄생 카드 <b>' + TA.ROMAN[TT.birth] + ' ' + bc.ko + '</b>의 힘(' + bc.up[0] + ')을 떠올리면 도움이 돼요.');
    var key = P[2].rev ? P[2].card.rv[0] : P[2].card.up[0], flow = P[3].rev ? P[3].card.rv[0] : P[3].card.up[0];
    var one = (P[2].rev ? '「' + key.split('·')[0] + '」에 귀 기울이면, ' : '「' + key.split('·')[0] + '」의 힘을 빌리면, ') +
      (P[3].rev ? '「' + flow.split('·')[0] + '」의 신호를 살필수록 흐름이 풀려요.' : '「' + flow.split('·')[0] + '」의 흐름이 다가와요.');
    var tags = P.map(function (p) { return (p.rev ? p.card.rv[0] : p.card.up[0]).split('·')[0]; });
    return { lines: lines, one: one, tags: tags };
  }
  function finish() {
    TT.phase = 'done';
    TT.spread.forEach(function (el) { el.classList.remove('sp'); el.classList.add('dim'); });
    msg('<b>오늘의 카드 4장이 모두 열렸어요</b><span>카드를 누르면 크게 볼 수 있어요</span>');
    var S2 = summary(), nm = tname();
    $('tsum').innerHTML = '<div class="orn" aria-hidden="true"><svg><use href="#spark"/></svg></div><h3>' + (nm ? '<span class="nm">' + esc(nm) + '</span>님의 ' : '') + '오늘의 타로 메시지</h3>' +
      '<div class="t-row" id="tRow"></div>' +
      '<p class="one">' + S2.one + '</p><div class="tags">' + S2.tags.map(function (t) { return '<span>#' + t + '</span>'; }).join('') + '</div>' +
      '<ul>' + S2.lines.map(function (l) { return '<li>' + l + '</li>'; }).join('') + '</ul>' +
      '<div class="t-btns"><button type="button" class="btn again" id="tAgain">다시 뽑기</button><button type="button" class="btn kakao" id="tShare">카톡으로 보내기</button><button type="button" class="btn timg" id="tImg">이미지로 저장</button></div>' +
      '<p class="t-hint">카톡으로 보내기 → 공유 창에서 <b>카카오톡</b>을 고르면 카드 4장과 점괘가 담긴 이미지가 함께 가요.</p>';
    TT.picks.forEach(function (P, k) {
      var b = document.createElement('button'); b.type = 'button'; b.setAttribute('data-k', k); b.setAttribute('aria-label', TA.POS[k].k + ' · ' + P.card.ko + ' 크게 보기');
      b.appendChild(makeFace(P.card, '64px', P.rev)); b.appendChild(document.createTextNode(TA.POS[k].k)); $('tRow').appendChild(b);
    });
    $('tsum').classList.add('on');
    $('tAgain').addEventListener('click', resetAndShuffle);
    $('tShare').addEventListener('click', function () { shareTarot(S2, true); });
    $('tImg').addEventListener('click', function () { shareTarot(S2, false); });
    $('tGo').textContent = '다시 뽑기';
    setTimeout(function () { $('tsum').scrollIntoView({ behavior: RM ? 'auto' : 'smooth', block: 'start' }); }, 500);
  }

  /* ---------- 카드 크게 보기 ---------- */
  var lastFocus = null;
  function openLb(k) {
    var P = TT.picks[k]; if (!P) return;
    var c = P.card, txt = P.rev ? c.rv : c.up;
    $('lbIn').innerHTML = '<div class="lb-pos">' + (k + 1) + ' · ' + TA.POS[k].k + '</div><div id="lbCard"></div>' +
      '<div class="lb-nm" id="lbNm">' + fullName(c) + '</div><div class="lb-en">' + c.en + '</div>' +
      '<span class="ori ' + (P.rev ? 'rv' : 'up') + '">' + (P.rev ? '역방향' : '정방향') + '</span>' +
      '<div class="lb-kw">' + kwHtml(txt) + '</div><p class="lb-tx">' + txt[1] + '</p><button type="button" class="lb-x" id="lbX">닫기</button>';
    $('lbCard').appendChild(makeFace(c, '', P.rev, 'big sheen'));
    lastFocus = document.activeElement;
    $('lb').classList.add('on'); document.body.style.overflow = 'hidden';
    $('lbX').focus();
  }
  function closeLb(quiet) {
    if (!$('lb').classList.contains('on')) return;
    $('lb').classList.remove('on'); $('lbIn').innerHTML = ''; document.body.style.overflow = '';
    if (!quiet && lastFocus && lastFocus.focus) lastFocus.focus();
  }
  $('lb').addEventListener('click', function (e) { if (e.target === this || e.target.id === 'lbX') closeLb(); });
  document.addEventListener('keydown', function (e) {
    if (!$('lb').classList.contains('on')) return;
    if (e.key === 'Escape') closeLb();
    else if (e.key === 'Tab') { e.preventDefault(); $('lbX').focus(); }
  });
  document.addEventListener('click', function (e) {
    var b = e.target.closest('.trd-card, .t-row button'); if (!b) return;
    openLb(+b.getAttribute('data-k'));
  });

  /* ---------- 타로 결과 이미지 (카드 4장 + 점괘) ----------
     카드 그림은 같은 출처 파일(웹판) 또는 파일 안에 넣은 그림(한 파일판)이라 캔버스가 오염되지 않음 → 오프라인·보안정책(CSP)에서도 저장 가능 */
  function drawFace(x, c, rev, X, Y, w, img) {
    var h = w * 1.72, p = w * 0.06, aw = w - 2 * p, ah = aw * 1.6923;
    x.save(); x.translate(X + w / 2, Y + h / 2); if (rev) x.rotate(Math.PI); x.translate(-w / 2, -h / 2);
    x.shadowColor = 'rgba(0,0,0,.5)'; x.shadowBlur = 28; x.shadowOffsetY = rev ? -10 : 10;
    var g = x.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#fcf6e6'); g.addColorStop(0.6, '#f3e7c9'); g.addColorStop(1, '#ead9b2');
    x.fillStyle = g; rr(x, 0, 0, w, h, w * 0.055); x.fill(); x.shadowColor = 'transparent';
    x.strokeStyle = 'rgba(184,145,63,.8)'; x.lineWidth = 2; rr(x, w * 0.028, w * 0.028, w - w * 0.056, h - w * 0.056, w * 0.035); x.stroke();
    if (img) x.drawImage(img, p, p, aw, ah); else { x.fillStyle = '#e9dcc0'; x.fillRect(p, p, aw, ah); }
    x.strokeStyle = 'rgba(42,31,14,.65)'; x.lineWidth = 1.5; x.strokeRect(p, p, aw, ah);
    var py = p + ah, ph = h - py, fs = c.ko.length >= 7 ? 0.094 : c.ko.length >= 5 ? 0.108 : 0.125;
    x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = '#2a1f0e';
    x.font = '700 ' + Math.round(w * fs) + 'px ' + SERIF; x.fillText(c.ko, w / 2, py + ph * 0.52);
    x.restore(); x.textAlign = 'left'; x.textBaseline = 'alphabetic';
  }
  function makeTarotImage(S2, imgs, H) {   // H 없이 부르면 한 번 그려 본 뒤 내용 길이에 맞춰 다시 그림
    if (!H) H = makeTarotImage(S2, imgs, 2600).end + 100;
    var W = 1080, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    var x = cv.getContext('2d'), nm = tname() || '고객', i;
    var g = x.createRadialGradient(W / 2, 0, 40, W / 2, H * 0.3, H); g.addColorStop(0, '#3a2391'); g.addColorStop(0.45, '#1d1247'); g.addColorStop(1, '#0d0826');
    x.fillStyle = g; x.fillRect(0, 0, W, H);
    starsOn(x, W, 900, 80, 3);
    x.strokeStyle = 'rgba(232,199,122,.55)'; x.lineWidth = 2; rr(x, 24, 24, W - 48, H - 48, 28); x.stroke();
    x.strokeStyle = 'rgba(232,199,122,.25)'; x.lineWidth = 1; rr(x, 36, 36, W - 72, H - 72, 20); x.stroke();
    x.textAlign = 'center';
    x.fillStyle = '#e8c77a'; x.font = '700 28px ' + CINZEL; x.fillText('MeAI · TAROT', W / 2, 104);
    x.fillStyle = '#fff'; x.font = '700 58px ' + SERIF; x.fillText(nm + '님의 오늘의 타로', W / 2, 180);
    var bc = TA.deck[TT.birth];
    x.fillStyle = '#d6cdf6'; x.font = '600 28px ' + SANS; x.fillText(T.y + '년 ' + T.m + '월 ' + T.d + '일 (' + T.w + ') · 탄생 카드 ' + TA.ROMAN[TT.birth] + ' ' + bc.ko, W / 2, 230);
    /* 카드 4장 */
    var cw = 222, ch = cw * 1.72, gap = 22, sx = (W - cw * 4 - gap * 3) / 2, cyTop = 280;
    TT.picks.forEach(function (P, k) {
      var X = sx + k * (cw + gap);
      drawFace(x, P.card, P.rev, X, cyTop, cw, imgs[k]);
      x.textAlign = 'center'; x.fillStyle = '#e8e1ff'; x.font = '700 26px ' + SANS; x.fillText((k + 1) + ' ' + TA.POS[k].k, X + cw / 2, cyTop + ch + 46);
      x.fillStyle = P.rev ? '#ffaaa5' : '#9fe6bd'; x.font = '700 24px ' + SANS; x.fillText(P.rev ? '역방향' : '정방향', X + cw / 2, cyTop + ch + 80);
    });
    /* 점괘 */
    var py = cyTop + ch + 116;
    x.fillStyle = 'rgba(255,255,255,.07)'; rr(x, 60, py, W - 120, H - py - 100, 32); x.fill();
    x.strokeStyle = 'rgba(232,199,122,.35)'; x.lineWidth = 2; rr(x, 60, py, W - 120, H - py - 100, 32); x.stroke();
    x.textAlign = 'left'; x.fillStyle = '#f8e7b4'; x.font = '700 36px ' + SERIF;
    var y = py + 68; y += wrapText(x, '✦ ' + S2.one, 100, y, W - 200, 52, 2) + 20;
    TT.picks.forEach(function (P, k) {
      var c = P.card, txt = P.rev ? c.rv : c.up;
      x.fillStyle = '#e8c77a'; x.beginPath(); x.arc(116, y - 10, 19, 0, 7); x.fill();
      x.fillStyle = '#2a1d00'; x.font = '700 24px ' + CINZEL; x.textAlign = 'center'; x.fillText(String(k + 1), 116, y - 1); x.textAlign = 'left';
      x.fillStyle = '#fff'; x.font = '700 31px ' + SERIF; x.fillText(TA.POS[k].k + ' · ' + fullName(c) + (P.rev ? ' (역)' : ''), 150, y);
      x.fillStyle = '#ddd6f6'; x.font = '500 28px ' + SANS;
      y += 44 + wrapText(x, txt[1], 150, y + 44, W - 250, 40, 2) + 20;
    });
    x.textAlign = 'center'; x.fillStyle = 'rgba(214,205,246,.62)'; x.font = '500 23px ' + SANS;
    x.fillText('재미로 보는 타로예요 · 라이더-웨이트-스미스 타로(1909) · 매번 새로 섞어요', W / 2, H - 58);
    cv.end = y + 4; return cv;
  }
  function shareTarot(S2, kakao) {
    var text = tarotText(S2), fname = '오늘의타로_' + (tname() || '고객') + '_' + T.y + pad(T.m) + pad(T.d) + '.png';
    Promise.all([fontsReady()].concat(TT.picks.map(function (p) { return p.img || cardImg(p.card.id); }))).then(function (r) {
      /* 웹서버판 폴더를 서버 없이 파일(file://)로 열면 브라우저가 그림 넣은 캔버스 저장을 막는다 → 카드 그림만 빼고 다시 그림 */
      return toBlob(makeTarotImage(S2, r.slice(1))).catch(function () { return toBlob(makeTarotImage(S2, [])); });
    }).then(function (blob) {
      var file = new File([blob], fname, { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) return navigator.share(kakao ? { files: [file], text: text, title: '오늘의 타로' } : { files: [file] });
      var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = fname; document.body.appendChild(a); a.click(); a.remove();
      if (kakao) return copy(text).then(function () { toast('이미지를 저장하고 글을 복사했어요 · 카톡에 이미지와 함께 붙여 넣으세요'); });
      toast('이미지를 저장했어요');
    }).catch(function (e) { if (e && e.name !== 'AbortError') copy(text).then(function () { toast('공유가 안 돼서 내용을 복사했어요'); }); });
  }
  function tarotText(S2) {
    var nm = tname() || '고객', t = '[오늘의 타로] ' + nm + '님 · ' + T.m + '월 ' + T.d + '일\n\n';
    TT.picks.forEach(function (p, k) { var c = p.card; t += (k + 1) + '. ' + TA.POS[k].k + ' : ' + fullName(c) + ' (' + (p.rev ? '역방향' : '정방향') + ')\n   ' + (p.rev ? c.rv[1] : c.up[1]) + '\n'; });
    return t + '\n✦ ' + S2.one + '\n\n재미로 보는 타로예요 :)';
  }
  async function resetAndShuffle() {
    if (TT.lock) return; TT.lock = true;
    $('tsum').classList.remove('on'); $('reads').innerHTML = '';
    for (var i = 0; i < 4; i++) { $('slab' + i).classList.remove('on'); }
    TT.picks.forEach(function (p) { p.el.classList.remove('flip'); });
    await wait(TT.picks.length ? 450 : 0);
    TT.cards.forEach(function (el, i) { el.classList.remove('sp', 'picked', 'dim', 'glow'); el.style.zIndex = ''; el.removeAttribute('data-k'); el.style.transitionDuration = '.5s'; setT(el, stackPos(i)); });
    await wait(520);
    TT.cards.forEach(function (el) { var fc = el.querySelector('.fc'); el.style.transitionDuration = ''; fc.innerHTML = ''; fc.className = 'fc face'; fc.removeAttribute('role'); fc.removeAttribute('aria-label'); });
    TT.picks = []; TT.phase = 'idle'; TT.lock = false;
    shuffle();
  }

  route();
})();
````

## js/fortune-text.js

````js
/* 오늘의 운세 v2 · 2026-10-29 (사주팔자·타로) · 세일즈혁신TF · 빌드: fortune/build_unse.py --web */
/* 사주 운세 문구 표 window.NZ_FTEXT */
window.NZ_FTEXT = {"head": {"비견": ["어깨를 나란히 할 동료가 나타나는 날, 함께하면 두 배로 가벼워져요", "내 페이스대로 밀고 가도 좋은 날, 뚝심이 빛나요", "닮은 사람과 마음이 통하는 날, 먼저 손 내밀어 보세요"], "겁재": ["승부욕이 살아나는 날, 오늘 목표는 평소보다 한 칸 높게", "에너지가 넘치는 날, 혼자 다 하려 말고 나눠 들면 더 멀리 가요", "속도가 붙는 날, 결정은 빠르게 · 지갑은 천천히"], "식신": ["말 한마디에 복이 붙는 날, 맛있는 대화가 술술 풀려요", "여유와 웃음이 따라오는 날, 좋아하는 일에 시간을 써 보세요", "손대는 일마다 결과물이 보이는 날, 작은 성과를 즐기세요"], "상관": ["아이디어가 반짝이는 날, 떠오른 생각은 바로 메모!", "표현력이 최고조인 날, 하고 싶던 말을 부드럽게 꺼내 보세요", "틀을 살짝 벗어나면 길이 보이는 날, 새로운 방식이 통해요"], "편재": ["뜻밖의 기회가 굴러오는 날, 넓게 연락할수록 운이 커져요", "발이 넓어지는 날, 오랜만의 연락이 반가운 소식으로 돌아와요", "움직이는 만큼 열매가 맺히는 날, 바깥 일정이 행운의 열쇠"], "정재": ["차곡차곡 쌓이는 날, 꾸준히 해 온 일이 보답받아요", "계산이 딱딱 맞아떨어지는 날, 꼼꼼함이 최고의 무기", "알뜰한 선택이 빛나는 날, 작은 약속을 지키면 큰 신뢰로"], "편관": ["도전 과제가 찾아오는 날, 피하지 않으면 실력이 한 뼘 자라요", "긴장감이 집중력으로 바뀌는 날, 어려운 일부터 먼저!", "책임감이 돋보이는 날, 끝까지 해내는 모습에 박수가 쏟아져요"], "정관": ["인정받는 날, 원칙대로 한 일이 좋은 평가로 돌아와요", "신뢰가 쌓이는 날, 단정한 태도가 최고의 명함", "질서가 잡히는 날, 미뤄 둔 정리를 끝내기 딱 좋아요"], "편인": ["직감이 날카로운 날, 첫 느낌을 믿어 보세요", "배우는 재미가 큰 날, 새로운 정보가 쏙쏙 들어와요", "혼자만의 시간이 보약인 날, 잠깐의 산책이 아이디어를 줘요"], "정인": ["도움의 손길이 닿는 날, 귀인이 가까이 있어요", "마음이 든든한 날, 배려가 배려로 돌아와요", "공부운이 좋은 날, 오늘 익힌 것은 오래 남아요"]}, "day_rel": {"육합": ["오늘의 기운과 손을 맞잡은 날, 만남이 술술 풀려요", "궁합이 딱 맞는 하루, 부탁하기도 받기도 좋아요"], "반합": ["좋은 기운이 한편이 되어 주는 날, 팀플레이가 잘 맞아요", "흐름을 타기 좋은 날, 주변과 박자를 맞춰 보세요"], "같음": ["익숙한 기운이 반겨 주는 날, 평소 하던 대로가 정답", "편안한 하루, 내 스타일 그대로 가도 좋아요"], "무난": ["잔잔하고 무난한 흐름, 계획한 대로 차근차근", "특별한 굴곡 없는 하루, 기본기가 빛나요"], "파": ["작은 변경이 생길 수 있는 날, 일정은 한 번 더 확인", "계획이 살짝 바뀌어도 괜찮아요, 플랜 B가 더 좋을 수도"], "해": ["말의 온도에 신경 쓰면 좋은 날, 부드럽게가 정답", "오해는 웃으며 풀기, 한 박자 쉬고 대답해요"], "원진": ["괜히 서운할 수 있는 날, 먼저 웃으면 분위기가 바뀌어요", "감정보다 사실을 먼저, 그러면 술술 풀려요"], "형": ["꼼꼼함이 필요한 날, 서류와 숫자는 두 번 확인", "급할수록 돌아가는 날, 천천히 가면 오히려 빨라요"], "충": ["기운이 활발하게 움직이는 날, 새 길이 열리기도 해요", "변화가 많은 날, 서두르기보다 한 번 더 확인하면 기회로"]}, "tti_rel": {"육합": "{a}띠와 오늘 {b}날은 찰떡궁합, 만남운이 좋아요", "반합": "{a}띠에게 {b}날은 든든한 지원군 같은 날", "같음": "{a}띠의 날! 오늘은 내가 주인공", "무난": "{a}띠와 {b}날은 무난한 사이, 편안하게 흘러가요", "파": "{a}띠에게 {b}날은 변수가 있는 날, 유연하게", "해": "{a}띠는 오늘 말을 아끼면 더 좋아요", "원진": "{a}띠는 오늘 마음의 여유가 행운의 열쇠", "형": "{a}띠는 오늘 꼼꼼함이 행운을 불러요", "충": "{a}띠와 {b}날은 정반대 기운, 활동적으로 움직이면 오히려 길해요"}, "bal": {"채움": "내 사주에 없던 {e}의 기운이 들어오는 날, 빈칸이 채워져요", "보통": "{e}의 기운이 알맞게 더해지는 날, 균형이 좋아요", "넘침": "{e}의 기운이 넘치는 날, 과유불급만 기억하세요"}, "tip": {"비견": ["요즘 같이 운동하거나 취미 함께하시는 분 계세요?", "고객님 같은 분이 주변에 많으면 든든하시겠어요"], "겁재": ["요즘 가장 의욕 나는 일이 뭐예요?", "올해 꼭 이루고 싶은 목표 하나만 꼽으면요?"], "식신": ["요즘 맛있게 드신 거 있으세요? 추천 받고 싶어요", "주말에 제일 즐거운 시간은 언제세요?"], "상관": ["요즘 새로 시작하신 거 있으세요?", "고객님 아이디어 듣는 게 늘 재미있어요"], "편재": ["요즘 다녀오신 곳 중에 좋았던 데 있으세요?", "새로 알게 된 분들 많으셨죠? 바쁘셨겠어요"], "정재": ["요즘 꾸준히 하고 계신 습관 있으세요?", "가계부나 계획 세우시는 편이세요? 비결 궁금해요"], "편관": ["요즘 제일 신경 쓰이는 일 있으세요? 들어 드릴게요", "바쁜 시기 잘 버티고 계신 비결이 뭐예요?"], "정관": ["요즘 일은 어떠세요? 인정받으실 일 많으시죠", "가족분들은 다들 잘 지내시죠?"], "편인": ["요즘 관심 가는 분야 있으세요?", "혼자만의 시간은 어떻게 보내세요?"], "정인": ["요즘 고마웠던 분 있으세요?", "부모님은 건강하시죠? 안부 여쭤요"]}, "keys": {"비견": ["동료", "뚝심", "협력"], "겁재": ["도전", "속도", "승부"], "식신": ["여유", "미식", "결과물"], "상관": ["아이디어", "표현", "변화"], "편재": ["기회", "인맥", "외출"], "정재": ["꾸준함", "신뢰", "절약"], "편관": ["도전", "집중", "책임"], "정관": ["인정", "원칙", "정리"], "편인": ["직감", "배움", "휴식"], "정인": ["귀인", "배려", "공부"]}};
````

## js/ie-check.js

````js
/* 오늘의 운세 v2 · 2026-10-29 (사주팔자·타로) · 세일즈혁신TF · 빌드: fortune/build_unse.py --web */
/* 익스플로러로 열리면 엣지로 다시 열기 · <head> 에서 가장 먼저 읽는다 */
/* 익스플로러로 열리면 같은 주소를 엣지로 다시 열기 (익스플로러도 읽을 수 있는 옛 문법으로 작성)
   - 엣지로 넘길 때 주소에 ?from=ie 를 붙임 → 회사 설정(IE 모드 목록) 때문에 엣지에서도 다시 익스플로러 방식으로 열리면
     그 표시를 보고 더 넘기지 않고(무한 반복 방지) 크롬용 주소 복사 안내를 보여 줌
   - 정상 브라우저로 넘어오면 주소창의 ?from=ie 는 지움 */
(function () {
  var ua = navigator.userAgent || '';
  var isIE = !!document.documentMode || ua.indexOf('MSIE ') > -1 || ua.indexOf('Trident/') > -1;
  var href = location.href, hash = location.hash || '', base = hash ? href.substring(0, href.length - hash.length) : href;
  var flag = /[?&]from=ie(?=&|$)/, plain = base.replace(flag, '').replace(/^([^?]*)&/, '$1?');
  if (!isIE) { if (flag.test(base) && window.history && history.replaceState) { try { history.replaceState(null, '', plain + hash); } catch (e) {} } return; }
  var loop = flag.test(base);
  window.__IE_LOOP = loop;
  window.__PLAIN_URL = plain + hash;
  window.__EDGE_URL = 'microsoft-edge:' + plain + (plain.indexOf('?') > -1 ? '&' : '?') + 'from=ie' + hash;
  document.documentElement.className += ' is-ie' + (loop ? ' ie-loop' : '');
})();
/* 안내 상자(.ie-box)의 단추 연결 · 엣지로 넘기기 : 상자가 그려진 뒤에 실행 */
(function () {
  function wire() {
    if (!window.__EDGE_URL) return;
    var a = document.getElementById('ie-go'), u = document.getElementById('ie-url'), c = document.getElementById('ie-copy');
    if (a) a.href = window.__EDGE_URL;
    if (u) { u.value = window.__PLAIN_URL; u.onclick = function () { u.select(); }; }
    if (c) c.onclick = function () {
      var ok = false;
      try { if (window.clipboardData) ok = window.clipboardData.setData('Text', window.__PLAIN_URL); } catch (e) {}
      if (!ok && u) { u.select(); try { ok = document.execCommand('copy'); } catch (e2) {} }
      c.innerHTML = ok ? '복사했어요 · 크롬 주소창에 붙여 넣으세요' : '위 주소를 선택해 Ctrl+C 로 복사해 주세요';
    };
    /* 안내 화면을 먼저 그린 뒤 엣지로 넘김. 이미 엣지에서 넘어왔는데도 IE 방식이면(IE 모드) 넘기지 않음 */
    if (!window.__IE_LOOP) setTimeout(function () { try { window.location.href = window.__EDGE_URL; } catch (e) {} }, 400);
  }
  if (!window.__EDGE_URL) return;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
})();
````

## js/saju-engine.js

````js
/* 오늘의 운세 v2 · 2026-10-29 (사주팔자·타로) · 세일즈혁신TF · 빌드: fortune/build_unse.py --web */
/* 사주 계산 엔진 window.NZ_SAJU */
/* =====================================================================
   사주(년·월·일주) + 오늘의 운세 엔진 — saju_engine.py 와 같은 규칙 (verify_saju.py 로 전 기간 일치 검사)
   한국 표준시 · 정오 출생 가정 · 년주=입춘 · 월주=12절 · 일주=율리우스일 · 시주는 받지 않음
   문구: window.NZ_FTEXT (fortune_text.py 에서 생성)
   ===================================================================== */
(function () {
  'use strict';
  var STEM = '甲乙丙丁戊己庚辛壬癸', STEM_K = '갑을병정무기경신임계', BR = '子丑寅卯辰巳午未申酉戌亥', BR_K = '자축인묘진사오미신유술해';
  var ANIMAL = ['쥐', '소', '호랑이', '토끼', '용', '뱀', '말', '양', '원숭이', '닭', '개', '돼지'];
  var ANIMAL_E = ['🐭', '🐮', '🐯', '🐰', '🐲', '🐍', '🐴', '🐑', '🐵', '🐔', '🐶', '🐷'];
  var EL = ['목', '화', '토', '금', '수'], EL_H = ['木', '火', '土', '金', '水'];
  var BR_EL = [4, 2, 0, 0, 2, 1, 1, 2, 3, 3, 2, 4];
  var JIE = [[315, 2, '입춘'], [345, 3, '경칩'], [15, 4, '청명'], [45, 5, '입하'], [75, 6, '망종'], [105, 7, '소서'],
             [135, 8, '입추'], [165, 9, '백로'], [195, 10, '한로'], [225, 11, '입동'], [255, 0, '대설'], [285, 1, '소한']];
  var KST = 9 / 24;
  function rnd(x) { return Math.floor(x + 0.5); }
  function mod(a, n) { return ((a % n) + n) % n; }
  function stemEl(s) { return Math.floor(s / 2); }
  function gzIndex(s, b) { for (var i = 0; i < 60; i++) if (i % 10 === s && i % 12 === b) return i; }
  function gz(i) { return STEM[i % 10] + BR[i % 12]; }
  function gzK(i) { return STEM_K[i % 10] + BR_K[i % 12]; }

  function jdFromDate(y, m, d, frac) {
    if (m <= 2) { y -= 1; m += 12; }
    var a = Math.floor(y / 100), b = 2 - a + Math.floor(a / 4);
    return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5 + (frac == null ? 0.5 : frac);
  }
  function sunLon(jd) {
    var T = (jd - 2451545.0) / 36525, R = Math.PI / 180;
    var L0 = 280.46646 + 36000.76983 * T + 0.0003032 * T * T;
    var M = (357.52911 + 35999.05029 * T - 0.0001537 * T * T) * R;
    var C = (1.914602 - 0.004817 * T - 0.000014 * T * T) * Math.sin(M) + (0.019993 - 0.000101 * T) * Math.sin(2 * M) + 0.000289 * Math.sin(3 * M);
    var om = (125.04 - 1934.136 * T) * R;
    return mod(L0 + C - 0.00569 - 0.00478 * Math.sin(om), 360);
  }
  function termJd(year, lon) {
    var days = mod(lon, 360) * 365.2422 / 360, jd = jdFromDate(year, 3, 20, 0.5) + days;
    if (lon >= 285) jd -= 365.2422;
    for (var k = 0; k < 50; k++) {
      var diff = mod(lon - sunLon(jd) + 180, 360) - 180;
      jd += diff * 365.2422 / 360;
      if (Math.abs(diff) < 1e-7) break;
    }
    return jd;
  }
  /* JD(UT) → 한국시 {y,m,d,hh,mm} */
  function jdToKst(jd) {
    var j = jd + 0.5 + KST, Z = Math.floor(j), F = j - Z;
    var a = Math.floor((Z - 1867216.25) / 36524.25), A = Z + 1 + a - Math.floor(a / 4);
    var B = A + 1524, C = Math.floor((B - 122.1) / 365.25), D = Math.floor(365.25 * C), E = Math.floor((B - D) / 30.6001);
    var day = B - D - Math.floor(30.6001 * E) + F, m = E < 14 ? E - 1 : E - 13, y = m > 2 ? C - 4716 : C - 4715, d = Math.floor(day);
    var mins = Math.round((day - d) * 1440);
    return { y: y, m: m, d: d, hh: Math.floor(mins / 60), mm: mins % 60 };
  }
  var cache = {};
  function jieList(year) {
    if (cache[year]) return cache[year];
    var out = [];
    [year - 1, year, year + 1].forEach(function (y) { JIE.forEach(function (j) { var jd = termJd(y, j[0]); out.push({ jd: jd, b: j[1], name: j[2], y: y, kst: jdToKst(jd) }); }); });
    out.sort(function (a, b) { return a.jd - b.jd; });
    return (cache[year] = out);
  }
  /* mins: 출생 시각(분, 한국시). 생략하면 정오(720) 가정 */
  function pillars(y, m, d, mins) {
    var noon = jdFromDate(y, m, d, 0) + (mins == null ? 720 : mins) / 1440 - KST, js = jieList(y), prev = null, next = null, ip = null, today = null;
    js.forEach(function (t) {
      if (t.jd <= noon) prev = t; else if (!next) next = t;
      if (t.name === '입춘' && t.y === y) ip = t;
      if (t.kst.y === y && t.kst.m === m && t.kst.d === d) today = t;
    });
    var sy = noon >= ip.jd ? y : y - 1, ys = mod(sy - 4, 10), yb = mod(sy - 4, 12), mb = prev.b, mi = mod(mb - 2, 12);
    var ms = mod((ys % 5) * 2 + 2 + mi, 10), di = mod(Math.floor(jdFromDate(y, m, d, 0.5) + 49), 60);
    return { y: y, m: m, d: d, sy: sy, ys: ys, yb: yb, ms: ms, mb: mb, ds: di % 10, db: di % 12, di: di, prev: prev, next: next, jieToday: today, noon: noon };
  }
  function daeun(p, male) {
    var yangYear = p.ys % 2 === 0, fwd = (yangYear && male) || (!yangYear && !male);
    var days = fwd ? p.next.jd - p.noon : p.noon - p.prev.jd;
    var n = Math.max(1, Math.min(10, rnd(days / 3)));
    var mi = gzIndex(p.ms, p.mb), list = [];
    for (var k = 1; k <= 10; k++) list.push({ age: n + (k - 1) * 10, i: mod(mi + (fwd ? k : -k), 60) });
    return { fwd: fwd, n: n, list: list };
  }
  function counts(p) {
    var c = [0, 0, 0, 0, 0];
    [p.ys, p.ms, p.ds].forEach(function (s) { c[stemEl(s)]++; });
    [p.yb, p.mb, p.db].forEach(function (b) { c[BR_EL[b]]++; });
    return c;
  }
  var TEN = [['비견', '겁재'], ['식신', '상관'], ['편재', '정재'], ['편관', '정관'], ['편인', '정인']];
  function tenGod(d, o) { return TEN[mod(stemEl(o) - stemEl(d), 5)][(d % 2) === (o % 2) ? 0 : 1]; }
  function pairIn(list, a, b) { return list.some(function (x) { return (x[0] === a && x[1] === b) || (x[0] === b && x[1] === a); }); }
  var SIX = [[0, 1], [2, 11], [3, 10], [4, 9], [5, 8], [6, 7]], SAM = [[8, 0, 4], [2, 6, 10], [5, 9, 1], [11, 3, 7]];
  var HY = [[2, 5], [5, 8], [8, 2], [1, 10], [10, 7], [7, 1], [0, 3]], SELF_HY = [4, 6, 9, 11];
  var HAE = [[0, 7], [1, 6], [2, 5], [3, 4], [8, 11], [9, 10]], WJ = [[0, 7], [1, 6], [2, 9], [3, 8], [4, 11], [5, 10]], PA = [[0, 9], [1, 4], [2, 11], [3, 6], [5, 8], [7, 10]];
  var REL = { '충': -6, '육합': 8, '반합': 6, '형': -4, '원진': -3, '해': -3, '파': -2, '같음': 3, '무난': 0 };
  function brRel(t, p) {
    if (Math.abs(t - p) === 6) return '충';
    if (t !== p && pairIn(SIX, t, p)) return '육합';
    if (t !== p && SAM.some(function (g) { return g.indexOf(t) >= 0 && g.indexOf(p) >= 0; })) return '반합';
    if ((t !== p && pairIn(HY, t, p)) || (t === p && SELF_HY.indexOf(t) >= 0)) return '형';
    if (t !== p && pairIn(WJ, t, p)) return '원진';
    if (t !== p && pairIn(HAE, t, p)) return '해';
    if (t !== p && pairIn(PA, t, p)) return '파';
    if (t === p) return '같음';
    return '무난';
  }
  var TEN_MOD = { '비견': [-2, 6, 4, 6], '겁재': [-5, 3, 6, 4], '식신': [6, 8, 4, 8], '상관': [4, 10, 2, 0], '편재': [10, 5, 6, 2],
    '정재': [12, 3, 5, 4], '편관': [2, -2, 8, -3], '정관': [4, 4, 10, 2], '편인': [-2, 0, 4, 5], '정인': [2, 6, 6, 8] };
  var WEIGHT = [0.3, 0.25, 0.25, 0.2], BASE = 70, LO = 55, HI = 98;
  var COLORS = ['초록', '빨강', '노랑', '흰색', '남색'], COLOR_HEX = ['#2f9e62', '#e0402f', '#e0a800', '#9aa3ad', '#2b4a8b'];
  var NUMBERS = ['3, 8', '2, 7', '5, 10', '4, 9', '1, 6'], DIRS = ['동쪽', '남쪽', '가운데', '서쪽', '북쪽'];
  function fnv(s) { var h = 0x811C9DC5; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function luckyEl(c, ds) {
    var me = stemEl(ds), order = [mod(me + 4, 5), me, mod(me + 1, 5), mod(me + 2, 5), mod(me + 3, 5)], mn = Math.min.apply(null, c);
    return order.filter(function (e) { return c[e] === mn; })[0];
  }
  function pad(n, w) { n = String(n); while (n.length < w) n = '0' + n; return n; }
  function fmt(s, a, b) { return s.replace('{a}', a).replace('{b}', b); }
  function fortune(y, m, d, male, ty, tm, td) {
    var T = window.NZ_FTEXT, p = pillars(y, m, d), t = pillars(ty, tm, td), c = counts(p), god = tenGod(p.ds, t.ds);
    var rDay = brRel(t.db, p.db), rYear = brRel(t.db, p.yb), te = stemEl(t.ds);
    var bal = c[te] === 0 ? 6 : (c[te] >= 3 ? -4 : 2), balK = c[te] === 0 ? '채움' : (c[te] >= 3 ? '넘침' : '보통');
    var key = pad(y, 4) + pad(m, 2) + pad(d, 2) + '|' + (male ? 'M' : 'F') + '|' + pad(ty, 4) + pad(tm, 2) + pad(td, 2), h = fnv(key);
    var sc = [0, 1, 2, 3].map(function (i) {
      var jit = ((h >>> (i * 5)) % 9) - 4;
      return Math.max(LO, Math.min(HI, BASE + TEN_MOD[god][i] + REL[rDay] + rnd(REL[rYear] * 0.6) + bal + jit));
    });
    var total = Math.floor((30 * sc[0] + 25 * sc[1] + 25 * sc[2] + 20 * sc[3] + 50) / 100);  // 가중 평균 반올림을 정수로 (소수 오차 방지)
    var stars = total >= 90 ? 5 : total >= 82 ? 4 : total >= 72 ? 3 : 2, le = luckyEl(c, p.ds);
    function pick(arr, salt) { return arr[(h >>> salt) % arr.length]; }
    return { p: p, t: t, counts: c, god: god, rDay: rDay, rYear: rYear, bal: balK, scores: sc, total: total, stars: stars,
      luckyEl: le, color: COLORS[le], colorHex: COLOR_HEX[le], number: NUMBERS[le], direction: DIRS[le],
      head: pick(T.head[god], 3), dayLine: pick(T.day_rel[rDay], 7), ttiLine: fmt(T.tti_rel[rYear], ANIMAL[p.yb], ANIMAL[t.db]),
      balLine: T.bal[balK].replace('{e}', EL[te]), tip: pick(T.tip[god], 11), keys: T.keys[god], hash: h };
  }
  window.NZ_SAJU = { pillars: pillars, fortune: fortune, daeun: daeun, counts: counts, tenGod: tenGod, brRel: brRel, termJd: termJd, jdToKst: jdToKst,
    gz: gz, gzK: gzK, gzIndex: gzIndex, stemEl: stemEl, STEM: STEM, STEM_K: STEM_K, BR: BR, BR_K: BR_K, ANIMAL: ANIMAL, ANIMAL_E: ANIMAL_E, EL: EL, EL_H: EL_H, BR_EL: BR_EL, COLOR_HEX: COLOR_HEX };
})();
````

## js/tarot-data.js

````js
/* 오늘의 운세 v2 · 2026-10-29 (사주팔자·타로) · 세일즈혁신TF · 빌드: fortune/build_unse.py --web */
/* 타로 78장 데이터 window.NZ_TAROT */
/* =====================================================================
   타로 78장 (라이더-웨이트 순서: 메이저 0~21, 마이너 4수트 × 14)
   카드 한 장 = [한글 이름, 영어 이름, 그림(메이저만), 정방향 키워드, 정방향 풀이, 역방향 키워드, 역방향 풀이]
   ===================================================================== */
(function () {
  'use strict';
  var MAJOR = [
    ['바보', 'The Fool', '🎒', '새 출발·자유·모험', '계산보다 설렘이 앞서는 때예요. 처음 해 보는 일에 가볍게 발을 내디뎌 보세요.', '무모함·준비 부족', '들뜬 마음에 준비가 덜 됐을 수 있어요. 출발 전에 짐을 한 번만 더 챙겨 보세요.'],
    ['마법사', 'The Magician', '✨', '능력·시작·실행력', '필요한 재료는 이미 손에 있어요. 생각만 하던 일을 오늘 바로 시작해도 좋아요.', '말뿐·재능 낭비', '말이 행동보다 앞서기 쉬워요. 약속은 작게, 실행은 확실하게 해 보세요.'],
    ['여사제', 'The High Priestess', '📖', '직관·지혜·침묵', '답은 바깥보다 내 안에 있어요. 서두르지 말고 조용히 느낌을 믿어 보세요.', '숨김·혼란', '중요한 정보가 아직 다 드러나지 않았어요. 확인되지 않은 말에는 귀를 덜 기울이세요.'],
    ['여황제', 'The Empress', '🌾', '풍요·돌봄·결실', '정성 들인 일이 풍성하게 자라는 때예요. 나와 주변을 넉넉히 돌봐 주세요.', '과잉·의존', '남을 챙기느라 나를 놓치고 있진 않나요? 돌봄의 방향을 나에게도 돌려 보세요.'],
    ['황제', 'The Emperor', '👑', '안정·책임·리더십', '질서와 원칙이 힘이 되는 날이에요. 계획을 세우고 앞장서 이끌어 보세요.', '고집·통제', '내 방식만 고집하면 사람이 멀어져요. 한 걸음 물러서 의견을 들어 보세요.'],
    ['교황', 'The Hierophant', '🔑', '가르침·신뢰·전통', '검증된 방법과 좋은 조언자가 길을 열어 줘요. 배우는 자세가 행운을 불러요.', '틀에 갇힘·반발', '익숙한 규칙이 오히려 발목을 잡을 수 있어요. 나에게 맞는 방식을 찾아보세요.'],
    ['연인', 'The Lovers', '💞', '사랑·조화·선택', '마음이 통하는 인연과 좋은 선택이 함께해요. 진심을 담아 표현해 보세요.', '엇갈림·망설임', '마음과 행동이 엇갈리기 쉬워요. 정말 원하는 것이 무엇인지 먼저 정해 보세요.'],
    ['전차', 'The Chariot', '🏇', '전진·승리·의지', '목표를 향해 힘차게 나아갈 때예요. 흔들리지 않는 의지가 승리를 가져와요.', '방향 상실·과속', '속도에 비해 방향이 흐릿해요. 잠시 멈춰 목적지를 다시 확인해 보세요.'],
    ['힘', 'Strength', '🦁', '용기·인내·부드러운 힘', '부드러움이 거친 상황을 다스려요. 조급해하지 않는 인내가 가장 큰 힘이에요.', '자신감 하락·감정 폭발', '스스로를 믿는 마음이 약해졌어요. 감정을 다그치기보다 다독여 주세요.'],
    ['은둔자', 'The Hermit', '🏮', '성찰·탐구·홀로서기', '혼자만의 시간이 답을 비춰 줘요. 소음에서 잠시 떨어져 생각을 정리해 보세요.', '고립·외로움', '너무 오래 혼자 버티고 있어요. 믿을 만한 사람에게 먼저 손을 내밀어 보세요.'],
    ['운명의 수레바퀴', 'Wheel of Fortune', '☸️', '전환점·행운·흐름', '흐름이 바뀌는 순간이 찾아와요. 들어오는 기회를 놓치지 말고 올라타세요.', '엇박자·지연', '타이밍이 살짝 어긋나 있어요. 억지로 돌리기보다 다음 흐름을 기다려 보세요.'],
    ['정의', 'Justice', '⚖️', '공정·균형·책임', '뿌린 만큼 거두는 때예요. 원칙대로 판단하면 결과도 정직하게 돌아와요.', '불공정·편향', '한쪽 말만 듣고 판단하기 쉬워요. 결정 전에 양쪽 사정을 모두 살펴보세요.'],
    ['매달린 사람', 'The Hanged Man', '🙃', '관점 전환·기다림·내려놓음', '거꾸로 보면 새 답이 보여요. 지금의 멈춤은 손해가 아니라 준비 시간이에요.', '헛된 희생·정체', '의미 없는 기다림이 길어지고 있어요. 붙잡고 있던 것을 놓아줄 때일 수 있어요.'],
    ['죽음', 'Death', '🥀', '끝과 시작·변화·정리', '한 장이 끝나야 다음 장이 열려요. 낡은 것을 정리하면 새 자리가 생겨요.', '변화 거부·미련', '끝난 일을 붙잡고 있어 다음이 오지 않아요. 아쉬움은 인사로 마무리해 보세요.'],
    ['절제', 'Temperance', '🏺', '조화·중용·회복', '서로 다른 것이 섞여 좋은 결과를 내요. 적당한 속도와 균형이 가장 좋아요.', '불균형·과함', '한쪽으로 지나치게 쏠려 있어요. 일·휴식·관계의 비율을 다시 맞춰 보세요.'],
    ['악마', 'The Devil', '⛓️', '유혹·집착·욕망', '달콤한 유혹이 가까이 있어요. 원하는 것을 솔직히 인정하되 끌려가지는 마세요.', '해방·끊어냄', '나를 묶던 습관이나 관계에서 벗어날 힘이 생겨요. 끊어낼 것은 지금 끊으세요.'],
    ['탑', 'The Tower', '⚡', '급변·깨달음·무너짐', '예상 밖 일이 낡은 틀을 흔들어요. 놀라더라도 그 덕에 진짜가 드러나요.', '위기 모면·불안', '큰 충격은 피했지만 불씨가 남아 있어요. 미뤄 둔 문제를 지금 손봐 두세요.'],
    ['별', 'The Star', '⭐', '희망·치유·영감', '어두운 뒤에 빛이 들어요. 바라는 것을 마음에 품고 꾸준히 걸어가세요.', '실망·의욕 저하', '기대가 꺾여 기운이 빠졌어요. 작은 목표 하나부터 다시 반짝이게 해 보세요.'],
    ['달', 'The Moon', '🌙', '불안·상상·직감', '보이는 것이 전부가 아니에요. 막연한 걱정은 줄이고 직감은 메모해 두세요.', '오해 풀림·안개 걷힘', '헷갈리던 상황이 서서히 선명해져요. 숨은 사실이 드러나며 마음이 가벼워져요.'],
    ['태양', 'The Sun', '☀️', '성공·기쁨·활력', '밝은 기운이 가득한 최고의 카드예요. 자신 있게 드러내면 좋은 일이 따라와요.', '잠깐의 흐림·과신', '좋은 흐름이지만 조금 늦게 와요. 자만만 조심하면 결국 해가 떠요.'],
    ['심판', 'Judgement', '📯', '부활·결단·소식', '다시 일어설 신호가 울려요. 미뤄 둔 결정을 내리면 새 기회가 열려요.', '자책·미루기', '지난 일로 자신을 너무 탓하고 있어요. 교훈만 남기고 다음으로 넘어가세요.'],
    ['세계', 'The World', '🌍', '완성·성취·통합', '한 바퀴를 멋지게 마무리하는 때예요. 이룬 것을 축하하고 다음 무대를 준비하세요.', '마무리 부족·미완', '거의 다 왔는데 마지막 한 조각이 남았어요. 끝맺음까지 챙기면 완성돼요.']
  ];
  /* 수트: 이름, 원소, 다루는 영역 */
  var SUITS = [
    { k: 'Wands', ko: '완드', el: '불', area: '열정·일·도전' },
    { k: 'Cups', ko: '컵', el: '물', area: '감정·사랑·관계' },
    { k: 'Swords', ko: '소드', el: '공기', area: '생각·판단·갈등' },
    { k: 'Pentacles', ko: '펜타클', el: '흙', area: '돈·현실·건강' }
  ];
  var RANK = ['에이스', '2', '3', '4', '5', '6', '7', '8', '9', '10', '시종', '기사', '여왕', '왕'];
  var RANK_E = ['Ace', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Page', 'Knight', 'Queen', 'King'];
  /* [정방향 키워드, 정방향 풀이, 역방향 키워드, 역방향 풀이] 수트별 14장 */
  var MINOR = [
    [ // 완드 (불)
      ['열정의 불씨·새 계획', '가슴 뛰는 아이디어가 생겨요. 망설이지 말고 첫 불을 붙여 보세요.', '의욕 부족·지연', '시작하려는 마음이 자꾸 식어요. 작게라도 오늘 한 걸음을 떼 보세요.'],
      ['계획·넓은 시야', '더 큰 그림을 그릴 때예요. 지금 자리에서 다음 목표를 설계해 보세요.', '두려움·우물쭈물', '익숙한 곳을 떠나기가 두려워요. 계획을 종이에 적으면 용기가 생겨요.'],
      ['확장·기다리던 소식', '뿌려 둔 노력이 멀리서 돌아와요. 시야를 넓히면 기회가 보여요.', '지연·기대 어긋남', '기다리던 일이 늦어지고 있어요. 다른 길도 함께 열어 두세요.'],
      ['축하·안정된 기반', '함께 웃을 일이 생겨요. 이룬 것을 사람들과 나누면 기쁨이 커져요.', '불안정·어수선함', '기반이 살짝 흔들려요. 가까운 사람과의 관계부터 챙겨 보세요.'],
      ['경쟁·의견 충돌', '의견이 부딪히지만 그 덕에 더 좋은 답이 나와요. 건강한 경쟁을 즐겨 보세요.', '갈등 회피·소모전', '피하기만 하면 다툼이 길어져요. 핵심만 짚어 짧게 정리해 보세요.'],
      ['승리·인정', '노력이 인정받고 박수받는 날이에요. 자신감 있게 앞에 서 보세요.', '자만·인정 부족', '기대만큼 알아주지 않아 서운할 수 있어요. 결과로 차분히 보여 주세요.'],
      ['지켜냄·소신', '내 자리를 지킬 힘이 있어요. 흔들려도 소신을 지키면 이겨요.', '지침·포기 직전', '혼자 막느라 지쳤어요. 다 지키려 하지 말고 중요한 것만 남기세요.'],
      ['빠른 진행·소식', '일이 빠르게 풀리고 연락이 몰려와요. 흐름이 왔을 때 속도를 내세요.', '지연·성급함', '서두를수록 엉켜요. 순서를 정해 하나씩 처리해 보세요.'],
      ['끈기·마지막 고비', '거의 다 왔어요. 지친 만큼 끝이 가까우니 조금만 더 버텨 보세요.', '방어적·의심', '상처가 남아 마음을 닫고 있어요. 모두가 적은 아니니 경계를 조금 풀어 보세요.'],
      ['책임감·무거운 짐', '맡은 일이 많아 어깨가 무거워요. 해낼 수 있지만 나눌 줄도 알아야 해요.', '과부하·내려놓기', '짐이 한계를 넘었어요. 꼭 내가 해야 할 일만 남기고 덜어내세요.'],
      ['호기심·좋은 소식', '새로운 배움과 반가운 소식이 와요. 궁금한 건 바로 물어보세요.', '산만함·소식 지연', '관심이 여기저기 흩어져요. 하나를 골라 끝까지 파 보세요.'],
      ['추진력·모험', '거침없이 달려갈 기운이에요. 새로운 도전에 몸을 던져 보세요.', '충동·조급함', '앞뒤 재지 않고 뛰어들기 쉬워요. 한 번 숨 고르고 출발하세요.'],
      ['자신감·매력', '밝은 에너지로 사람을 끌어당겨요. 당당한 태도가 좋은 기회를 불러요.', '질투·예민함', '작은 일에 마음이 날카로워져요. 나를 다른 사람과 비교하지 마세요.'],
      ['비전·리더십', '큰 그림을 보고 사람을 이끄는 날이에요. 결정을 미루지 말고 방향을 제시하세요.', '독단·성급한 결정', '혼자 정하고 밀어붙이기 쉬워요. 결정 전 한 사람에게만 더 물어보세요.']
    ],
    [ // 컵 (물)
      ['새 감정·사랑의 시작', '마음이 차오르는 새로운 감정이 시작돼요. 따뜻한 마음을 숨기지 마세요.', '감정 억누름·공허', '마음을 꾹 누르고 있어요. 솔직한 감정을 한 사람에게라도 털어놓아 보세요.'],
      ['교감·좋은 짝', '마음이 통하는 사람과 연결돼요. 서로 주고받는 관계가 힘이 돼요.', '엇갈림·불균형', '주는 마음과 받는 마음의 무게가 달라요. 서운함은 쌓기 전에 말해 보세요.'],
      ['축하·우정', '함께 웃을 일이 생기는 날이에요. 친구와 기쁨을 나누면 두 배가 돼요.', '과한 즐거움·뒷말', '즐거움이 지나치거나 뒷말이 생길 수 있어요. 적당한 선을 지켜 주세요.'],
      ['권태·무관심', '지금 가진 것에 시큰둥해요. 이미 곁에 있는 기회를 다시 들여다보세요.', '새 의욕·관심 회복', '멈춰 있던 마음이 다시 움직여요. 새로운 제안에 귀를 열어 보세요.'],
      ['상실감·아쉬움', '잃은 것에 마음이 머물러요. 뒤돌아보면 아직 남은 잔이 있어요.', '회복·용서', '아픔이 서서히 아물어요. 지난 일을 용서하면 새 잔을 채울 수 있어요.'],
      ['추억·순수한 마음', '따뜻한 옛 인연이나 추억이 힘이 돼요. 순수한 마음으로 다가가 보세요.', '과거 집착', '지난날에 너무 머물러 있어요. 추억은 간직하고 시선은 앞으로 두세요.'],
      ['선택지·상상', '여러 가능성이 눈앞에 펼쳐져요. 꿈과 현실을 구분해 하나를 골라 보세요.', '환상 깨짐·현실 직시', '막연한 기대가 걷히고 현실이 보여요. 오히려 선택이 쉬워져요.'],
      ['떠남·더 깊은 것 찾기', '채워지지 않는 마음을 따라 새 길을 찾아요. 떠나는 용기도 성장이에요.', '망설임·회피', '떠날지 머물지 정하지 못해요. 마음이 진짜 원하는 쪽을 물어보세요.'],
      ['소원 성취·만족', '바라던 일이 이뤄지는 소원 카드예요. 오늘의 만족을 마음껏 누리세요.', '욕심·허전함', '가져도 채워지지 않는 느낌이에요. 진짜 바라는 것이 무엇인지 돌아보세요.'],
      ['가족·행복한 관계', '사랑하는 사람들과 행복이 가득해요. 가족과 함께하는 시간이 큰 복이에요.', '관계 갈등·가치 차이', '가까운 사이에서 생각 차이가 보여요. 정답보다 공감부터 건네 보세요.'],
      ['다정한 소식·감수성', '설레는 연락이나 다정한 제안이 와요. 순수한 호기심으로 받아 보세요.', '감정 기복·미성숙', '기분에 따라 말이 앞서기 쉬워요. 하룻밤 자고 답해도 늦지 않아요.'],
      ['로맨스·제안', '마음을 담은 제안이 찾아와요. 진심을 행동으로 보여 주면 통해요.', '변덕·과장', '달콤한 말에 비해 행동이 부족할 수 있어요. 말보다 실천을 지켜보세요.'],
      ['공감·따뜻한 직관', '상대의 마음을 잘 읽는 날이에요. 들어 주는 것만으로도 큰 힘이 돼요.', '감정 소진·지나친 이입', '남의 감정까지 떠안아 지쳤어요. 내 마음부터 먼저 돌봐 주세요.'],
      ['감정 조절·포용', '흔들림 없이 상황을 감싸 안아요. 침착한 태도가 신뢰를 얻어요.', '감정 억압·변덕', '참아 온 감정이 엉뚱한 곳에서 터질 수 있어요. 적당히 풀어 주세요.']
    ],
    [ // 소드 (공기)
      ['명쾌함·돌파', '머릿속이 맑아지고 핵심이 보여요. 결단이 필요한 일을 오늘 정리하세요.', '혼란·날 선 말', '생각이 엉키고 말이 날카로워져요. 결론은 하루 미뤄도 괜찮아요.'],
      ['고민·보류', '두 선택 사이에서 눈을 가리고 있어요. 정보를 더 모으면 답이 보여요.', '결정 압박·정보 공개', '더는 미루기 어려워요. 드러난 사실을 바탕으로 마음을 정하세요.'],
      ['마음의 상처·이별', '아픈 말이나 서운함이 남아요. 감정을 인정해야 회복이 시작돼요.', '회복·용서', '상처가 아물어 가요. 털어놓고 정리하면 한결 가벼워져요.'],
      ['휴식·재충전', '잠시 멈추고 쉬어야 할 때예요. 충분히 쉬어야 다음 판단이 정확해요.', '복귀·조바심', '쉬는 동안 조바심이 났어요. 천천히 일상의 속도를 되찾으세요.'],
      ['갈등·이기고도 손해', '이겨도 남는 게 없는 다툼이 보여요. 꼭 이겨야 하는 싸움인지 따져 보세요.', '화해·후회', '다툼 뒤에 후회가 남아요. 먼저 사과하면 관계가 회복돼요.'],
      ['이동·나아짐', '힘든 곳을 떠나 잔잔한 곳으로 가요. 상황은 천천히 나아지고 있어요.', '정체·미련', '떠나야 하는데 발이 떨어지지 않아요. 짐을 줄이면 움직일 수 있어요.'],
      ['전략·눈치', '정면보다 꾀가 통하는 날이에요. 내 패를 다 보여 주지 마세요.', '들통·양심', '숨긴 것이 드러날 수 있어요. 솔직하게 털어놓는 편이 오히려 나아요.'],
      ['제약·스스로 묶임', '답답한 상황에 갇힌 느낌이에요. 생각보다 매듭은 느슨하니 한 가지만 풀어 보세요.', '해방·새 관점', '스스로 묶었던 생각에서 벗어나요. 관점을 바꾸니 길이 보여요.'],
      ['걱정·불면', '걱정이 꼬리를 물어요. 머릿속 걱정을 종이에 적으면 크기가 줄어들어요.', '불안 완화·희망', '가장 어두운 밤이 지나가요. 걱정했던 일은 생각보다 작게 끝나요.'],
      ['바닥·완전한 끝', '더 내려갈 곳이 없는 끝이에요. 끝은 곧 새벽의 시작이에요.', '회복의 시작', '바닥을 찍고 올라오기 시작해요. 천천히 다시 일어나면 돼요.'],
      ['관찰·호기심', '눈과 귀를 열고 정보를 모으는 날이에요. 질문이 많을수록 유리해요.', '험담·경솔함', '확인 안 된 말이 퍼지기 쉬워요. 말하기 전에 사실부터 확인하세요.'],
      ['돌진·추진', '목표를 향해 단숨에 달려가요. 빠른 판단이 성과를 만들어요.', '무모함·충돌', '속도가 앞서 사람과 부딪혀요. 상대의 속도도 살펴 주세요.'],
      ['냉철·독립', '감정에 휘둘리지 않는 판단력이 빛나요. 할 말은 분명하게 하세요.', '차가움·냉소', '말이 너무 차갑게 전해질 수 있어요. 한마디의 온기를 더해 보세요.'],
      ['권위·논리', '논리와 원칙으로 문제를 풀어요. 공정한 판단이 신뢰를 얻어요.', '독선·권위 남용', '옳다는 확신이 고집이 될 수 있어요. 반대 의견에도 기회를 주세요.']
    ],
    [ // 펜타클 (흙)
      ['새 기회·재물의 씨앗', '돈이나 일과 관련된 좋은 기회가 와요. 현실적인 첫 투자를 해 보세요.', '놓친 기회·낭비', '눈앞의 기회를 놓치기 쉬워요. 지출 계획부터 꼼꼼히 세우세요.'],
      ['균형·저글링', '여러 일을 동시에 굴리는 솜씨가 좋아요. 유연하게 우선순위를 바꿔 보세요.', '과부하·우왕좌왕', '벌려 놓은 일이 많아 손이 모자라요. 하나를 내려놓아야 균형이 잡혀요.'],
      ['협업·실력 인정', '함께 일하면 결과가 좋아요. 내 실력이 제대로 인정받는 날이에요.', '손발 안 맞음', '역할이 겹쳐 엇박자가 나요. 누가 무엇을 맡을지 먼저 정하세요.'],
      ['저축·지킴', '모으고 지키는 힘이 강해요. 알뜰함이 안정감을 줘요.', '인색함·집착', '너무 움켜쥐면 흐름이 막혀요. 필요한 곳에는 기꺼이 쓰세요.'],
      ['어려움·도움 요청', '형편이 빠듯하게 느껴져요. 혼자 버티지 말고 도움을 청하면 길이 있어요.', '회복·도움의 손길', '힘든 시기가 끝나 가요. 주변에서 내민 손을 잡아 보세요.'],
      ['나눔·주고받음', '베푼 만큼 돌아오는 흐름이에요. 기분 좋게 나누면 복이 돌아와요.', '불공정한 거래', '주고받는 균형이 맞지 않아요. 조건을 분명히 하고 거래하세요.'],
      ['인내·성장 대기', '심어 둔 것이 자라는 중이에요. 조급해하지 말고 결실을 기다리세요.', '조바심·헛수고', '결과가 안 보여 지쳤어요. 방법을 점검하고 다시 가꿔 보세요.'],
      ['성실·기술 연마', '꾸준히 갈고닦는 노력이 실력이 돼요. 반복이 곧 경쟁력이에요.', '지루함·대충', '같은 일이 지겨워 대충하기 쉬워요. 작은 목표로 재미를 더해 보세요.'],
      ['여유·자립', '스스로 일군 결실을 누리는 때예요. 나를 위한 작은 사치도 괜찮아요.', '과소비·의존', '보여 주기 위한 지출을 조심하세요. 자립의 기반을 먼저 다지세요.'],
      ['부·가족의 안정', '오래 이어질 재물과 가족의 안정이 보여요. 장기적인 계획이 빛나요.', '재산 갈등', '돈 문제로 가까운 사이에 금이 갈 수 있어요. 문서와 약속을 명확히 하세요.'],
      ['배움·성실한 시작', '새로운 공부나 실무를 배우기 좋은 날이에요. 기초부터 차근차근 쌓으세요.', '게으름·계획만', '계획만 세우고 시작을 미뤄요. 오늘 10분이라도 손을 대 보세요.'],
      ['꾸준함·책임', '느리지만 확실하게 해내요. 맡은 일을 끝까지 책임지면 신뢰가 쌓여요.', '정체·지나친 신중', '너무 조심스러워 진도가 안 나가요. 완벽보다 완료를 목표로 하세요.'],
      ['실속·살림', '실속 있게 챙기고 돌보는 힘이 커요. 생활의 작은 정리가 운을 높여요.', '일과 삶의 불균형', '일이나 살림 한쪽에 치우쳐 있어요. 나를 위한 시간도 챙기세요.'],
      ['성공·풍요', '안정된 성취와 재물운이 함께해요. 쌓아 온 경험이 든든한 자산이에요.', '물질 집착·고집', '돈과 성과에만 마음이 쏠려요. 사람과의 관계도 함께 챙기세요.']
    ]
  ];
  var deck = [];
  MAJOR.forEach(function (c, i) { deck.push({ id: i, major: true, no: i, ko: c[0], en: c[1], sym: c[2], up: [c[3], c[4]], rv: [c[5], c[6]] }); });
  SUITS.forEach(function (s, si) {
    MINOR[si].forEach(function (c, r) {
      deck.push({ id: deck.length, major: false, suit: si, rank: r, ko: s.ko + ' ' + RANK[r], en: RANK_E[r] + ' of ' + s.k, up: [c[0], c[1]], rv: [c[2], c[3]] });
    });
  });
  window.NZ_TAROT = {
    deck: deck, SUITS: SUITS, RANK: RANK,
    ROMAN: ['0', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII', 'XVIII', 'XIX', 'XX', 'XXI'],
    /* 4장 스프레드 자리 */
    POS: [
      { k: '지금의 나', d: '지금 내 마음과 상황' },
      { k: '걸림돌', d: '조심하거나 넘어야 할 것' },
      { k: '도움의 열쇠', d: '힘이 되는 태도·사람' },
      { k: '다가올 흐름', d: '이대로 가면 펼쳐질 모습' }
    ],
    /* 수트별 요약 문장 (가장 많이 나온 수트) */
    SUIT_SUM: [
      '불의 기운(완드)이 강해요. 일과 도전에 에너지가 몰리는 시기라 먼저 움직이는 쪽이 유리해요.',
      '물의 기운(컵)이 강해요. 마음과 관계가 중심이 되는 시기라 진심 어린 대화가 운을 열어요.',
      '공기의 기운(소드)이 강해요. 생각이 많아지는 시기라 말과 판단을 한 번 더 다듬으면 좋아요.',
      '흙의 기운(펜타클)이 강해요. 돈과 현실 문제가 중심이라 꼼꼼한 계획이 결실로 이어져요.'
    ],
    /* 생년월일 숫자를 모두 더해 1~21(22는 0 바보)로 줄인 '탄생 카드' */
    birthCard: function (y, m, d) {
      var s = String(y) + String(m) + String(d), n = 0, i;
      for (i = 0; i < s.length; i++) n += +s.charAt(i);
      while (n > 22) { var t = 0, q = String(n); for (i = 0; i < q.length; i++) t += +q.charAt(i); n = t; }
      return n === 22 ? 0 : n;
    }
  };
})();
````

## js/tarot-img.js

````js
/* 오늘의 운세 v2 · 2026-10-29 (사주팔자·타로) · 세일즈혁신TF · 빌드: fortune/build_unse.py --web */
/* 타로 카드 그림 주소 window.NZ_TAROT_IMG (deck id 0~77 → img/tarot/00~77.webp) */
window.NZ_TAROT_IMG = (function () { var a = [], i; for (i = 0; i < 78; i++) a.push('img/tarot/' + (i < 10 ? '0' : '') + i + '.webp'); return a; })();
````
