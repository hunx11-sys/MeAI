/* 오늘의 운세 v2 · 2026-10-29 (사주팔자·타로) · 세일즈혁신TF · 빌드: fortune/build_unse.py --web */
/* 타로 카드 그림 주소 window.NZ_TAROT_IMG (deck id 0~77 → img/tarot/00~77.webp) */
window.NZ_TAROT_IMG = (function () { var a = [], i; for (i = 0; i < 78; i++) a.push('img/tarot/' + (i < 10 ? '0' : '') + i + '.webp'); return a; })();
