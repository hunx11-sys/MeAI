/* 오늘의 운세 v2 · 2026-10-29 (사주팔자·타로) · 세일즈혁신TF · 빌드: fortune/build_unse.py --web */
/* 사주 계산 엔진 window.NZ_SAJU */
/* =====================================================================
   사주(년·월·일주) + 오늘의 운세 엔진 — saju_engine.py 와 같은 규칙 (verify_saju.py 로 전 기간 일치 검사)
   한국 표준시 · 정오 출생 가정 · 년주=입춘 · 월주=12절 · 일주=율리우스일 · 시주는 받지 않음
   문구: window.NZ_FTEXT (fortune_text.py 에서 생성)
   ===================================================================== */
(function () {
  'use strict';
  var STEM = '甲乙丙丁戊己庚辛壬癸', STEM_K = '갑을병정무기경신임계', BR = '子丑寅卯辰巳午未申酉戌亥', BR_K = '자축인묘진사오미신유술해';
  var ANIMAL = ['쥐', '소', '호랑이', '토끼', '용', '뱀', '말', '양', '원숭이', '닭', '개', '돼지'];
  var ANIMAL_E = ['🐭', '🐮', '🐯', '🐰', '🐲', '🐍', '🐴', '🐑', '🐵', '🐔', '🐶', '🐷'];
  var EL = ['목', '화', '토', '금', '수'], EL_H = ['木', '火', '土', '金', '水'];
  var BR_EL = [4, 2, 0, 0, 2, 1, 1, 2, 3, 3, 2, 4];
  var JIE = [[315, 2, '입춘'], [345, 3, '경칩'], [15, 4, '청명'], [45, 5, '입하'], [75, 6, '망종'], [105, 7, '소서'],
             [135, 8, '입추'], [165, 9, '백로'], [195, 10, '한로'], [225, 11, '입동'], [255, 0, '대설'], [285, 1, '소한']];
  var KST = 9 / 24;
  function rnd(x) { return Math.floor(x + 0.5); }
  function mod(a, n) { return ((a % n) + n) % n; }
  function stemEl(s) { return Math.floor(s / 2); }
  function gzIndex(s, b) { for (var i = 0; i < 60; i++) if (i % 10 === s && i % 12 === b) return i; }
  function gz(i) { return STEM[i % 10] + BR[i % 12]; }
  function gzK(i) { return STEM_K[i % 10] + BR_K[i % 12]; }

  function jdFromDate(y, m, d, frac) {
    if (m <= 2) { y -= 1; m += 12; }
    var a = Math.floor(y / 100), b = 2 - a + Math.floor(a / 4);
    return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5 + (frac == null ? 0.5 : frac);
  }
  function sunLon(jd) {
    var T = (jd - 2451545.0) / 36525, R = Math.PI / 180;
    var L0 = 280.46646 + 36000.76983 * T + 0.0003032 * T * T;
    var M = (357.52911 + 35999.05029 * T - 0.0001537 * T * T) * R;
    var C = (1.914602 - 0.004817 * T - 0.000014 * T * T) * Math.sin(M) + (0.019993 - 0.000101 * T) * Math.sin(2 * M) + 0.000289 * Math.sin(3 * M);
    var om = (125.04 - 1934.136 * T) * R;
    return mod(L0 + C - 0.00569 - 0.00478 * Math.sin(om), 360);
  }
  function termJd(year, lon) {
    var days = mod(lon, 360) * 365.2422 / 360, jd = jdFromDate(year, 3, 20, 0.5) + days;
    if (lon >= 285) jd -= 365.2422;
    for (var k = 0; k < 50; k++) {
      var diff = mod(lon - sunLon(jd) + 180, 360) - 180;
      jd += diff * 365.2422 / 360;
      if (Math.abs(diff) < 1e-7) break;
    }
    return jd;
  }
  /* JD(UT) → 한국시 {y,m,d,hh,mm} */
  function jdToKst(jd) {
    var j = jd + 0.5 + KST, Z = Math.floor(j), F = j - Z;
    var a = Math.floor((Z - 1867216.25) / 36524.25), A = Z + 1 + a - Math.floor(a / 4);
    var B = A + 1524, C = Math.floor((B - 122.1) / 365.25), D = Math.floor(365.25 * C), E = Math.floor((B - D) / 30.6001);
    var day = B - D - Math.floor(30.6001 * E) + F, m = E < 14 ? E - 1 : E - 13, y = m > 2 ? C - 4716 : C - 4715, d = Math.floor(day);
    var mins = Math.round((day - d) * 1440);
    return { y: y, m: m, d: d, hh: Math.floor(mins / 60), mm: mins % 60 };
  }
  var cache = {};
  function jieList(year) {
    if (cache[year]) return cache[year];
    var out = [];
    [year - 1, year, year + 1].forEach(function (y) { JIE.forEach(function (j) { var jd = termJd(y, j[0]); out.push({ jd: jd, b: j[1], name: j[2], y: y, kst: jdToKst(jd) }); }); });
    out.sort(function (a, b) { return a.jd - b.jd; });
    return (cache[year] = out);
  }
  /* mins: 출생 시각(분, 한국시). 생략하면 정오(720) 가정 */
  function pillars(y, m, d, mins) {
    var noon = jdFromDate(y, m, d, 0) + (mins == null ? 720 : mins) / 1440 - KST, js = jieList(y), prev = null, next = null, ip = null, today = null;
    js.forEach(function (t) {
      if (t.jd <= noon) prev = t; else if (!next) next = t;
      if (t.name === '입춘' && t.y === y) ip = t;
      if (t.kst.y === y && t.kst.m === m && t.kst.d === d) today = t;
    });
    var sy = noon >= ip.jd ? y : y - 1, ys = mod(sy - 4, 10), yb = mod(sy - 4, 12), mb = prev.b, mi = mod(mb - 2, 12);
    var ms = mod((ys % 5) * 2 + 2 + mi, 10), di = mod(Math.floor(jdFromDate(y, m, d, 0.5) + 49), 60);
    return { y: y, m: m, d: d, sy: sy, ys: ys, yb: yb, ms: ms, mb: mb, ds: di % 10, db: di % 12, di: di, prev: prev, next: next, jieToday: today, noon: noon };
  }
  function daeun(p, male) {
    var yangYear = p.ys % 2 === 0, fwd = (yangYear && male) || (!yangYear && !male);
    var days = fwd ? p.next.jd - p.noon : p.noon - p.prev.jd;
    var n = Math.max(1, Math.min(10, rnd(days / 3)));
    var mi = gzIndex(p.ms, p.mb), list = [];
    for (var k = 1; k <= 10; k++) list.push({ age: n + (k - 1) * 10, i: mod(mi + (fwd ? k : -k), 60) });
    return { fwd: fwd, n: n, list: list };
  }
  function counts(p) {
    var c = [0, 0, 0, 0, 0];
    [p.ys, p.ms, p.ds].forEach(function (s) { c[stemEl(s)]++; });
    [p.yb, p.mb, p.db].forEach(function (b) { c[BR_EL[b]]++; });
    return c;
  }
  var TEN = [['비견', '겁재'], ['식신', '상관'], ['편재', '정재'], ['편관', '정관'], ['편인', '정인']];
  function tenGod(d, o) { return TEN[mod(stemEl(o) - stemEl(d), 5)][(d % 2) === (o % 2) ? 0 : 1]; }
  function pairIn(list, a, b) { return list.some(function (x) { return (x[0] === a && x[1] === b) || (x[0] === b && x[1] === a); }); }
  var SIX = [[0, 1], [2, 11], [3, 10], [4, 9], [5, 8], [6, 7]], SAM = [[8, 0, 4], [2, 6, 10], [5, 9, 1], [11, 3, 7]];
  var HY = [[2, 5], [5, 8], [8, 2], [1, 10], [10, 7], [7, 1], [0, 3]], SELF_HY = [4, 6, 9, 11];
  var HAE = [[0, 7], [1, 6], [2, 5], [3, 4], [8, 11], [9, 10]], WJ = [[0, 7], [1, 6], [2, 9], [3, 8], [4, 11], [5, 10]], PA = [[0, 9], [1, 4], [2, 11], [3, 6], [5, 8], [7, 10]];
  var REL = { '충': -6, '육합': 8, '반합': 6, '형': -4, '원진': -3, '해': -3, '파': -2, '같음': 3, '무난': 0 };
  function brRel(t, p) {
    if (Math.abs(t - p) === 6) return '충';
    if (t !== p && pairIn(SIX, t, p)) return '육합';
    if (t !== p && SAM.some(function (g) { return g.indexOf(t) >= 0 && g.indexOf(p) >= 0; })) return '반합';
    if ((t !== p && pairIn(HY, t, p)) || (t === p && SELF_HY.indexOf(t) >= 0)) return '형';
    if (t !== p && pairIn(WJ, t, p)) return '원진';
    if (t !== p && pairIn(HAE, t, p)) return '해';
    if (t !== p && pairIn(PA, t, p)) return '파';
    if (t === p) return '같음';
    return '무난';
  }
  var TEN_MOD = { '비견': [-2, 6, 4, 6], '겁재': [-5, 3, 6, 4], '식신': [6, 8, 4, 8], '상관': [4, 10, 2, 0], '편재': [10, 5, 6, 2],
    '정재': [12, 3, 5, 4], '편관': [2, -2, 8, -3], '정관': [4, 4, 10, 2], '편인': [-2, 0, 4, 5], '정인': [2, 6, 6, 8] };
  var WEIGHT = [0.3, 0.25, 0.25, 0.2], BASE = 70, LO = 55, HI = 98;
  var COLORS = ['초록', '빨강', '노랑', '흰색', '남색'], COLOR_HEX = ['#2f9e62', '#e0402f', '#e0a800', '#9aa3ad', '#2b4a8b'];
  var NUMBERS = ['3, 8', '2, 7', '5, 10', '4, 9', '1, 6'], DIRS = ['동쪽', '남쪽', '가운데', '서쪽', '북쪽'];
  function fnv(s) { var h = 0x811C9DC5; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function luckyEl(c, ds) {
    var me = stemEl(ds), order = [mod(me + 4, 5), me, mod(me + 1, 5), mod(me + 2, 5), mod(me + 3, 5)], mn = Math.min.apply(null, c);
    return order.filter(function (e) { return c[e] === mn; })[0];
  }
  function pad(n, w) { n = String(n); while (n.length < w) n = '0' + n; return n; }
  function fmt(s, a, b) { return s.replace('{a}', a).replace('{b}', b); }
  function fortune(y, m, d, male, ty, tm, td) {
    var T = window.NZ_FTEXT, p = pillars(y, m, d), t = pillars(ty, tm, td), c = counts(p), god = tenGod(p.ds, t.ds);
    var rDay = brRel(t.db, p.db), rYear = brRel(t.db, p.yb), te = stemEl(t.ds);
    var bal = c[te] === 0 ? 6 : (c[te] >= 3 ? -4 : 2), balK = c[te] === 0 ? '채움' : (c[te] >= 3 ? '넘침' : '보통');
    var key = pad(y, 4) + pad(m, 2) + pad(d, 2) + '|' + (male ? 'M' : 'F') + '|' + pad(ty, 4) + pad(tm, 2) + pad(td, 2), h = fnv(key);
    var sc = [0, 1, 2, 3].map(function (i) {
      var jit = ((h >>> (i * 5)) % 9) - 4;
      return Math.max(LO, Math.min(HI, BASE + TEN_MOD[god][i] + REL[rDay] + rnd(REL[rYear] * 0.6) + bal + jit));
    });
    var total = Math.floor((30 * sc[0] + 25 * sc[1] + 25 * sc[2] + 20 * sc[3] + 50) / 100);  // 가중 평균 반올림을 정수로 (소수 오차 방지)
    var stars = total >= 90 ? 5 : total >= 82 ? 4 : total >= 72 ? 3 : 2, le = luckyEl(c, p.ds);
    function pick(arr, salt) { return arr[(h >>> salt) % arr.length]; }
    return { p: p, t: t, counts: c, god: god, rDay: rDay, rYear: rYear, bal: balK, scores: sc, total: total, stars: stars,
      luckyEl: le, color: COLORS[le], colorHex: COLOR_HEX[le], number: NUMBERS[le], direction: DIRS[le],
      head: pick(T.head[god], 3), dayLine: pick(T.day_rel[rDay], 7), ttiLine: fmt(T.tti_rel[rYear], ANIMAL[p.yb], ANIMAL[t.db]),
      balLine: T.bal[balK].replace('{e}', EL[te]), tip: pick(T.tip[god], 11), keys: T.keys[god], hash: h };
  }
  window.NZ_SAJU = { pillars: pillars, fortune: fortune, daeun: daeun, counts: counts, tenGod: tenGod, brRel: brRel, termJd: termJd, jdToKst: jdToKst,
    gz: gz, gzK: gzK, gzIndex: gzIndex, stemEl: stemEl, STEM: STEM, STEM_K: STEM_K, BR: BR, BR_K: BR_K, ANIMAL: ANIMAL, ANIMAL_E: ANIMAL_E, EL: EL, EL_H: EL_H, BR_EL: BR_EL, COLOR_HEX: COLOR_HEX };
})();
