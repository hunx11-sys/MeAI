# -*- coding: utf-8 -*-
"""스마트 제안서 전용 특약 마스터 보강 — 약관 PDF → db_terms_extra.json (v8.66)

영업지원도구(특약검색기 tool.html · 보상시뮬레이터 등)에는 넣지 않는다. db.json 은 tool.html 에서만 뽑으므로
그대로 두고, 이 파일은 matcher 가 db.json 과 함께 읽는다(소유자 지시 2026-09-30 : 내Mom대로·내Mom같은 어린이보험은
스마트 제안서 고도화·오류 제거 목적의 약관 파싱만).

  python extract_terms_extra.py "약관.pdf" 상품표시명 id접두어 [상품명패턴]   (여러 상품은 한 번씩 — 같은 상품은 교체)

scripts/import_terms.py(또또암 때 쓴 추출기)의 절단 규칙을 그대로 쓰고, 이 두 약관의 새 별표 표기를 다룬다.
  · 별표 표기 【별표-질병40(대장 양성종양및특정용종 분류표)】 — 번호가 '공통·상해·질병' 갈래별이라 **번호(갈래+숫자)로** 부록 표에 잇는다.
  · 세부보장(①②…)마다 제3조에서 자기 별표를 따로 가리킨다 → 세부 레코드는 **자기 구간의 별표 코드만**(없으면 부모 코드).
  · 수가코드(hc) : 연결된 별표·본문의 5자리 진료행위코드(scripts/add_hc_codes.py 와 같은 규칙).
  · 제외코드(x) : 별표 안 '(… 제외)' 괄호의 코드 + 특약 본문에서 '제외'가 들어간 문장의 괄호 코드. 그 밖의 추정은 하지 않는다.
원칙 : 코드는 약관 원문에서만 옮긴다. 표를 못 찾으면 k 를 비워 두고(계산 제외 + 로그) 목록에 남긴다.
"""
import io, json, os, re, sys, hashlib, collections
import pymupdf

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE, '..', 'scripts'))
import import_terms as IT                                   # build_lines · heading_blocks · title_norm · subs_of · category · NONKCD · JUNK
import name_spacing as NS                                   # 약관 줄바꿈 자리에 끼어든 띄어쓰기 바로잡기(2026-11-06 · 「주요치 료비」 → 「주요치료비」)
OUT = os.path.join(BASE, 'db_terms_extra.json')

HEAD = re.compile(r'\s*【\s*별\s*표\s*-?\s*([가-힣]*)\s*(\d+)\s*】\s*')
REF = re.compile(r'【\s*별\s*표\s*-?\s*([가-힣]*)\s*(\d+)\s*(?:[(（]((?:[^()（）】]|[(（][^()（）】]*[)）])*)[)）]?)?\s*】')   # 닫는 괄호가 빠진 약관 오탈자도 읽는다 — 내Mom대로 2-70 「【별표-질병50(건선 분류표】」(v8.87)
# 범위 기호 : 물결(~)과, 양쪽이 모두 질병코드인 하이픈('P00 - P04' · 'H15-H22')(v8.77 — 하이픈 범위를 두 코드로만 읽어
# 내Mom같은어린이 출생전후기 주요병태 분류표 P00~P96 열 묶음이 양 끝 코드만 남았다)
CODE = re.compile(r'(?<![A-Za-z0-9])([A-Z]\d{2}(?:\.\d{1,2})?)(?:(?:\s*[~∼～]\s*|\s*[-‐–]\s*(?=[A-Z]\d{2}))([A-Z]?\d{2}(?:\.\d{1,2})?))?(?![0-9])')
HC = re.compile(r'(?<![A-Za-z0-9])([A-Z]{1,2}\d{3,4})(?![A-Za-z0-9])(?:\s*[~∼]\s*([A-Z]{1,2}\d{3,4}))?')   # 한글에 붙여 쓴 수가코드도 읽는다 — 내Mom대로 「피부과적자외선치료MM331~MM334」(v8.87 · 전에는 MM334 하나만)
GOJI = re.compile(r'\([^()]{1,24}가입\)')                    # 담보명 꼬리표 — scen_engine.GOJI 와 같은 형태
def tidy_goji(s):
    """PDF 줄바꿈으로 꼬리표 안에 공백이 생긴 '(편한가 입)'·'(31간편가 입)' 을 '(편한가입)' 으로 — 그래야 GOJI 가 떼고 감수 마스터와 이름이 맞는다(v8.71).
       가벼109-6 '… 갑상선암 주요치료비(…)(편한가 입)' 이 또160-6 과 안 맞아 파싱 코드(표 전체 77개)가 들어갔다."""
    return re.sub(r'\(([^()]{1,30})\)', lambda m: '(' + re.sub(r'\s+', '', m.group(1)) + ')' if re.sub(r'\s+', '', m.group(1)).endswith('가입') else m.group(0), s or '')
CIRC = '①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳'

def nz(s): return re.sub(r'[\s ]', '', s or '')
# '수술에서 제외하는 사항(① 흡인 ② 천자 ③ 신경차단 ④ 미용성형 목적의 수술 ⑤ 피임 목적의 수술 …)'도 세부보장이 아니다(2026-10-20 :
# 간편31 · The좋은내Mom대로 32대질병관혈수술비에 [미용성형 목적의 수술] 세부 레코드가 생겼던 것)
JUNKSUB = re.compile(r'청구서|증명서|제출|회사양식|위생관리|성형수술|미용\s*성형|목적의\s*수술|^\d+\.|[一-龥]|등의\s*조치|[「【“]|한다|이하|말한다|정한다')

EXAMPLE = re.compile(r'【[^】]*예\s*시[^】]*】.*?(?=\n\s*\d+\.\s|\n\s*【|\n\s*제\s*\d+\s*조|\Z)', re.S)
def strip_examples(t):
    """【○○ 예시】 블록(원발부위 기준 예시 · 보험금 지급예시 그림)의 코드는 설명용 — 다음 번호 항목·다음 【·다음 조문까지 뺀다.
       지급예시 그림의 '결장암(C18) … 보험금 미지급' 같은 줄은 지급 규칙이 아니다(v8.71 : 내Mom대로 갱신형 통합암진단비 세부보장 5건의
       제외코드에 C18·C50·C25·C34·C73 등 예시 코드가 들어가 14대특정암 폐암(C34) 사례가 0원이 되던 것)."""
    return EXAMPLE.sub(' ', t)

def join_split_ranges(t):
    """표 칸 폭 때문에 범위 끝 코드의 마지막 숫자가 다음 줄로 넘어간 것을 잇는다(v8.73).
       'C00~C1' 처럼 끝이 '영문+숫자 1자리'면 KCD 로 완결되지 않은 것이다 — 바로 다음 줄, 또는 설명 글 줄 몇 개 뒤에
       숫자 한 자리만 있는 줄이 나오면 그 숫자를 붙이고 그 줄은 지운다(The건강한내Mom대로5.10.5 p.1285 : 'C74~C7' … '5', 'C77~C8' … '0')."""
    L = t.split('\n')
    for i, line in enumerate(L):
        m = re.search(r'([~∼～]\s*[A-Z]\d)\s*$', line)
        if not m:
            continue
        for j in range(i + 1, min(i + 16, len(L))):                           # 설명 글 줄이 9줄 끼는 쪽도 있다(The건강한내Mom대로5.10.5 p.1285 'C74~C7' … 9줄 … '5' · v8.77)
            if re.fullmatch(r'\s*\d\s*', L[j]):
                L[i] = line.rstrip() + L[j].strip(); L[j] = ''
                break
            if re.search(r'[A-Z]\d{2}', L[j]):                             # 다른 코드가 먼저 나오면 잇지 않는다
                break
    return '\n'.join(L)


def kcds(txt):
    """표·본문 텍스트 → (코드목록, 제외코드목록). '(… 제외)' 괄호 안 코드는 제외코드로."""
    t = re.sub(r'([A-Z]\d{2}\.)\s*\n\s*(\d)', r'\1\2', txt)          # 'C78.' + 줄바꿈 + '4'
    t = join_split_ranges(t)                                           # 'C00~C1' … '4' (The건강한내Mom대로5.10.5 통합암 분류표 · v8.73)
    t = strip_examples(t)
    ex = []
    for m in re.finditer(r'[(（]([^()（）]{0,120}?)제외\s*[)）]', t):
        for a, b in CODE.findall(m.group(1)): ex.append(a + ('~' + (b if b[0].isalpha() else a[0] + b) if b else ''))
    t2 = re.sub(r'[(（][^()（）]{0,120}?제외\s*[)）]', ' ', t)
    # 표 머리글의 범위 안내 문장('다만, 다음의 상병 이외의 출생전후기 질병(P00~P96)은 포함되지 않습니다')은 대상 코드가 아니다
    t2 = re.sub(r'[^.。]{0,200}(?:포함되지\s*않|포함하지\s*않|보상하지\s*않|지급하지\s*않|해당하지\s*않|아니합니다|제외합니다|제외됩니다|출생전후기)[^.。]{0,60}[.。]', ' ', t2.replace('\n', ' '))
    k = []
    for a, b in CODE.findall(t2):
        c = a + ('~' + (b if b[0].isalpha() else a[0] + b) if b else '')
        if c not in k: k.append(c)
    return k, list(dict.fromkeys(ex))

def hcs(txt):
    out = []
    for a, b in HC.findall(txt or ''):
        if len(a) != 5: continue
        if b and len(b) == 5 and a[:-2] == b[:-2] and b[-2:].isdigit() and a[-2:].isdigit():
            for n in range(int(a[-2:]), int(b[-2:]) + 1): out.append(a[:-2] + '%02d' % n)
        else: out.append(a)
    return list(dict.fromkeys(out))

def appendix(lines, starts):
    """줄 단독의 【별표-갈래N】 제목부터 다음 제목(또는 다음 특약 시작)까지 표 하나.
       약관은 [본문][부록][갱신형 본문][부록]… 처럼 부록이 여러 번 온다 → 사이에 특약 시작이 끼면 다른 부록(구역)으로 나눈다.
       반환 : [(구역시작줄, 구역끝줄, {갈래N: [표…]})] (목차 줄은 제목 뒤에 점선·쪽번호가 붙어 제외된다)"""
    heads = [i for i, (pi, l) in enumerate(lines) if HEAD.fullmatch(l)]
    starts = sorted(starts); regions = []
    def next_start(i):
        for s in starts:
            if s > i: return s
        return len(lines)
    cur = None
    for n, i in enumerate(heads):
        if cur is None or next_start(cur['last']) < i:
            cur = {'a': i, 'last': i, 'tabs': {}}; regions.append(cur)
        cur['last'] = i
        m = HEAD.fullmatch(lines[i][1]); key = m.group(1) + m.group(2)
        j = min(heads[n + 1] if n + 1 < len(heads) else len(lines), next_start(i))
        name, k = [], i + 1
        while k < j and len(name) < 2:
            tt = lines[k][1].strip()
            if tt: name.append(tt)
            k += 1
            if name and re.search(r'(표|계산|비용|종류|목록)$', name[-1]): break
        txt = '\n'.join(l for _, l in lines[k:j])
        cut = TAB_END.search(txt)                    # 부록 마지막 표 뒤로 다음 약관 조문이 이어지면 거기서 끊는다(v8.73)
        if cut:
            txt = txt[:cut.start()]
        cur['tabs'].setdefault(key, []).append({'key': key, 'name': ' '.join(name), 'page': lines[i][0] + 1, 'text': txt})
        cur['b'] = j
    return [(r['a'], r['b'], r['tabs']) for r in regions]

# 부록 마지막 표 뒤에 다음 약관('제2관 …' · '제3조(보험금의 지급사유)')이 붙어 나오면 거기부터는 표가 아니다 —
# 내Mom대로·어린이 【별표2 독감(인플루엔자) 분류표】가 3만6천 자로 늘어나, 보통약관 해설 '습관성 유산, 불임 … N96~N98'을
# 대상코드로 읽던 것(v8.73 · 독감 항바이러스제치료비 5건).
TAB_END = re.compile(r'\n\s*제\s*\d+\s*관\s+\S|\n\s*제\s*\d+\s*조\s*\(')


def pick(tabs, key, name):
    c = tabs.get(key) or []
    if len(c) <= 1: return c[0] if c else None
    nn = nz(name).replace('분류표', '')
    for e in c:
        en = nz(e['name']).replace('분류표', '')
        if nn and en and (nn in en or en in nn): return e
    return c[0]

def is_kcd_table(e):
    return not any(x in nz(e['name']) for x in IT.NONKCD) and bool(kcds(e['text'])[0])

NEG = re.compile(r'제외|포함되지\s*않|보상하지\s*않|지급하지\s*않')
def refs_of(txt, tabs):
    """본문 → [(표, 문장)] (줄바꿈으로 끊긴 【별표\n-공통2(…)】 도 잇는다)"""
    flat = re.sub(r'\s*\n\s*', '', txt)
    out, seen = [], set()
    for sent in re.split(r'(?<=[다음])\.', flat):
        for m in REF.finditer(sent):
            e = pick(tabs, m.group(1) + m.group(2), m.group(3) or '')
            if e and (id(e), sent) not in seen: seen.add((id(e), sent)); out.append((e, sent))
    return out

def cover(pairs):
    """[(표, 문장)] → (대상 코드, 제외 코드, 쓴 표). 코드는 약관 표·문장 원문에서만.
       · 문장이 표를 가리키면서 코드를 직접 적었으면('…분류표 중 분류번호 C44') 그 코드만 대상
       · 문장에 제외·포함되지 않 등이 있으면 : 문장에 적힌 코드는 제외코드, 표는 '표 바로 뒤 30자 안에서 제외'면 표 전체가 제외
       · 그 밖은 표 전체가 대상"""
    k, x, used = [], [], []
    add = lambda L, cs: L.extend(c for c in cs if c not in L)
    for e, sent in pairs:
        if not is_kcd_table(e): continue
        s0 = REF.sub(' ', sent)
        sc = [a + ('~' + (b if b[0].isalpha() else a[0] + b) if b else '') for a, b in CODE.findall(s0)]
        tk, tx = kcds(e['text'])
        # 담보·분류표 이름 속 '(유사암제외)'·'(특정암제외)' 는 제외 문장이 아니다(v8.71) — 「【별표13(통합암(전이포함)(유사암제외) 분류표)】에서
        # 정한「통합암(전이포함)(유사암제외)」으로 진단확정」 문장에서 표 전체 101코드가 제외코드로 들어가 통합암진단비 세부보장(건맘242·건강146·가벼117)·
        # 926종 항암방사선및약물치료비(건맘168·건강209)가 모든 암에 0원이 되던 것. 표 안의 '(… 제외)' 괄호 코드(C44·C73)는 kcds 가 따로 뽑는다.
        sn = re.sub(r'[(（][^()（）]{0,30}제외\s*[)）]', '', sent)
        neg = NEG.search(sn)
        m = REF.search(sn); tail = sn[m.end():m.end() + 30] if m else ''
        if neg and not sc and NEG.search(tail) and '중' not in tail[:8]:
            add(x, tk)                                   # '【별표…】에 해당하는 질병은 제외'
        elif sc and not neg:
            add(k, sc)                                   # '…분류표 중 C44'
        else:
            add(k, tk); add(x, tx)
            if neg: add(x, sc)
        used.append(e)
    return k, x, used

def body_x(txt):
    """특약 본문의 '제외' 문장 괄호 코드 — 예) '… 질병(N08.3 제외)' · '기타피부암(C44) 및 갑상선암(C73)은 제외'"""
    ex = []
    flat = re.sub(r'\s*\n\s*', ' ', strip_examples(txt))          # 지급예시 그림의 코드는 제외코드가 아니다(v8.71)
    for sent in re.split(r'(?<=다)\.\s', flat):
        if '제외' not in sent: continue
        for m in re.finditer(r'[(（]\s*([A-Z]\d{2}(?:\.\d{1,2})?(?:\s*[~∼～,]\s*[A-Z]?\d{2}(?:\.\d{1,2})?)*)\s*(?:제외)?\s*[)）]', sent):
            for a, b in CODE.findall(m.group(1)): ex.append(a + ('~' + (b if b[0].isalpha() else a[0] + b) if b else ''))
    return list(dict.fromkeys(ex))

def sub_chunks(body_lines, labels):
    """제3조(세부보장에 관한 사항)의 ①②… 구간 — 세부보장마다 [시작, 끝) 줄 위치. 못 찾으면 None"""
    pos = []
    for i, lab in enumerate(labels):
        c = CIRC[i] if i < len(CIRC) else None
        key = nz(lab)[:6]
        hits = [j for j, l in enumerate(body_lines) if c and l.strip().startswith(c) and key and key in nz(l)]
        pos.append(hits[-1] if hits else None)                # 제1조 목록이 아닌 제3조 본문(마지막으로 나오는 곳)
    if any(p is None for p in pos) or pos != sorted(pos): return None
    return [(p, pos[i + 1] if i + 1 < len(pos) else len(body_lines)) for i, p in enumerate(pos)]

# 특약 분류(c) — db.json categories 와 같은 id. import_terms.category 는 암보험용이라 '수술비·입원일당'을 암으로 보냈다(v8.66)
_CATS = [(r'통합치료비', 'integrated'), (r'유사암|암.*진단|진단.*암|전이암', 'cancer_dx'), (r'암.*(수술|입원|통원)', 'cancer_etc'), (r'암|항암|표적|면역|양성자|중입자|호르몬', 'cancer_tx'),
         (r'뇌|혈전', 'brain'), (r'심장|허혈|심근|부정맥|순환계', 'heart'), (r'신부전|신장', 'kidney'), (r'치매|장기요양', 'dementia'), (r'치아|임플란트', 'dental'),
         (r'자동차|운전|교통', 'driving'), (r'벌금|변호사|소송|법률', 'legal'), (r'배상', 'liability'), (r'화재|재물|가전', 'property'),
         (r'골절|화상|깁스', 'fracture'), (r'후유장해|장해', 'disability'), (r'사망', 'death'), (r'간병|간호', 'care'), (r'수술', 'surgery'), (r'입원|통원|응급', 'admission')]
def category(n):
    for p, c in _CATS:
        if re.search(p, n): return c
    return 'specific'

def tid(product, e): return 'X' + hashlib.md5((product + '|' + e['key'] + '|' + str(e['page'])).encode('utf-8')).hexdigest()[:10]

def col_text(page):
    """두 단 조판 쪽을 '왼쪽 단 → 오른쪽 단' 순서로 읽는다(v8.73).
       pymupdf 기본 get_text() 는 줄 높이가 같으면 두 단을 가로로 섞어, 별표 둘째 단의 코드가 다음 별표로 넘어가거나
       (특정순환계질환 분류표 52 → 34코드) 옆 표의 코드가 들어왔다(대상포진 분류표에 I21·I60 등 · 악성신생물 분류표에 B15·I00 등).
       가로 전체를 차지하는 블록(제목·표머리)은 위치대로 앞에 둔다."""
    w = page.rect.width
    bl = [b for b in page.get_text('blocks') if b[6] == 0 and b[4].strip()]
    full = [b for b in bl if b[0] < w * 0.35 and b[2] > w * 0.65]
    rest = [b for b in bl if b not in full]
    left = [b for b in rest if (b[0] + b[2]) / 2 < w / 2]
    right = [b for b in rest if (b[0] + b[2]) / 2 >= w / 2]
    if not left or not right:                                   # 한 단 쪽은 기본 읽기 그대로
        return page.get_text()
    seq = sorted(full + left, key=lambda b: (b[1], b[0])) + sorted(right, key=lambda b: (b[1], b[0]))
    nl = chr(10)
    return nl.join(b[4].rstrip(nl) for b in seq) + nl


PAIR_HEAD = re.compile(r'^\s*\d+(?:-\d+)?\.\s*(.+?)\s*$')
def alt_titles(lines, bstart, title):
    """2610 약관(2026-10-31)부터 비갱신 특약과 갱신형 특약이 한 본문을 같이 쓴다 — 제목이
         「2-168. 통합암진단비(유사암제외)보장 특별약관」 「2-169. 갱신형 통합암진단비(유사암제외)보장 특별약관」 두 줄(넷 줄)로 잇달아 오고
       heading_blocks 는 제1조에서 거슬러 올라가다 첫 번호 줄(2-169.)에서 멈추므로 앞 제목(비갱신)을 잃는다(내Mom대로 · 내Mom같은어린이
       암진단비(유사암제외) · 뇌졸중진단비 · 급성심근경색증진단비 등 13개 — 독립특약 → 종속특약 전환). 블록 바로 위 줄(최대 4줄)이
       「번호. …특별약관」 꼴이면 그 제목을 돌려준다(같은 본문 · 같은 별표를 쓰는 특약으로 하나 더 만든다). 글자는 만들지 않는다."""
    buf, j, n = [], bstart - 1, 0
    while j >= 0 and n < 4:
        t = lines[j][1].strip(); j -= 1
        if not t: continue
        n += 1; buf.insert(0, t)
        joined = ' '.join(buf)
        if PAIR_HEAD.match(joined) and '특별약관' in nz(joined):          # 「…보장 특별약」+「관」 처럼 글자가 줄 끝에서 끊긴 제목도(내Mom대로 2610 p.570 암진단비(유사암제외))
            alt = IT.title_norm(PAIR_HEAD.match(joined).group(1))
            alt = GOJI.sub('', tidy_goji(alt)); alt = re.sub(r'보장$', '', alt).strip()
            # 짝으로 보는 것은 「갱신형」만 다른 같은 이름뿐(내Mom대로 2610 : 같은 이름 55쌍 · 다른 이름 5건은 앞 특약 머리글·절 제목이라 뺀다)
            if alt and nz(alt) != nz(title) and re.sub(r'^갱신형', '', nz(alt)) == re.sub(r'^갱신형', '', nz(title)) and len(alt) <= 70 and not IT.JUNK.search(alt):
                return [alt]
            return []
        if re.search(r'(니다|습니다|합니다|됩니다)\s*\.?\s*$', t) or re.match(r'^\s*제\s*\d+\s*조', t) or '【' in t:
            return []
    return []


def parse(path, product, prefix):
    d = pymupdf.open(path)
    pages = [col_text(d[i]) if os.environ.get('TERMS_COLS', '1') == '1' else d[i].get_text() for i in range(len(d))]
    lines = IT.build_lines(pages)
    TXT = NS.flat(pages)                                                   # 이름 띄어쓰기 판정용 약관 글자(같은 줄 안)
    NREF = '\n'.join(r['n'] for r in json.load(open(os.path.join(BASE, 'db.json'), encoding='utf-8'))['riders'])   # 감수본 이름 — 붙여 쓴 표기 참고
    blocks = IT.heading_blocks(lines)
    regs = appendix(lines, [b['bstart'] for b in blocks])
    riders, log = [], []
    alltabs = {}
    for a, z, tb in regs:
        for kk, v in tb.items(): alltabs.setdefault(kk, []).extend(v)
    for bi, b in enumerate(blocks):
        if any(a <= b['bstart'] < z for a, z, _ in regs): continue          # 부록(별표) 안의 '제1조'는 특약이 아니다
        nxt = [r for r in regs if r[0] > b['bstart']]
        if not nxt: continue
        tabs, app_a = nxt[0][2], nxt[0][0]                                  # 이 특약 뒤에 오는 부록(같은 구역)
        title = IT.title_norm(b['title'])
        title = GOJI.sub('', tidy_goji(title)); title = re.sub(r'보장$', '', title).strip()
        title = NS.unbreak(title, TXT, ref=NREF)[0]
        if not title or len(title) > 70 or IT.JUNK.search(title) or re.search(r'다\.|^부터', title): continue
        end = min(blocks[bi + 1]['bstart'] if bi + 1 < len(blocks) else len(lines), app_a)
        body_lines = [l for _, l in lines[b['bstart']:end]]
        body = '\n'.join(body_lines)
        if '지급사유' not in body[:8000] and '보장의 범위' not in body[:3000]: continue
        P = refs_of(body, tabs)
        R = list({id(e): e for e, _ in P}.values())
        k, x, _u = cover(P)
        x += [c for c in body_x(body) if c not in x]
        hc = []
        for e in R:
            if '수술분류표' not in e['name'] and '산정특례' not in e['name']: hc += hcs(e['text'])
        hc = list(dict.fromkeys(hc + hcs(body)))
        rid = '%s%d' % (prefix, len([r for r in riders if not r.get('parent')]) + 1)
        r = {'id': rid, 'p': product, 'n': title, 'c': category(title), 'pg': b['page'] + 1, 'k': k, 'x': x,
             't': [tid(product, e) for e in R], 'hc': hc, 'src': [e['key'] + ' ' + e['name'] for e in R], '_body': body}   # _body : 세부보장 채우기(sub_fill)용 · 저장 전에 뗀다
        riders.append(r)
        if not k and not re.search(r'사망|후유장해|상해|골절|화상|입원일당|수술비\(1-|1-5종|1-7종|수술비Ⅱ|질병수술비|납입|지원금|배상|벌금|변호사|소송|치아', title):
            log.append(('KCD 없음', rid, title, r['src']))
        alt_ids = []
        for alt in alt_titles(lines, b['bstart'], title):          # 비갱신·갱신형 짝 제목(2610 약관) — 같은 본문·별표로 하나 더
            alt = NS.unbreak(alt, TXT, ref=NREF)[0]
            arid = '%s%d' % (prefix, len([r_ for r_ in riders if not r_.get('parent')]) + 1)
            riders.append(dict(r, id=arid, n=alt, c=category(alt), pair=rid)); alt_ids.append((arid, alt))
            log.append(('짝 제목(같은 본문)', arid, alt, rid))
        m_sub = re.search(r'총\s*(\d+)\s*개\s*(의)?\s*세부\s*보장', body)
        n_sub = int(m_sub.group(1)) if m_sub else 0
        if not n_sub: continue
        labels, how = IT.subs_of(body_lines, n_sub)
        if len(labels) != n_sub:
            log.append(('세부 개수 불일치 %d/%d' % (len(labels), n_sub), rid, title, labels[:6])); labels = labels[:n_sub]
        ch = sub_chunks(body_lines, labels) if how == 'enum' else None
        for i, lab in enumerate(labels, 1):
            lab = GOJI.sub('', tidy_goji(lab)).strip()
            if JUNKSUB.search(lab): continue                          # 보험금 청구서류 목록 등이 세부보장으로 잡힌 것
            lab = re.split(r'\s*:\s*|\s*보장\s*:', lab)[0].strip()      # '화상진단비보장 : 화상으로 진단확정시 …' → '화상진단비'
            lab = re.sub(r'보장$', '', lab).strip()
            lab = NS.unbreak(lab, TXT, ref=NREF)[0]
            sk, sx, st, shc, ssrc = k, x, r['t'], hc, r['src']
            if ch:
                seg = '\n'.join(body_lines[ch[i - 1][0]:ch[i - 1][1]])
                SP = refs_of(seg, tabs); SR = list({id(e): e for e, _ in SP}.values())
                a_, b_, u_ = cover(SP)
                if u_:
                    sk, sx = a_, b_
                    sx += [c for c in body_x(seg) if c not in sx]
                    st = [tid(product, e) for e in SR]; ssrc = [e['key'] + ' ' + e['name'] for e in SR]
                    shc = list(dict.fromkeys([h for e in SR if '수술분류표' not in e['name'] for h in hcs(e['text'])] + hcs(seg)))
            child = {'id': '%s-%d' % (rid, i), 'p': product, 'n': '%s[%s]' % (title, lab), 'c': category('%s[%s]' % (title, lab)) if r['c'] == category(title) else r['c'], 'pg': r['pg'],
                     'k': sk, 'x': sx, 't': st, 'hc': shc, 'src': ssrc, 'parent': rid}
            riders.append(child)
            for arid, alt in alt_ids:                                   # 짝 제목(비갱신) 쪽에도 같은 세부보장을
                riders.append(dict(child, id='%s-%d' % (arid, i), n='%s[%s]' % (alt, lab), parent=arid))
    return riders, alltabs, log

# 보강 상품의 추출(감수) 순서 — 같은 이름 특약의 코드를 빌릴 때 이 순서에서 앞선 상품 것만 쓴다
ORDER = ['내Mom대로', '내Mom같은어린이', '간편31', 'The건강한내Mom대로5.10.5', 'The건강한5.10.5', 'The좋은내Mom대로', 'The가벼운간편355']

MUGAM = re.compile(r'\((?:감액및면책기간미적용|감액기간미적용|면책기간미적용)\)')
GJ_ = re.compile(r'\([^()]{1,24}가입\)')


def settle_key(n):
    """감수 마스터와 '같은 특약'을 찾는 이름 열쇠(v8.73).
       · 공백 → 가입 꼬리표 → 갱신형 → 무감액 꼬리표((면책기간미적용) 등) 순으로 뗀다. 무감액 판은 면책·감액 기간만 다르고
         보장 문구·별표가 같다(The건강한5.10.5 p.699 항암방사선약물치료비(면책기간미적용) 제1조·제3조 = 통48 과 같은 문구).
       · 세트 특약 'A[A[B]]' → 'A[B]', 'A[A'(B)(연간1회한)]' → 'A[B]' (구성특약 이름에서 부모 이름·(연간1회한)을 뗀다)
       · 약관 추출 때 앞에 붙은 번호('8계속받는…', '926종…')는 그 이름이 감수 마스터에 없을 때만 뗀다(호출하는 쪽에서)."""
    t = MUGAM.sub('', re.sub(r'^갱신형', '', GJ_.sub('', re.sub(r'\s', '', n or ''))))
    m = re.fullmatch(r'([^\[\]]+)\[(.*)\]', t)
    if m:
        par, comp = m.group(1), m.group(2)
        mm = re.fullmatch(r'([^\[\]]+)\[(.*)\]', comp)
        if mm and settle_key(mm.group(1)) == par:
            comp = mm.group(2)
        comp = MUGAM.sub('', re.sub(r'^갱신형', '', comp)).replace('(연간1회한)', '')
        if comp.startswith(par):
            comp = comp[len(par):]
        if comp.startswith('(') and comp.endswith(')'):
            comp = comp[1:-1]
        t = par + '[' + comp + ']'
    return t


def settle(riders):
    """감수(監修)된 특약 마스터(db.json)에 같은 이름 특약이 있으면 그 코드(k·x·hc)를 쓴다 — 메리츠 특약은 상품이 달라도
       같은 이름이면 같은 약관 조문·별표를 쓴다(원문 대조 : 같은 이름 668건 중 469건이 파싱 결과와 완전 일치, 나머지는
       파서의 한계 — 암종 구분 열이 있는 표·'분류표 중 C44' 같은 정의 조문). 마스터에 없는 특약만 파싱 코드를 쓰고 근거(별표)를 남긴다."""
    sys.path.insert(0, BASE)
    key = settle_key
    # 정확한 이름(공백·가입 꼬리표·갱신형만 뗀 것)이 먼저 — 무감액 꼬리표까지 뗀 열쇠는 정확한 짝이 없을 때만 쓴다(v8.73).
    # 예) 가벼249 「암진단비(유사암및소액암제외)(감액및면책기간미적용)」 은 통291(같은 무감액판)이 짝이고, 통229(일반판)가 아니다.
    exact = lambda n: re.sub(r'^갱신형', '', GJ_.sub('', re.sub(r'\s', '', n or '')))
    db = json.load(open(os.path.join(BASE, 'db.json'), encoding='utf-8'))['riders']
    idx = collections.defaultdict(list); idx0 = collections.defaultdict(list)
    for r in db:
        idx[key(r['n'])].append(r); idx0[exact(r['n'])].append(r)
    ex_idx = collections.defaultdict(list)                           # 먼저 추출한 다른 보강 상품(같은 약관 문구)의 파싱 결과 — KCD 를 못 뽑은 특약의 보조 근거
    # 빌려오는 상품은 ORDER 에서 이 상품보다 앞선 것만, ORDER 순서대로 — 어떤 순서로 다시 뽑아도 결과가 같다(v8.71).
    # 전에는 db_terms_extra.json 에 들어 있는 순서(마지막에 뽑은 상품이 맨 뒤)를 따라서, 한 상품만 다시 뽑으면 다른 상품 코드를 빌리던 특약이 바뀌었다.
    me = riders[0]['p'] if riders else ''
    rank = lambda p: ORDER.index(p) if p in ORDER else len(ORDER)
    if os.path.exists(OUT):
        for r in sorted(json.load(open(OUT, encoding='utf-8'))['riders'], key=lambda r: rank(r['p'])):
            if r.get('k') and r['p'] != me and rank(r['p']) < rank(me): ex_idx[key(r['n'])].append(r)
    n_m = 0
    for r in riders:
        if not r['k'] and ex_idx.get(key(r['n'])):
            o = ex_idx[key(r['n'])][0]
            r.update(k=list(o['k']), x=list(o.get('x') or []), hc=list(o.get('hc') or r['hc']), src=o.get('src') or [])
            r['basis_from'] = '%s %s(같은 이름 특약 약관 p.%s)' % (o['p'], o['id'], o.get('pg'))
        kk = key(r['n'])
        c = idx0.get(exact(r['n'])) or idx.get(kk) or (idx.get(kk[1:]) if re.match(r'^\d', kk) else None)
        if c:
            best = c[0]
            r.update(k=list(best.get('k') or []), x=list(best.get('x') or []), hc=list(best.get('hc') or []), c=best.get('c') or r['c'],
                     basis='마스터 %s(%s) 같은 이름 특약' % (best['id'], best['p']))
            n_m += 1
        else:
            r['basis'] = ('약관 p.%s 파싱 : %s' % (r['pg'], ' · '.join(r.get('src') or []) or '별표 없음')) + ((' · 코드는 ' + r.pop('basis_from')) if r.get('basis_from') else '')
    return n_m

def fill_subs(riders, log):
    """약관이 「총 N개의 세부보장」 문구 없이 지급표로만 세부보장을 나눈 특약(32대질병관혈수술비 · 다빈치로봇 암수술비 · 표적항암약물허가치료비Ⅲ 등)에
       같은 이름 특약(감수 마스터 · 다른 보강 상품)의 세부보장을 붙인다 — 이 약관 본문에 그 세부보장 이름이 모두 있을 때만(v8.90 · sub_fill.py)"""
    import sub_fill as SF
    db = [dict(r, src='db') for r in json.load(open(os.path.join(BASE, 'db.json'), encoding='utf-8'))['riders']]
    other = [dict(r, src='extra') for r in (json.load(open(OUT, encoding='utf-8'))['riders'] if os.path.exists(OUT) else []) if riders and r['p'] != riders[0]['p']]
    plan, flog = SF.plan(riders, db + other + [dict(r, src='extra') for r in riders], lambda r: r.get('_body') or '')
    pos = {r['id']: i for i, r in enumerate(riders)}
    add = []
    for par, new in plan:
        kids = [dict(k, t=list(par.get('t') or []), src=list(par.get('src') or []), pg=par['pg']) for k, _ in new]
        at = max([pos[par['id']]] + [i for i, r in enumerate(riders) if r['id'].startswith(par['id'] + '-')])   # 세부보장이 일부 있으면 그 뒤에(v8.92)
        add.append((at, kids))
        log.append(('세부보장 채움 %d개' % len(kids), par['id'], par['n'], kids[0]['basis'][:60]))
    for i, kids in sorted(add, key=lambda x: -x[0]):
        riders[i + 1:i + 1] = kids
    for x in flog:
        if not x[0].startswith('본문 없음'): log.append(x)
    return sum(len(k) for _, k in add)

if __name__ == '__main__':
    if len(sys.argv) < 4: sys.exit(__doc__)
    path, product, prefix = sys.argv[1:4]
    riders, tabs, log = parse(path, product, prefix)
    n_m = settle(riders)
    print('감수 마스터와 같은 이름 %d건은 마스터 코드 · 나머지 %d건은 약관 파싱 코드' % (n_m, len(riders) - n_m))
    n_f = fill_subs(riders, log)
    if n_f: print('세부보장 채움 %d건(같은 이름 특약의 세부보장 · 약관 본문에 그 이름이 있을 때만 — sub_fill.py)' % n_f)
    for r in riders: r.pop('_body', None)
    db = json.load(open(OUT, encoding='utf-8')) if os.path.exists(OUT) else {'meta': {}, 'riders': []}
    # 새 약관에 없는 특약(판매중지)은 넘기지 않는다 — 소유자 2026-11-02 : 판매중지 담보는 지운다(이전에는 retired 표시로 이월했음)
    db['riders'] = [r for r in db['riders'] if r['p'] != product] + riders
    db['meta'] = {'note': '스마트 제안서 전용 특약 마스터(영업지원도구 미반영) — extract_terms_extra.py 로 약관 PDF 에서 추출',
                  'products': sorted({r['p'] for r in db['riders']}), 'prodcount': dict(collections.Counter(r['p'] for r in db['riders'])),
                  'sources': dict((db.get('meta') or {}).get('sources') or {}, **{product: os.path.basename(path)})}
    json.dump(db, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    par = [r for r in riders if not r.get('parent')]
    print('%s : 특약 %d · 세부 %d · 별표 %d · KCD 보유 %d · 제외코드 보유 %d · 수가코드 보유 %d' % (
        product, len(par), len(riders) - len(par), sum(len(v) for v in tabs.values()), sum(1 for r in riders if r['k']),
        sum(1 for r in riders if r['x']), sum(1 for r in riders if r['hc'])))
    for x in log: print('  [%s] %s %s %s' % x)
