# -*- coding: utf-8 -*-
"""설계 PDF + 담보 JSON → 보장 지면(설계에 있는 계열만, 최대 9쪽) 생성 후 담보사항이 끝나는 쪽 뒤에 삽입."""
import json, re, subprocess, sys, os
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import pdfplumber
from build_pdf import merge
def page_count(p):
    with pdfplumber.open(p) as pdf: return len(pdf.pages)

def last_cover_page(pdf_path):
    """'보장보험료 합계'가 마지막으로 나오는 쪽 = 담보사항 종료 쪽"""
    n = 0
    with pdfplumber.open(pdf_path) as pdf:
        for i, p in enumerate(pdf.pages):
            t = p.extract_text() or ''
            if '보장보험료 합계' in t or '보장보험료합계' in t.replace(' ',''): n = i+1
    return n or 3
def auto_meta(pdf_path):
    """원본 상품설명서 첫 쪽들에서 피보험자·보험료·상품명·계약사항·영업담당자·발행정보를 자동 추출"""
    with pdfplumber.open(pdf_path) as pdf:
        t1 = pdf.pages[0].extract_text() or ''
        t2 = '\n'.join((q.extract_text() or '') for q in pdf.pages[1:3])      # 2 · 3쪽(짧은 PDF 에서 멈추지 않게 · 결과는 같다)
    def g(pat, t, d=''):
        mm = re.search(pat, t); return mm.group(1).strip() if mm else d
    m = {}
    m['insured'] = g(r'피보험자\s+(\S+)', t1, '고객')
    m['premium'] = g(r'보험료\s+([\d,]+)\s*원', t1, '') + '원'
    if m['premium'] == '원':                                   # 태아 설계 : 「보험료 출생전 : 110,770 원, 출생후 : 110,770 원」 — 지금 내는 출생전 보험료를 적는다(전에는 못 읽어 표지 · 머리줄에 「-」 · v9.06)
        bf = re.search(r'보험료\s+출생전\s*[:：]?\s*([\d,]+)\s*원(?:\s*,?\s*출생후\s*[:：]?\s*([\d,]+)\s*원)?', t1)
        if bf:
            m['premium'] = bf.group(1) + '원'
            if bf.group(2) and bf.group(2) != bf.group(1): m['premium_after'] = bf.group(2) + '원'      # 출생후 보험료가 다르면 따로 남긴다(지면에는 출생전)
    m['product'] = g(r'(\(무\)[^\n]+)', t1, '')
    m['head'] = g(r'(계약사항\s*:[^\n]+)', t2, '').replace('~', '~ ').replace('  ', ' ')
    m['agent'] = g(r'영업담당자\s+(.+?)\s+발행정보', t2, '')
    # 발행 일시는 텍스트 추출 순서가 들쭉날쭉해 날짜 패턴을 직접 찾고, 이름은 '발행정보' 다음 줄에서 가져온다
    dt = re.search(r'(\d{4}\.\d{2}\.\d{2}\s+\d{2}:\d{2}:\d{2})', t2)
    nm = re.search(r'발행정보\s*\n\s*([가-힣]{2,5})\s*\n', t2)
    m['issued'] = ((dt.group(1).replace(' ', '&nbsp;&nbsp;') if dt else '') + '<br>' + (nm.group(1) if nm else '')).strip('<br>')
    m['sex'] = insured_sex(pdf_path)
    return m

def insured_sex(pdf_path):
    """피보험자 성별(v8.19) : 상품설명서 뒤쪽 '갱신담보 예상보험료' 표의 '피보험자명 ○○ 생년월일 남/여, **년' 을 읽는다.
       그 줄이 없으면 '계약자명 ○○(남, 1978. …)' 로, 그것도 없으면 빈 값('') → 생성기가 담보명(유방·자궁 / 전립선)으로 추정하고, 끝내 모르면 성별 중립 사례를 쓴다.
       반환 : 'M' | 'F' | ''"""
    with pdfplumber.open(pdf_path) as pdf:
        pages = [(p.extract_text() or '') for p in pdf.pages]
    full = '\n'.join(pages)
    mm = re.search(r'피보험자명[^\n]{0,40}?생년월일\s*(남|여)', full) or re.search(r'피보험자명\s*\S+\s*\((남|여)\s*,', full)
    if not mm: mm = re.search(r'계약자명\s*\S+\s*\((남|여)\s*,', full)
    return {'남': 'M', '여': 'F'}.get(mm.group(1), '') if mm else ''

def guess_line(riders, pdf=None):
    """특약 마스터의 상품 라인을 추정 — 설계서 첫 쪽 상품명 우선(v8.65).
    담보명은 읽을 때 고지유형 꼬리표((통합간편가입) 등)를 이미 떼므로 이름만으로는 늘 '케어프리'가 나왔다.
    그 결과 통합간편 설계서의 '갱신형 ○○' 담보가 같은 이름의 케어프리 레코드에 매칭되어,
    통합간편 약관의 세부보장 목록(예 32대질병관혈수술비 [5대질병] 통55-1)을 못 찾았다."""
    names = ' '.join(r['name'] for r in riders)
    ln = None
    if pdf:
        try:
            import pdfplumber
            with pdfplumber.open(pdf) as d: head = re.sub(r'\s+', '', d.pages[0].extract_text() or '')
            ln = line_from_head(head)
        except Exception:
            pass
    # 2026-11 추가 상품(올케어 수술비보험 통합간편고지형 등)은 담보에 「(통합간편가입)」 이 붙어도 통합간편건강보험이 아니다 — 상품명이 먼저다(v9.07).
    # 그 밖의 상품은 전과 같은 순서(고지 구분자 → 상품명) 그대로
    if ln in NEW_LINES_2611: return ln
    if '통합간편가입' in names: return '통합간편'
    return ln or '케어프리'

def line_from_head(head):
    """설계서 첫 쪽 글자(또는 상품명 · 띄어쓰기 없이) → 상품 라인. 못 읽으면 None(guess_line 이 '케어프리' 로 둔다).
    담보코드 입력(code_input.line_of)도 이 규칙을 쓴다 — 설계서 PDF 와 같은 상품 라인이 나와야 같은 특약을 찾는다(v9.06)"""
    if '통합간편건강보험' in head: return '통합간편'
    if re.search(r'\(무\)내Mom대로보장보험', head): return '내Mom대로'          # 스마트 제안서 전용 보강 마스터(db_terms_extra.json)(v8.66)
    if '내Mom같은어린이보험' in head: return '내Mom같은어린이'
    if '간편31건강보험' in head: return '간편31'                                # 스마트 제안서 전용 보강 마스터(v8.70)
    # 약관 4건 추가(v8.71) — 'The건강한 내Mom대로' 는 '내Mom대로' 보다 먼저 본다
    if 'The건강한내Mom대로5.10.5' in head: return 'The건강한내Mom대로5.10.5'
    if 'The건강한5.10.5' in head: return 'The건강한5.10.5'
    if 'The좋은내Mom대로' in head: return 'The좋은내Mom대로'
    if 'The가벼운간편355' in head: return 'The가벼운간편355'
    # The좋은 M-Basket(약관명 The좋은 케어프리보험 M-Basket · GA 판매명 The좋은 알파Plus · 연만기 전 특약 갱신형)(v8.77) —
    # 세만기·비갱신 기반 케어프리 M-Basket(GA 알파Plus)과 다른 상품이다. 두 판매명 약관은 본문이 같다. 이 줄이 없으면 '케어프리' 로 떨어진다
    if re.search(r'The좋은(케어프리보험|알파Plus)', head): return 'The좋은케어프리'
    # 2026-11-23 약관 추가분(v9.07) — 스마트 제안서 전용 보강 마스터. 심사형 · 고지형은 상품명에 적힌 글자로(약관 표지 「(맞춤간편심사형)」 · 「(355간편고지형)」)
    if '올케어보장꽉채운암보험' in head: return '올케어암간편' if '맞춤간편' in head else '올케어암'
    if '올케어꽉채운뇌심보험' in head: return '올케어뇌심간편' if '맞춤간편' in head else '올케어뇌심'
    if '올케어꽉채운수술비보험' in head: return '올케어수술비'
    if '올케어꽉채운골키퍼건강보험' in head: return '올케어골키퍼'
    if re.search(r'OnlyYou통합보험', head, re.I): return 'OnlyYou통합간편' if '355간편' in head else 'OnlyYou통합'
    if '성공파트너종합보험' in head: return '성공파트너'
    if '상해안심보험' in head: return '상해안심'
    return None
NEW_LINES_2611 = ('올케어암', '올케어암간편', '올케어뇌심', '올케어뇌심간편', '올케어수술비', '올케어골키퍼', 'OnlyYou통합', 'OnlyYou통합간편', '성공파트너', '상해안심')

if __name__=='__main__':
    if len(sys.argv) == 3:                      # python build_all.py 원본.pdf 결과.pdf  → 완전 자동
        orig, out = sys.argv[1], sys.argv[2]
        cust = os.path.join(BASE, 'out', '_auto_cust.json'); os.makedirs(os.path.join(BASE, 'out'), exist_ok=True)
        c = auto_meta(orig)
        import matcher
        rows = matcher.read_proposal(orig)
        c['riders'] = matcher.read_proposal(orig, line=guess_line(rows, orig))
        try:
            import desc_engine
            c['riders'], c['desc_info'] = desc_engine.attach(c['riders'], orig)
        except Exception as e:
            c['desc_info'] = {'ok': False, 'err': str(e)}
        try:                                   # 3차 안전장치(v8.41) : 설계서 뒤쪽 「특약 안내사항」 표와 금액 대조
            import verify3
            c['verify3'] = verify3.compare(c['riders'], orig)
        except Exception as e:
            c['verify3'] = [{'오류': str(e)}]
        c['src'] = os.path.basename(orig)
        json.dump(c, open(cust, 'w', encoding='utf-8'), ensure_ascii=False)
        import scen_engine as S
        print('자동 인식 —', c['insured'], c['premium'], '· 담보', len(c['riders']), '건 · 매칭', sum(1 for r in c['riders'] if r.get('matched')), '건',
              '(마스터 %(마스터)d · 부모연결 %(부모연결)d · 규칙만 %(규칙만)d · 계산제외 %(계산제외)d)' % S.recog(c['riders']))
    else:
        cust, orig, out = sys.argv[1], sys.argv[2], sys.argv[3]
    c = json.load(open(cust, encoding='utf-8'))
    ia = last_cover_page(orig); c['insert_after'] = ia; c['base_pages'] = page_count(orig)
    json.dump(c, open(cust,'w',encoding='utf-8'), ensure_ascii=False)
    os.makedirs(os.path.join(BASE,'out'), exist_ok=True)
    html = os.path.join(BASE,'out','_tmp.html'); pdf = os.path.join(BASE,'out','_tmp.pdf')
    subprocess.check_call([sys.executable, os.path.join(BASE,'gen2.py'), cust, html])
    audit = json.load(open(os.path.splitext(html)[0] + '_audit.json', encoding='utf-8'))['요약']
    if not audit.get('생성쪽수'):                # 암·뇌·심장·통합치료비 계열 담보가 없는 설계(운전자·치아 등) → 원본 그대로(v8.4)
        import shutil; shutil.copyfile(orig, out)
        print('스마트제안서 미첨부 — 대상 담보 없음 · 원본 그대로 출력 :', out, '(', c['base_pages'], '쪽 )'); sys.exit(0)
    subprocess.check_call([sys.executable, os.path.join(BASE,'render.py'), html, pdf])
    new = page_count(pdf)                      # 생성 쪽수는 gen2 구성에 따라 자동 반영
    print('담보사항 종료 쪽', ia, '· 생성', new, '쪽 → 총', merge(orig, pdf, out, insert_after=ia, new=new), '쪽')
