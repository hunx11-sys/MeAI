# 스마트 제안서 생성 API — 프론트엔드 연동 가이드

> proposal_smart v8.48 · AI추진파트 세일즈혁신TF
> **LLM·외부 API를 쓰지 않습니다.** 규칙표(rules.json)와 약관 데이터(JSON)에 따른 계산만 수행하며,
> 실행 중 외부 네트워크 통신이 없습니다. 같은 PDF를 넣으면 항상 같은 결과가 나옵니다.

## 1. 서버 띄우기

가장 쉬운 방법 — 폴더 안의 실행 파일을 두 번 누르면 설치·실행·브라우저 열기까지 한 번에 됩니다.

| 운영체제 | 실행 파일 |
|---|---|
| 윈도우 | `start_windows.bat` |
| 맥 · 리눅스 | `start.sh` |

직접 명령으로 실행할 때는 아래와 같습니다.

```bash
pip install -r requirements.txt
python -m playwright install chromium     # HTML → PDF 렌더 (최초 1회) — playwright 1.47 이상

python api.py                             # http://127.0.0.1:8080
python api.py 0.0.0.0 9000                # 호스트·포트 지정
```

추가 패키지 설치가 없습니다 — API 서버는 **파이썬 표준 라이브러리(http.server)** 로만 만들었습니다.
브라우저에서 `http://127.0.0.1:8080/` 를 열면 연동 데모 화면이 나옵니다(PDF를 끌어다 놓으면 결과가 보임).

> **주의** — `web/index.html` 파일을 탐색기에서 직접 열면 동작하지 않습니다(서버가 없어 `Failed to fetch`).
> 반드시 서버를 띄운 뒤 **주소창에 `http://127.0.0.1:8080`** 을 입력해 접속하세요.
> 파일로 열었을 때는 화면 위에 그 안내가 표시되며, 'API 주소'를 입력하고 '연결 확인'을 누르면 그 상태로도 사용할 수 있습니다.

## 2. 엔드포인트

| 메서드 | 경로 | 요청 | 응답 |
|---|---|---|---|
| GET | `/health` | — | `{"ok":true,"version":"v8.48","llm":false,"network":false}` |
| GET | `/` | — | 연동 데모 화면(HTML) |
| GET | `/assets/<파일>` | — | 지면이 쓰는 글꼴·로고(미리보기용 정적 파일) |
| POST | `/v1/proposal/pdf` | 가입설계서 PDF | **결과 PDF**(원본 + 생성 지면) `application/pdf` |
| POST | `/v1/proposal/pages.pdf` | 가입설계서 PDF | 생성 지면만 담은 PDF |
| POST | `/v1/proposal/pages.html` | 가입설계서 PDF | 생성 지면 HTML — `<iframe>`에 그대로 띄울 수 있음 |
| POST | `/v1/proposal/audit` | 가입설계서 PDF | 요약 + 감사 로그 JSON |
| POST | `/v1/proposal/riders` | 가입설계서 PDF | 인식한 담보 목록 JSON (생성 없이 빠르게 확인) |
| POST | `/v1/proposal/all` | 가입설계서 PDF | 요약 + 감사로그 + 지면 HTML + 결과 PDF(base64) 한 번에 |
| POST | `/v1/ga/pdf` · `/v1/ga/all` | 설계서 PDF | 기존 GA 양식 6쪽 PDF / JSON(PDF base64 · 감사 로그 · 인식 담보) |
| POST | **`/v1/ga2/pdf`** | 설계서 PDF | **GA 새 양식(v2 · 2026-11-18 회의 반영) PDF 13~17쪽** |
| POST | **`/v1/ga2/all`** | 설계서 PDF | 새 양식 JSON : `pages` · `detail_pages` · `care_pages`(support/use/none) · `care_pages_ko` · `rider_count` · `matched` · `riders` · `warn` · `elapsed_sec` · `log`(계산 로그) · `pdf_base64` |

| POST | **`/v1/ga2/json/pdf`** · `/all` · `/check` | 담보 목록 JSON | **담보코드 입력** — 설계서 PDF 없이 「단위상품코드 · 담보코드 · 상품담보명 · 가입금액」 으로 새 양식 PDF / JSON / 입력 점검만. 사양 · 예시는 `ga_docs/IT_GA_V2.md` 5장 · `ga_docs/code_input_example.json` · 모듈 `code_input.py` |

새 양식(v2)은 한 프로세스에서 한 번에 1건씩(줄 서서) 처리한다 — 크로뮴 하나를 같은 작업 스레드에서 쓴다. 자세한 인계 안내는 `ga_docs/IT_GA_V2.md`.

업로드 방식은 두 가지 모두 받습니다.

- `Content-Type: application/pdf` + PDF 바이트를 body 에 그대로 (fetch 권장)
- `multipart/form-data` 의 `file` 필드 (HTML `<input type="file">` 그대로)

CORS는 개발 편의를 위해 모두 열어 두었습니다(`Access-Control-Allow-Origin: *`).
운영 배포 시에는 `api.py` 의 `_cors()` 에서 사내 도메인으로 좁혀 주세요.

## 3. 호출 예

### 결과 PDF 받아 화면에 띄우기

```js
const API = 'http://127.0.0.1:8080';

const blob = await fetch(`${API}/v1/proposal/pdf`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/pdf' },
  body: file,                       // <input type="file"> 의 File 객체
}).then(r => { if (!r.ok) throw new Error('생성 실패'); return r.blob(); });

viewer.src = URL.createObjectURL(blob);
```

### 요약·지면·PDF 한 번에 받기

```js
const d = await fetch(`${API}/v1/proposal/all`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/pdf' },
  body: file,
}).then(r => r.json());

d.total_pages     // 65      결과 PDF 전체 쪽수
d.new_pages       // 9       생성한 지면 수 (0이면 대상 담보 없음)
d.insert_after    // 43      원본 43쪽 뒤에 삽입
d.rider_count     // 151     인식한 담보 수
d.matched         // 133     특약 마스터와 매칭된 담보 수
d.recog           // {마스터:137, 부모연결:14, 규칙만:0, 계산제외:0, 규칙만목록:[], 계산제외목록:[]}  담보 인식 상태(v8.61) — 넷의 합 = rider_count. 부모연결 = 1-7종 수술비 ┗ 종별 행처럼 부모 특약 마스터에 물린 담보 · 규칙만 = 마스터에 없지만 규칙표로 계산 · 계산제외 = 빈칸이 되는 담보
d.attached        // true    지면을 붙였는지
d.elapsed_sec     // 31.7    처리 시간
d.meta            // 피보험자·보험료·상품명·계약사항 등 PDF에서 읽은 값
d.audit           // 감사 로그(요약·제외 담보와 사유)
d.pages_html      // 생성 지면 HTML (iframe srcdoc 으로 바로 사용)
d.pdf_base64      // 결과 PDF (base64)
```

### 응답 예 — `/v1/proposal/audit`

```json
{
  "ok": true, "attached": true,
  "base_pages": 56, "new_pages": 9, "total_pages": 65, "insert_after": 43,
  "rider_count": 151, "matched": 151, "recog": { "마스터": 137, "부모연결": 14, "규칙만": 0, "계산제외": 0, "규칙만목록": [], "계산제외목록": [] }, "elapsed_sec": 31.7,
  "meta": { "insured": "고객님", "premium": "669,590원", "product": "(무)메리츠 The건강한 …" },
  "audit": {
    "요약": { "담보수": 151, "구조별": { "dx": 14, "surg": 56, "tx": 48, "day": 11, "care": 9,
                                        "itc": 5, "itc_unknown": 1, "life": 6, "nonmed": 1 },
              "미분류": [], "규칙수": 66, "생성쪽수": 9, "첨부": true, "제외지면": [] },
    "로그": [ { "구분": "KCD없음", "담보": "…", "사유": "…" } ]
  }
}
```

## 4. 응답 코드

| 코드 | 뜻 | 프론트 처리 제안 |
|---|---|---|
| 200 | 정상 | — |
| 400 | PDF가 아니거나(사내 보안 DRM 으로 잠긴 파일 포함) 본문이 빔 | `error` 문장을 그대로 보여 줌 |
| 422 | 설계서를 읽지 못해 만들지 않음(v8.98) — 그림 PDF(스캔 · 캡처) · 깨진 · 암호 PDF · 가입설계서가 아닌 문서 · 계산할 담보가 하나도 없음 | `error` 문장(이유 + 할 일)을 그대로 보여 줌 |
| 409 | 대상 담보가 없어 생성 지면이 없음(`pages.pdf` 요청 시) | "스마트 제안서 대상 아님" 안내 후 원본 제공 |
| 503 | 동시 처리 대기 초과 | 재시도 안내 |
| 500 | 생성 중 오류 | 오류 메시지 노출 + 원본 PDF 제공 권장 |

`attached: false` 는 오류가 아닙니다 — 운전자·치아보험처럼 암·뇌·심장·통합치료비 담보가 없는 설계는
지면을 만들지 않고 원본을 그대로 돌려줍니다.

## 5. 성능과 운영 시 고려사항

- 1건 처리에 **약 30초**(원본 56쪽 + 생성 9쪽 = 65쪽). 담보 수가 많으면 더 걸립니다.
- **실제 생성은 한 프로세스에서 한 번에 1건**입니다(9쪽 · GA 6쪽 · GA 새 양식 모두 `GA_LOCK` 으로 줄을 섬 — 설계서 상태와 계산 로그를
  모듈 안에 두므로 겹치면 로그가 섞인다). 받아 두는 요청은 2건(`LOCK`)이고, 180초 넘게 기다리면 503 입니다.
  처리량을 늘리려면 프로세스를 여러 개(포트마다) 띄우고 앞에 부하분산을 두세요(프로세스마다 메모리 약 1GB).
- 새 양식이 600초를 넘기면 504 를 돌려주고, 그 뒤로는 `/health` 가 503(`ok:false`)이 됩니다 — 서버를 다시 켜 주세요.
- 요청 상한은 60MB(`MAX_BYTES`)입니다.
- 화면에서 바로 기다리게 하지 말고 **작업 등록 → 완료 알림** 형태를 권합니다.
  프론트에서 폴링이 필요하면 작업 큐는 IT개발파트 표준 방식에 맞춰 붙이는 것이 좋습니다.
- 업로드된 PDF와 작업 폴더(9쪽 지면 · 새 양식 중간 파일)는 요청마다 임시 폴더에 만들고 응답 뒤 지웁니다. 서버가 처리 중에
  꺼져 남은 것은 서버를 켤 때와 요청이 올 때 「만든 지 1시간 넘은 것」 을 지웁니다. 결과는 서버에 저장하지 않습니다.

## 6. 파이썬에서 직접 쓰기 (API 없이)

```python
from pipeline import build

r = build('가입설계서.pdf')
r['out_pdf']      # 결과 PDF 경로
r['pages_html']   # 생성 지면 HTML 경로
r['audit']        # 감사 로그
r['attached']     # 지면을 붙였는지
```

배치에서 쓰려면 `python pipeline.py 원본.pdf 결과.pdf` 로도 실행됩니다.

### v8.19 — 응답 audit.요약 추가 항목
| 키 | 뜻 |
|---|---|
| `피보험자성별` | 설계서에서 읽은 성별(남/여) 또는 `미확인(성별 중립 사례)` |
| `사례` | 지면 8쪽 '사례로 보는 치료비 보장' 카드 3장의 병명 목록(예 `["폐암","위암","전립선암"]`) |

요청 쪽에서 성별을 알고 있으면 고객 JSON(`cust`)에 `"sex": "M"` 또는 `"F"` 를 넣어 설계서 판독값을 덮어쓸 수 있다.

### v8.48·v8.49 — 지면 검사 결과
| 키 | 뜻 |
|---|---|
| `audit.요약.지면검사` | 쪽별 자동 축소율·아래 여백, 그리고 글자가 틀 밖으로 나간 경우 `이탈`·`잘림` 항목 |
| `audit.요약.렌더러` | 실제로 찍은 크로미엄 판(예 `chromium/141.0.7390.37`). 현장에서 지면이 이상하다는 제보가 오면 생성 PC와 판을 대 볼 때 쓴다 |
| `layout_warn` (응답 최상위) | `이탈`·`잘림`이 하나라도 있을 때만 실림. 있으면 그 PDF는 검수 후 배포한다 |

`이탈`·`잘림`은 정상 동작에서는 나오지 않는다(테스트 설계 6건 모두 0건). 나온다면 글꼴이 다르게 깔렸거나
크로미엄 판이 크게 낮은 환경이므로, `렌더러` 값을 함께 보고 환경을 맞춘다.

렌더는 `playwright` 가 함께 들고 오는 크로미엄을 쓴다. **playwright 1.47 이상**(크로미엄 129 이상)을 설치한다.
