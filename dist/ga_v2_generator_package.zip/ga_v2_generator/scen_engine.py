# -*- coding: utf-8 -*-
"""설계 담보 전체(진단비·수술비·입원일당·치료비·통합치료비)에 대한 사례별 보상 계산 엔진 v3.1 (모듈 v8.3).

  ▣ 판정 근거는 두 가지뿐이다.
     ① 담보명   : rules.json 규칙표(보상구조) + 담보명 토큰(상해/질병·병원 종별·병실·한도일수·종·제외질병)
     ② 약관 KCD : db.json 의 특약별 KCD 목록 · g131.json 그룹표 · 별표3 암분류 로직(engine.cancer_cls)
     ※ KCD 목록은 어떤 경우에도 코드에서 생성·추정하지 않는다.
  ▣ 규칙표에 없는 담보가 들어와도 예외를 던지지 않는다. 계산에서 제외하고 ISSUES 에 사유를 남긴다.
     (운영 원칙 : 미매칭 담보 = 제외 + 로그)
"""
import json, os, re, sys
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import engine as itc            # 통합치료비 약관 지급금액표 엔진

# ══ 가입금액 표기 → 만원 (v8.3 : 억·천·백·십·만 조합 전부 처리, 원 단위는 0) ═══════════
# 설계서 표기 예 : 5천만원 · 1억5천만원 · 1억 5,000만원 · 3천5백만원 · 1,000만원 · 2억원 · 1억 · 간병인지원
AMT_RE = (r'간병인지원'
          r'|(?=\d)(?:\d[\d,]*억\s*)?(?:\d[\d,]*천)?(?:\d[\d,]*백)?(?:\d[\d,]*십)?(?:\d[\d,]*)?만원'
          r'|\d[\d,]*억\s*(?:\d[\d,]*천)?(?:\d[\d,]*백)?(?:\d[\d,]*십)?(?:\d[\d,]*만)?원?')
_AMT_FULL = re.compile(r'(?:(\d+)억)?(?:(\d+)천)?(?:(\d+)백)?(?:(\d+)십)?(\d+)?(만)?원?')
def amt_to_man(s):
    """'1억5천만원' → 15000. 해석 불가·원 단위(5,000원)·현물(간병인지원)은 0."""
    s = re.sub(r'[\s,]', '', s or '')
    m = _AMT_FULL.fullmatch(s)
    if not m or not any(m.groups()[:5]): return 0
    eok, cheon, baek, sip, man = (int(g) if g else 0 for g in m.groups()[:5])
    if not (eok or cheon or baek or sip or m.group(6)): return 0      # '5000원' 같은 원 단위 → 만원 미만 취급
    return eok * 10000 + cheon * 1000 + baek * 100 + sip * 10 + man

# ══ 규칙표 ══════════════════════════════════════════════════════════
RULEDOC = json.load(open(os.path.join(BASE, 'rules.json'), encoding='utf-8'))
RULES = RULEDOC['rules']
for _r in RULES:
    _r['_m'] = re.compile(_r['m'])
    _r['_x'] = re.compile(_r['x']) if _r.get('x') else None
KCDG = RULEDOC['kcd_groups']
FIVE_MAJOR = KCDG['특정5대질병']                      # 특정5대질병(대장용종·백내장·후각특정질환·특정피부질환·혈관종)

G131 = json.load(open(os.path.join(BASE, 'g131.json'), encoding='utf-8'))
SYN = json.load(open(os.path.join(BASE, 'product_data.json'), encoding='utf-8'))['EMB']['syn']   # 암종명 → KCD
# 그룹표(g131.json · 소유자 정리 엑셀)에 없는 세부보장 라벨(유방의장애 · 편도염)은 특약 마스터의 세부보장 레코드(131대질병수술비[유방의장애] 등,
# 약관 별표80·81 에서 추출)의 KCD 목록으로 채운다. 전에는 코드에 D24·J03 을 손으로 적어 두었는데 별표80(N60~N64)·별표81(J35)에 없는 코드였다 —
# 유방 양성신생물(D24) 맘모톰에 [유방의장애] 수술비가 잘못 붙었다(the510 195 → 115만원). 질병코드는 코드에서 만들지 않는다(CLAUDE.md 1)(v8.62)
# 다빈도61대(130대 · 통합간편 별표)·다빈도62대(131대 · 케어프리 별표)도 마스터 세부보장 레코드의 목록과 제외코드를 그대로 쓴다(v8.76).
# 전에는 둘 다 그룹표의 '다빈도64대' 통합표로 판정해, 세부보장 레코드가 없는 간편31 갱신형130대질병수술비(다빈도61대질병)가
# 130대에 없는 추간판장애(M50·M51 — 62대에만)와 다른 세부보장인 편도염(J35)·유방의장애(N60~N64)에도 지급됐다.
# 61대와 62대의 차이는 추간판장애뿐이다(두 약관 별표 대조 · 소유자 확인 2026-10-20).
G131X = {}          # 그룹 라벨 → 그 별표의 제외코드(예 : 다빈도61대 K23.0 · N39.3 · N39.4)
def _g131_from_master():
    _p = os.path.join(BASE, 'db.json')
    if not os.path.exists(_p): return
    have = {re.sub(r'[\s․·,]', '', k) for k in G131}
    for r in json.load(open(_p, encoding='utf-8')).get('riders') or []:
        m = re.search(r'\[([^\[\]]+)\]$', r.get('n') or '')
        if m and re.match(r'^(갱신형)?13[01]대질병수술비', r['n'].replace(' ', '')) and r.get('k'):
            lab = re.sub(r'[\s․·,]', '', m.group(1))
            if lab not in have:
                G131[lab] = list(r['k']); have.add(lab)
                if r.get('x'): G131X[lab] = list(r['x'])
_g131_from_master()

# ══ 1-7종 수술분류표 (약관 별표3, extract_surg7.py 로 생성) — 수술코드 → 종 (v8.5) ═══════════
SURG7 = {}
_p7 = os.path.join(BASE, 'surg7.json')
if os.path.exists(_p7): SURG7 = {r['code']: r for r in json.load(open(_p7, encoding='utf-8'))['rows']}
# ══ 신수술분류표 (The건강한 내Mom대로 5.10.5 약관 별표, extract_surg_new.py 로 생성) — 신수술비[기본]·[주요수술] 판정 (v8.70) ══
NEWSURG = {'basic': [], 'major': {}}
_pn = os.path.join(BASE, 'surg_new.json')
if os.path.exists(_pn): NEWSURG = json.load(open(_pn, encoding='utf-8'))
_NEWSURG_BASIC = set(NEWSURG.get('basic') or [])
NEWSURG_TYPE_KEY = [('장기이식', '장기이식'), ('개두', '개두및두부'), ('개흉', '개흉'), ('개복', '개복'), ('각막', '각막조직피부이식및조직재건'), ('경피적', '경피적')]
def surg7_grade(x):
    """사례의 1-7종 표기 : 정수(종) 그대로, 수술코드('F121' 등)는 분류표에서 종을 찾는다. 모르면 None."""
    if x is None or isinstance(x, int): return x
    r = SURG7.get(str(x).upper()); return r['grade'] if r else None
def surg7_name(x):
    r = SURG7.get(str(x).upper()) if isinstance(x, str) else None
    return r['name'] if r else ''
def surg7_group(x):
    """수술코드 → 분류표의 수술구분 이름(예 B016 → '뇌동맥류수술'). 모르면 ''."""
    r = SURG7.get(str(x).upper()) if isinstance(x, str) else None
    return (r.get('group') or '') if r else ''

# ══ 1-5종 수술분류표Ⅱ (약관 별표76, extract_surg5.py 로 생성) — 항목번호 → 종, 질병코드 예외 (v8.6) ═══
SURG5 = {}
_p5 = os.path.join(BASE, 'surg5.json')
if os.path.exists(_p5): SURG5 = {i['no']: i for i in json.load(open(_p5, encoding='utf-8'))['items']}
def surg5_grade(x, kcd=None):
    """사례의 1-5종 표기 : 정수(종) 그대로, 항목번호('33'·'88-1'·'C1' 등)는 분류표에서 종을 찾고
       '단, ○○(KCD)로 인한 수술은 N종' 예외(담석증 K80→2종, 대장 용종 D12→1종, 기타피부암 C44→3종 등)를 질병코드로 적용한다."""
    if x is None or isinstance(x, int): return x
    it = SURG5.get(str(x))
    if not it: return None
    for e in it.get('exceptions') or []:
        if kcd and (kcd == e['kcd'] or kcd.startswith(e['kcd'])): return e['grade']
    return it['grade']
def surg5_name(x):
    it = SURG5.get(str(x)) if isinstance(x, str) else None
    return it['name'] if it else ''
def surg_open(tg):
    """사례 수술이 관혈(True)인지 비관혈(False)인지 — 모르면 None (v8.55)

    약관(5대질환수술비 제5조 ⑤⑥) : 관혈 = 피부를 절개해 병변을 노출하는 수술(대뇌내시경·복강경·흉강경은
    관혈에 준함) / 비관혈 = 내시경·카테터·신의료수술. 사례에 'open' 태그가 있으면 그대로 쓰고, 없으면
    1-5종 항목으로 가린다 — 88-x(카테터·고주파·내시경 등)·C2 는 비관혈, C1 과 이름에 관혈·개흉·개복·개두가
    적힌 항목은 관혈. 그 밖은 모름."""
    if 'open' in tg: return bool(tg['open'])
    j = tg.get('surg')
    if not isinstance(j, str) or j not in SURG5: return None
    if j.startswith('88') or j == 'C2': return False
    nm = SURG5[j]['name']
    if j.startswith('C1') or any(k in nm for k in ('관혈', '개흉', '개복', '개두')): return True
    return None

# 고지유형 꼬리표 — rules.json goji_tags 한 곳에서만 관리(v8.3). matcher.py 도 이 GOJI 를 가져다 쓴다.
# 목록에 없는 새 꼬리표도 떼도록 '(… 가입)' 형태(24자 이내)는 모두 고지유형으로 본다(v8.65) — (편한가입)·(355입원,수술고지간편가입)·
# (맞춤 간편가입) 등 상품마다 붙는 꼬리표만 다르고 특약은 같다. 꼬리표가 남으면 마스터·규칙표 대조가 어긋난다.
GOJI = r'(?:\((?:%s)\)|\([^()]{1,24}가입\))' % '|'.join(re.escape(t) for t in RULEDOC['goji_tags'])
# 인수 · 전환 표시 — [특별조건부](할증보험료법 특별약관 = 보험료만 할증 · 보장 같음) · [계약전환용] · (출생전) 은 보장 알맹이가 같은
# 같은 특약이다(소유자 2026-11-09). 정보계 상품담보명에 붙어 오며, 떼지 않으면 마스터 매칭 · 통합치료비 금액표 찾기가 어긋난다(v8.89)
VARTAG = re.compile(r'\[(?:특별조건부|계약전환용)\]|\(출생전\)')
def nname(n):
    """고지유형 꼬리표·인수 표시·공백 제거 — 규칙표 매칭에 쓰는 정규화 담보명"""
    return re.sub(r'\s+', '', VARTAG.sub('', re.sub(GOJI, '', n or '')).replace('[기본계약]', '').replace('┗', ''))

# ══ 통합치료비 식별 (v8.3 : 약관 지급금액표 RIDERS 에서 자동 생성 + 보조 별칭) ═══════════
ITC_MAP = {r['nm']: r['id'] for r in itc.RIDERS}
ITC_MAP.update({'암 통합치료비(주요치료)(비급여(전액본인부담 포함))': 'ca_ncm'})
# 특정순환계질환 통합치료비Ⅱ(2026-10-31 개정안 별첨7 §5) — 통합치료항목·연간 지급횟수·금액표가 기존 특정순환계질환 통합치료비(CV)와 같다(개정안 v6.0 대조 2026-10-23 · 정식 약관으로 재확인).
# 세부보장 ①「특정순환계질환 통합치료비(통합간편가입)」은 고지 꼬리표가 떨어져 그대로 circ 에 맞고, 부모 「…Ⅱ」 는 별칭으로 잇는다. ②③ 「(연간 주요치료Ⅱ N회이상)」 은 규칙 tx_life_circ2.
ITC_MAP.update({'특정순환계질환 통합치료비Ⅱ': 'circ'})
_ITC_NORM = {nname(k): v for k, v in ITC_MAP.items()}
def noren(n):
    """설계서의 '갱신형' 접두어를 뗀 이름 — 약관 지급금액표는 갱신 여부를 구분하지 않는다(v8.20)"""
    return re.sub(r'^갱신형', '', nname(n))
def itc_id(name):
    """약관 지급금액표가 있는 통합치료비면 그 id, 아니면 None(→ 규칙표 itc_unknown 이 계산 제외+로그).
       「부모[세부보장]」 꼴(특약 마스터의 세부 레코드 · 예 : 특정순환계질환통합치료비Ⅱ[특정순환계질환 통합치료비])은 세부보장 이름으로 본다(2610 약관 · 2026-11-01)"""
    hit = _ITC_NORM.get(nname(name)) or _ITC_NORM.get(noren(name))
    if hit: return hit
    m = re.fullmatch(r'(.+?)\[(.+)\]', re.sub(GOJI, '', (name or '')).strip())        # 고지 꼬리표((통합간편가입) 등)는 떼고 본다(H3)
    if m: return _ITC_NORM.get(nname(m.group(2))) or _ITC_NORM.get(noren(m.group(2)))
    return None
# ══ 통합생활지원비 식별 (v8.36) ════════════════════════════════════════════════
# 통합생활지원비는 통합치료비와 구조가 다르다 — 산정특례 등록·치료 항목마다 **월** 단위로 지급하고
# 가입금액은 '월간 총 지급금액 한도'다. 정액 치료비로 계산하면 진단만으로 가입금액 전액이 잡히므로
# 사례 계산에서는 빼고(rules.json ls_monthly), 지면에는 약관 항목표(life_support.json)를 그대로 보여준다.
LS = {}
if os.path.exists(os.path.join(BASE, 'life_support.json')):
    LS = json.load(open(os.path.join(BASE, 'life_support.json'), encoding='utf-8'))
_LS_PAT = [('two_ls', '2대질환'), ('inj_ls', '상해'), ('dz_ls', '질병'), ('ca_ls', '암')]
def ls_id(name):
    """통합생활지원비면 그 id(ca_ls·two_ls·dz_ls·inj_ls), 아니면 None"""
    nm = noren(name)
    if '통합생활지원비' not in nm: return None
    head = nm.split('통합생활지원비')[0]
    for rid, key in _LS_PAT:
        if key in head and rid in LS: return rid
    return None
def ls_tier(rid, man):
    """가입금액(월간 총 지급금액) → 약관 항목표. 구간이 없으면 None — 금액을 추정하지 않는다."""
    t = (LS.get(rid) or {}).get('tiers') or {}
    return t.get(str(int(man))) or t.get(str(man))

INJ_KNOWN = set()                                     # 상해 통합치료비 : gen2 가 inj_itc.json 으로 별도 계산
if os.path.exists(os.path.join(BASE, 'inj_itc.json')):
    INJ_KNOWN = {nname(k) for k in json.load(open(os.path.join(BASE, 'inj_itc.json'), encoding='utf-8'))}

# 담보 → 항목표. 근거는 두 가지이며 순서가 정해져 있다.
#   ① 이 설계서 상품설명서의 담보 설명문에 실린 항목표 — 1순위(그 상품·그 가입금액의 실제 표)
#   ② 약관 지급금액표(life_support.json) — 설명문이 없을 때. 단 서로 다른 상품 약관에서
#      같은 표임을 대조한 담보만 쓴다. 확인하지 못한 금액은 만들지 않는다.
_LS_ITEMS = {}
def ls_items(r):
    """담보 → (항목표, 근거) · 근거는 'paper'(상품설명서) · 'book'(약관) · None(없음)"""
    key = id(r)
    if key in _LS_ITEMS: return _LS_ITEMS[key]
    rid = ls_id(r['name'])
    res = ([], None)
    if rid:
        v = LS.get(rid) or {}
        book = ls_tier(rid, r['man'])
        try:
            import desc_engine as DE
            paper = DE.life_items(r.get('desc') or '')
        except Exception:
            paper = []
        if paper and book:
            k = lambda xs: sorted((re.sub(r'\s', '', x['label']), x['amt']) for x in xs)
            if k(paper) != k(book):
                log('교차대조', r['name'], '상품설명서 설명문과 약관 지급금액표의 항목·금액이 달라 설명문 기준으로 표시함')
        if paper: res = (paper, 'paper')
        elif book and len(v.get('srcs') or []) >= 2: res = (book, 'book')
        elif book: log('근거부족', r['name'], '이 상품 약관·설명문에서 항목표를 확인하지 못해 계산·지면에서 제외 (다른 상품 약관 1곳에만 있어 대조 불가)')
        else: log('금액표없음', r['name'], '가입금액 %g만원 구간의 항목표가 설명문에도 약관에도 없어 계산·지면에서 제외' % r['man'])
    _LS_ITEMS[key] = res
    return res

# 사례 단계 → 통합생활지원비 항목. 약관 항목명을 그대로 읽어 맞춘다.
#   · 전신마취는 **기본(급여)만** 인정한다 — 4시간·6시간 이상 여부는 사례로 단정할 수 없다(과소 계산 쪽으로).
#   · 산정특례 등록 시점은 **질환마다 다르다**(약관 별표87~89 · 본인일부부담금 산정특례 기준).
#       암·유사암·뇌수막 양성신생물 : 등록된 암환자가 **등록일로부터 5년간** → 사실상 진단과 함께.
#                                    그래서 진단 단계에서 지급하고, 진단비 칸에도 함께 센다.
#       뇌혈관질환 : 그 상병의 치료를 위하여 【별표88-2】의 **수술을 받은 경우** 최대 30일.
#                    그 목록에 **경피적뇌혈관약물성형술(M6599 · 동맥내 혈전용해)** 이 들어 있고,
#                    수술을 받지 않아도 뇌경색은 24시간 이내 내원·NIHSS 5점 이상이면 등록된다.
#                    → **혈전용해치료도 등록 사유로 본다.**
#       심장질환   : 그 상병의 치료를 위하여 【별표89-2】의 수술 **또는 【별표89-3】의 약제** 투여 최대 30일.
#                    그 약제가 **Alteplase · Tenecteplase · Urokinase 주사제** — 전부 혈전용해제다.
#                    → **혈전용해치료만 받아도 등록**된다(약관 명시).
#     → 뇌·심장은 진단만으로 등록되지 않으므로 **수술·시술·혈전용해 단계**에서 지급하고
#       진단비 칸에는 넣지 않는다. 산정특례는 '등록당' 지급이라 한 사례에서 한 번만 센다(gen2.flow_card).
#   · 희귀질환·중증난치·중증화상·중증외상 산정특례는 사례로 단정하지 않는다.
# 유사암 = 제자리암(cis) · 경계성종양(bord) · 기타피부암(skin) · 갑상선암(thy) — 약관 별표87-2 그대로.
# 경계성종양(D37~D48)이 빠져 있어 유사암 산정특례·유사암 항암 항목이 그 사례에서 안 잡히던 것을 바로잡음(v8.47).
SIM_CLS = ('cis', 'bord', 'thy', 'skin')

def cancer_scope_ok(text, kcd):
    """담보명이나 세부급부 라벨이 암 구분을 못박았으면 사례의 암 구분이 그에 맞는지(v8.61).
       '유사암제외' → 일반암만 / '기타피부암 및 갑상선암' → C44·C73 / '갑상선암' → C73 / '기타피부암' → C44 / '유사암' → 유사암 4종.
       '…포함'(재진단암진단비(…갑상선암및전립선암포함) 등)은 범위를 넓히는 말이라 좁히지 않는다.
       전에는 '유사암 전용'만 가려서, 갑상선암(C73) 사례에 「기타피부암 및 갑상선암 항암방사선약물치료비(기타피부암)」과
       「암 주요치료비(암(유사암제외))」가 함께 붙었다(약관 통117 제1조 「기타피부암」및「갑상선암」 각각 최초 1회 · 통81 제1조 유사암 제외)."""
    t = re.sub(r'[\s․·,]', '', text or '')
    if not t or '포함' in t: return True
    dc = itc.cancer_cls(kcd)
    if dc is None: return True
    if re.search(r'유사암[^)]{0,8}제외', t): return dc == 'major'
    thy, skin = '갑상선암' in t, '기타피부암' in t
    if thy and skin: return dc in ('thy', 'skin')
    if thy: return dc == 'thy'
    if skin: return dc == 'skin'
    if '유사암' in t: return dc in SIM_CLS
    return True

def special_reg(r, sc, nm, dx):
    """산정특례대상 진단비 — 「산정특례대상으로 등록된 경우」가 지급사유다(통203·통204 제1조 등). 등록 시점은 질환마다 다르다
       (ls_lines 주석·약관 별표와 같은 근거).
       · 암·유사암·뇌수막 양성신생물 : 등록일로부터 5년 → 사실상 진단과 함께 → 진단 단계 그대로.
       · 뇌혈관 : 별표(산정특례 뇌혈관질환의 수술 · M6599 동맥내 혈전용해 포함)의 수술을 받은 경우 최대 30일
         심장   : 별표의 수술 또는 혈전용해제(Alteplase 등) 투여 → 수술·시술·혈전용해 단계에서만. 그 단계에는 진단 태그가 없으므로
                  계열 표시(series·grp)로 뇌·심을 가른다.
       · 그 밖(중증화상·중증외상·희귀·중증난치·결핵·중복암/재등록암) : 사례로 단정하지 않는다 → 계산 제외 + 로그.
       반환 (지급 가능 여부, 진단 태그)"""
    tg = sc['tags']
    if re.search(r'중복암|재등록암', nm):
        log('조건부', r['name'], '암 산정특례 재등록(중복암 · 5년 뒤 재등록) 조건 — 사례로 단정할 수 없어 계산 제외'); return False, dx
    if re.search(r'\(암|유사암|뇌·수막|뇌수막', nm): return True, dx
    if re.search(r'뇌혈관|심장', nm):
        acts = _acts(sc, True)
        if not (tg.get('surg') or 'surg' in acts or 'thromb' in acts): return False, dx
        ser = tg.get('series') or ''; grp = tg.get('grp') or []
        if '뇌혈관' in nm and (dx == 'brain' or ser == 'brain' or '뇌혈관질환' in grp): return True, 'brain'
        if '심장' in nm and (dx == 'heart' or ser == 'heart' or '심장질환' in grp): return True, 'heart'
        return False, dx
    log('조건부', r['name'], '산정특례 등록 조건(중증화상·중증외상·희귀·중증난치·결핵 등)은 사례로 단정할 수 없어 계산 제외'); return False, dx

# 통합치료비·통합생활지원비의 **항목 한정 면책**(v8.61). 특약 전체 제외코드(x)가 아니라 「종합병원 전신마취치료」항목에만 적용되는
# 질병 목록이라 db.json 의 x 에는 넣지 않고 규칙표 kcd_groups 에 둔다(코드는 약관 조문 원문 그대로).
#   질병 통합치료비        : 통139 · 케233 제16조③  → 전신마취치료(6시간이상) 항목
#   암전후관련 통합치료비  : 케N397 제22조②③(방사선직장염 K62.7) → 전신마취치료(6시간이상) 항목
#   질병 통합생활지원비    : 케401 제17조② → 전신마취치료(급여 · 4시간이상 · 6시간이상) 3항목
ANES_X_GROUP = '전신마취치료 항목면책(질병 통합치료비·질병 통합생활지원비)'
ITC_ITEM_X = {'dz': {'anes6': ANES_X_GROUP}, 'pre': {'anes6': '전신마취치료 항목면책(암전후관련 통합치료비)'}}

def _ls_evkeys(sc):
    ks = set()
    for ev in (sc.get('itc_events') or []):
        if len(ev) > 3: ks |= set(ev[3] or [])
    return ks

def ls_lines(r, sc):
    """이 사례 단계에서 통합생활지원비가 얼마 나오는지 → [(항목명, 금액)] · 합계는 월간 한도(가입금액)까지"""
    items, src = ls_items(r)
    if not items: return [], False
    tg = sc.get('tags') or {}
    rid = ls_id(r['name'])
    # 원인 조건(v8.61) — 상해 통합생활지원비(케396 제1조②)는 '상해의 치료를 직접적인 목적으로' 받은 주요치료만,
    # 질병·암 통합생활지원비(케401·케235 제1조②)는 '대상상병으로 진단확정되고 그 치료를 직접적인 목적으로' 받은 것만.
    # 2대질환(케255 제1조①)은 질병 또는 상해로 뇌·심장 산정특례에 등록되면 지급하므로 원인을 가리지 않는다.
    if rid == 'inj_ls' and tg.get('cause') != '상해': return [], False
    inj_case = tg.get('cause') == '상해'
    ks = _ls_evkeys(sc)
    code = sc.get('kcd') or ''
    dc = itc.cancer_cls(code)
    dx = tg.get('dx') or ''
    grp = tg.get('grp') or []
    # 계열 판정 — 진단 태그·질병군 말고 'series' 로도 본다.
    # 혈전용해 같은 단계는 질병군 태그를 달면 그 그룹의 다른 담보까지 지급되어 버리므로,
    # 계산에 영향을 주지 않는 표시 태그를 따로 둔다.
    ser = tg.get('series') or ''
    brain = (dx == 'brain') or (ser == 'brain') or ('뇌혈관질환' in grp)
    heart = (dx == 'heart') or (ser == 'heart') or ('심장질환' in grp)
    # 입원·재활처럼 진단 태그가 없는 단계도 사례 질병코드가 약관 산정특례 목록(규칙표 kcd_groups · 별표 원문)에 들면 그 계열로 본다(v8.61).
    # 2대질환 통합생활지원비는 「질병 또는 상해로」 등록되면 지급하므로(통145 제1조①) 외상성 두개내손상(S06 · 별표 뇌혈관 목록)도 여기서 뇌 계열이 된다.
    brain = brain or code_hit(KCDG.get('중증질환자(뇌혈관질환) 산정특례대상') or [], code)
    heart = heart or code_hit(KCDG.get('중증질환자(심장질환) 산정특례대상') or [], code)
    anes = bool(tg.get('anes'))                       # 전신마취 수술인지는 사례에 명시된 것만 본다
    anes_h = tg.get('anes_h') or 0                    # 마취시간(시간 · 사례의 가정값) — 없으면 기본(급여) 항목만
    surgstep = bool(tg.get('surg')) or ('surg' in ks)  # 이 단계에서 수술·시술을 받았는지
    icu = bool(tg.get('icu')) or ('icu' in ks)
    chemo = bool(tg.get('chemo')) or ('chemo' in ks)
    rad = bool(tg.get('rad')) or ('rad' in ks)
    thromb = ('thromb' in ks)
    rehab = ('rehab' in ks)
    regstep = surgstep or thromb                      # 뇌·심장 산정특례 등록 사유(수술 또는 혈전용해)
    got = []
    for it in items:
        lb = re.sub(r'\s', '', it['label'])
        amt = it['amt']
        if amt <= 0: continue
        # 질병·암 통합생활지원비의 주요치료 항목(케401 제3조③⑦~⑪ · 케235 제1조②)은 '진단확정된 질병(암)의 치료를 직접적인 목적으로' 받은 것만 —
        # 상해 사례에는 산정특례 행(질병 또는 상해로 등록 : 뇌혈관·심장·중증난치)만 남긴다(v8.61)
        if inj_case and rid in ('dz_ls', 'ca_ls') and it['grp'] != '산정특례': continue
        # 계열 담보의 주요치료 항목은 그 계열의 치료일 때만(v8.61) — 2대질환(통145·케255 제1조③ 「2대질환」의 치료를 직접적인 목적으로 …
        # 전신마취·중환자실·혈전용해 각 호) 은 뇌·심장 사례만, 암(케235)은 암·유사암 사례만. 종전에는 중환자실·혈전용해가 계열을 안 가려
        # 폐암 수술·교통사고 개두술에도 2대질환 통합생활지원비의 중환자실 항목이 붙었다.
        if it['grp'] != '산정특례':
            if rid == 'two_ls' and not (brain or heart): continue
            if rid == 'ca_ls' and dc is None: continue
        hit = False
        if it['grp'] == '산정특례':
            if '유사암' in lb and '제외' not in lb: hit = bool(dx) and (dc in SIM_CLS)   # 별표87-2 : C44·C73·D00~D09·D37~D48
            elif '암(' in lb or lb.startswith('중증질환자(암'): hit = bool(dx) and (dc == 'major')
            elif '뇌·수막' in lb or '뇌·수막의양성신생물' in lb: hit = bool(dx) and bool(re.match(r'^D3[23]', code))
            elif '뇌혈관' in lb: hit = brain and regstep       # 수술 또는 혈전용해로 등록(별표88-2 M6599)
            elif '심장' in lb: hit = heart and regstep         # 수술 또는 혈전용해제 투여로 등록(별표89-2·89-3)
            else: hit = False                          # 희귀·중증난치·중증화상·중증외상 — 사례로 단정하지 않는다
        elif '전신마취' in lb:
            # 약관 항목표는 (급여) / (급여, 4시간이상) / (급여, 6시간이상) 세 항목이 각각 '치료 1회당' — 마취시간이 구간에 들면
            # 그 항목도 함께 지급한다. 「종합병원」항목이므로 병원 종별을 보고, 계열 담보는 그 계열의 치료일 때만 :
            #   2대질환(케255 제1조②) = 「2대질환」의 치료 목적 → 뇌·심장 사례만 / 암(케235) = 행 이름의 암(유사암제외)·유사암 구분
            #   질병(케401 제17조②) = 정신질환·임신출산·선천기형·비만·요실금·치핵·치과질환 치료의 전신마취 항목은 지급하지 않음(v8.61)
            hit = anes and hosp_ok('종합', tg.get('hosp'))
            if '6시간이상' in lb: hit = hit and anes_h >= 6
            elif '4시간이상' in lb: hit = hit and anes_h >= 4
            if rid == 'ca_ls': hit = hit and _ls_cancer_row(lb, dc)
            elif rid == 'dz_ls' and hit and code_hit(KCDG.get(ANES_X_GROUP) or [], code):
                hit = False; log('면책', r['name'], '%s — 약관 제17조② 항목 한정 면책 질병(%s)이라 전신마취 항목 제외' % (it['label'], code))
        elif '중환자실' in lb:
            hit = icu
        elif '항암방사선' in lb:
            hit = rad and _ls_cancer_row(lb, dc)
        elif '항암약물' in lb:
            hit = chemo and _ls_cancer_row(lb, dc)
        elif '혈전용해' in lb:
            hit = thromb
        elif '재활' in lb:
            hit = rehab and '전문재활' in lb and '전문외' not in lb and '외래' not in lb
        if hit: got.append((it['label'], amt, it['grp']))
    tot = sum(a for _l, a, _g in got)
    if tot <= r['man']: return got, False
    # 월간 총 지급금액 한도 — 한 달에 받는 합계는 가입금액까지
    out, left = [], r['man']
    for l, a, g in sorted(got, key=lambda x: -x[1]):
        if left <= 0: break
        out.append((l, min(a, left), g)); left -= min(a, left)
    return out, True

def _ls_cancer_row(lb, dc):
    """'암(유사암제외) 항암…' / '유사암 항암…' 행 가리기"""
    if lb.startswith('유사암'): return dc in SIM_CLS
    if '암(유사암제외)' in lb: return dc == 'major'
    return dc is not None

ISSUES = []                                           # 미분류·검토필요 로그(운영 점검용)
def log(kind, name, reason):
    it = {'구분': kind, '담보': name, '사유': reason}
    if it not in ISSUES: ISSUES.append(it)

# 특약 마스터(db.json)가 담고 있는 상품 — 로그 문구에 '어느 약관 데이터에 없는지'를 적기 위해 읽는다(v8.61)
_pdb = os.path.join(BASE, 'db.json')
DB_PRODUCTS = (json.load(open(_pdb, encoding='utf-8')).get('meta') or {}).get('products') or [] if os.path.exists(_pdb) else []

def no_master_why(r, what):
    """'KCD 목록이 없다'는 로그를 두 경우로 가른다(v8.61).
       · 담보 자체가 마스터에 없다(matched False) : 설계 상품의 약관이 데이터(6개 상품)에 없는 것 —
         다른 상품의 같은 이름 담보로 대신 계산하지 않고 빈칸으로 둔다(CLAUDE.md 1·4).
       · 마스터에는 있는데 목록만 비어 있다 : 마스터 보강 대상."""
    if r.get('matched') is False:
        return ('이 담보는 특약 마스터(약관 데이터 : %s)에 없다 — 설계 상품의 약관이 데이터에 없어 %s을 붙일 수 없으므로 지급 판정 제외. '
                '다른 상품의 같은 이름 담보로 대신 계산하지 않음(약관 데이터 추가 전까지 빈칸)') % ('·'.join(DB_PRODUCTS) or 'db.json', what)
    nm = re.sub(r'\s', '', r.get('name') or '')
    for key, why in NO_KCD_BY_TERMS.items():
        if key in nm: return why
    return '특약 마스터에 %s이 없어 지급 판정 제외 (마스터 보강 필요)' % what

# 약관이 질병코드 별표 대신 정의 조문으로 정해 목록이 원래 없는 세부보장 — 「마스터 보강 필요」 가 아니다(v8.93 · 소유자 2026-11-10 문구)
NO_KCD_BY_TERMS = {
    '중증화상및부식': '약관이 체표면적 기준(신체표면적 20% 이상 3도 화상 · 부식, 제6조)으로 정하여 기준에서 제외함 — 질병코드 목록 없음',
}

def issues_grouped(items=None):
    """같은 구분·사유의 로그를 담보 그룹 1줄로 묶는다(v8.61). 예) '1-7종 수술분류표 종 구분이 사례에 없어 계산 제외' 14줄 → 1줄.
       담보명은 '담보목록'에 모두 남기므로 정보는 잃지 않는다. 사유가 담보마다 다른 로그(3차대조 등)는 그대로 한 줄씩."""
    out, idx = [], {}
    for it in (ISSUES if items is None else items):
        key = (it['구분'], it['사유'])
        if key in idx:
            g = out[idx[key]]
            if it['담보'] not in g['담보목록']: g['담보목록'].append(it['담보'])
            g['담보'] = '%s 외 %d건' % (g['담보목록'][0], len(g['담보목록']) - 1) if len(g['담보목록']) > 1 else g['담보목록'][0]
        else:
            idx[key] = len(out); out.append(dict(it, 담보목록=[it['담보']]))
    return out

def recog(riders):
    """담보 인식 상태 집계(v8.61) — 「마스터」(설계서 담보명이 특약 마스터에 있음) · 「부모연결」(┗ 세부 행을 부모
       특약의 마스터에 물림 : 1-7종 수술비 종별 행) · 「규칙만」(마스터에 없지만 규칙표로 계산됨) · 「계산제외」(마스터에도
       없고 규칙이 없거나 약관 KCD 목록이 필요한데 없어 빈칸이 되는 담보). 넷의 합 = 담보 수.
       전에는 matched 한 숫자만 있어 부모연결·규칙만 담보가 모두 '미인식'으로 보고됐다."""
    c = {'마스터': 0, '부모연결': 0, '규칙만': 0, '계산제외': 0, '규칙만목록': [], '계산제외목록': []}
    for r in riders:
        if r.get('matched'):
            c['부모연결' if r.get('via') else '마스터'] += 1; continue
        if r.get('itc') or ls_id(r['name']):                        # 통합치료비·생활지원비는 금액표 엔진이 계산
            c['규칙만'] += 1; c['규칙만목록'].append(r['name']); continue
        rule = classify(r['name']); o = (rule or {}).get('opt') or {}
        calc = rule is not None and rule['kind'] in HANDLER and not (o.get('kcd') in ('codes', 'codes_listed') and not r.get('codes'))
        if calc: c['규칙만'] += 1; c['규칙만목록'].append(r['name'])
        else: c['계산제외'] += 1; c['계산제외목록'].append(r['name'])
    return c

_CC = {}
_XSUB = re.compile(r'\[[^\]]*(진단비|치료비|수술비|입원일당|통원일당)[^\]]*\]')
_SUBN = re.compile(r'\[([^\[\]]+)\]\]*$')   # 겹대괄호 '…[암치료,후유장해및진단비[항암약물치료비]]' 의 안쪽 세부보장도 읽는다(v8.63 · 또177·또211)


def _rule_for(nm):
    for r in RULES:
        if not r['_m'].search(nm): continue
        if r['_x'] and r['_x'].search(nm): continue
        # 부모 담보명에 '사망·후유장해'가 섞여 있어도 세부급부가 진단비·치료비 등 계산 대상이면
        # 사망·후유장해 규칙을 건너뛴다 — 예) 암후유장해및진단비[암진단비(유사암제외)] (v8.8)
        if r['kind'] == 'life' and _XSUB.search(nm): continue
        return r
    return None


def classify(name):
    """담보명 → 규칙(rules.json). 없으면 None.

    세부급부가 있는 담보(부모[세부])는 **세부급부가 보상 유형을 정한다**(v8.23).
    '암치료,후유장해및진단비[표적항암약물허가치료비…]' 처럼 부모 이름만 보면 진단비로 읽히지만
    실제 지급 대상은 세부급부(치료비)다. 부모 이름만 보고 단정하지 않는다.
    다만 부모 규칙이 세부급부명으로 암종·치료를 다시 읽는 구조(by_benefit)면 부모를 그대로 둔다.
    """
    nm = nname(name)
    if nm in _CC: return _CC[nm]
    hit = _rule_for(nm)
    m = _SUBN.search(nm)
    if m:
        sub = _rule_for(m.group(1))
        if sub and (hit is None or (not (hit.get('opt') or {}).get('by_benefit') and sub['kind'] != hit['kind'])):
            hit = sub
    _CC[nm] = hit
    return hit

# ══ 담보명 토큰 ════════════════════════════════════════════════════
HOSP = [('상급종합병원', '상급종합'), ('요양병원', '요양'), ('종합병원', '종합')]
def tokens(nm):
    t = {}
    t['cause'] = '상해' if ('상해' in nm or '재해' in nm) else ('질병' if '질병' in nm else None)
    t['ex_hosp'] = '요양' if '요양병원제외' in nm else None            # '(요양병원제외)' 는 요양병원 입원을 빼는 조건이지 요양병원 요구가 아니다(v8.12)
    _nm = nm.replace('요양병원제외', '')
    t['hosp'] = next((v for k, v in HOSP if k in _nm), None)
    t['room'] = '1인실' if ('1인실' in nm and '2-3인실' not in nm) else ('2-3인실' if '2-3인실' in nm else None)
    m = re.search(r'(\d+)일한도', nm);        t['limit'] = int(m.group(1)) if m else None
    m = re.search(r'\((\d+)일이상', nm);      t['minday'] = int(m.group(1)) if m else None
    m = re.search(r'[\[(](상해|질병)?(\d)종[,\])]', nm)
    t['gkind'] = m.group(1) if m else None;   t['gj'] = int(m.group(2)) if m else None
    t['icu'] = '중환자실' in nm
    t['visit'] = '통원' in nm
    t['plus'] = '(plus)' in nm
    t['ex'] = re.findall(r'특정(\d)대질병제외', nm)
    return t

# ══ KCD 판정 ═══════════════════════════════════════════════════════

HRANK = {'의원': 0, '병원': 1, '종합': 2, '상급종합': 3}
def hosp_ok(need, have):
    """담보가 요구하는 병원 종별(need)을 사례의 병원(have)이 충족하는지.
       상급종합병원 = 종합병원 중에서 보건복지부장관이 지정 → 종합병원 조건도 함께 충족한다."""
    if not need: return True
    if need == '요양' or have == '요양': return need == have
    if have in (None, '모든'): return False
    return HRANK.get(have, 0) >= HRANK.get(need, 0)

def is_cancer(kcd):
    """암·유사암(제자리암 포함) 여부 — 131/130대질병수술비 등 일반 질병 담보 대상에서 제외"""
    return bool(itc.cancer_cls(kcd))

RNG = re.compile(r'^([A-Z])(\d{2})~([A-Z])(\d{2})$')
# 세분류 범위 표기 — 약관·마스터가 'Q26.0~Q26.4' 처럼 적는 것(v8.51). 앞의 RNG 는 3자리 범위만 읽어
# 이 표기가 어느 갈래에도 걸리지 않고 조용히 대상에서 빠졌다(산정특례·중증화상·5대골절 등 34건).
RNG_SUB = re.compile(r'^([A-Z]\d{2})\.(\d{1,2})~([A-Z]\d{2})\.(\d{1,2})$')
def code_hit(codes, kcd):
    """약관 KCD 목록(개별코드·세분류·범위표기 A15~A19·제외표기 !N74.0 모두 지원) 대조"""
    if not codes: return False
    c3 = kcd.split('.')[0]
    m3 = re.match(r'^([A-Z])(\d{2})', c3)
    for e in codes:                                   # 제외 코드가 먼저 (v8.6 : 131대질병 그룹표 '(N74.0제외)' 등)
        if e.startswith('!'):
            x = e[1:].strip()
            if kcd == x or kcd.startswith(x + '.') or (len(x) == 3 and c3 == x): return False
    for e in codes:
        e = e.strip()
        if e.startswith('!'): continue
        if kcd == e or kcd.startswith(e + '.') or c3 == e or e.startswith(kcd + '.'): return True
        r = RNG.match(e)
        if r and m3 and r.group(1) == m3.group(1) == r.group(3) and int(r.group(2)) <= int(m3.group(2)) <= int(r.group(4)):
            return True
        rs = RNG_SUB.match(e)                         # 'Q26.0~Q26.4' — 세분류 자리로 비교(v8.51)
        if rs and rs.group(1) == rs.group(3) == c3 and '.' in kcd:
            sub, w = kcd.split('.', 1)[1], len(rs.group(2))
            if sub[:w].isdigit() and int(rs.group(2)) <= int(sub[:w]) <= int(rs.group(4)):
                return True
    return False

def excluded(r, kcd):
    """특약 마스터의 제외코드(x : 보상하지 않는 질병 — 질병수술비의 치핵·비만·정신질환·선천기형 등)에 해당하면 True (v8.7)"""
    ex = r.get('excl') or []
    return bool(ex) and code_hit(ex, kcd)

_p13 = os.path.join(BASE, 'cancer13.json')
C13 = json.load(open(_p13, encoding='utf-8')) if os.path.exists(_p13) else {'groups': {}, 'alias': {}}
_C13N = {re.sub(r'[\s()·,]|전이포함', '', k): v for k, v in C13['groups'].items()}
for _a, _t in (C13.get('alias') or {}).items():
    _C13N.setdefault(re.sub(r'[\s()·,]|전이포함', '', _a), C13['groups'][_t])
def c13_codes(name):
    """세부급부 암종명 → 약관 별표 「암종별(13종)통합암(전이포함)(유사암제외) 분류표」 질병코드"""
    return _C13N.get(re.sub(r'[\s()·,]|전이포함', '', name or ''))

def g131_key(label):
    l = re.sub(r'[\s․·,]', '', label or '')
    for cand in (l, re.sub(r'다빈도\d+대질병', '다빈도64대질병', l)):   # 다빈도61대·62대는 그 별표 그대로, 없을 때만 64대 통합표(v8.76)
        for k in G131:
            if re.sub(r'[\s․·,]', '', k) == cand: return k
    return None

def _pn(s): return re.sub(r'[\s․·,]', '', s or '')
def grp_hit(nm, sc, r=None):
    """약관 KCD 목록이 없는 담보 : 사례가 선언한 질병군(grp)이 담보명·세부급부에 들어 있으면 대상으로 본다."""
    lab = _pn((r or {}).get('benefit') or (r or {}).get('sub') or '')
    for g in sc['tags'].get('grp') or []:
        g = _pn(g)
        if g and (g in _pn(nm) or g == lab): return True
    return False

DXFAM = {'cancer': '암', 'sim_cancer': '암', 'brain': '뇌', 'heart': '심장'}

_BRAIN3 = lambda c: c.startswith('I6') or c.startswith('G45')
_HEART3 = lambda c: c[:2] in ('I2', 'I4', 'I5')
_SPAN = {}


def spans_brain_heart(codes):
    """약관 KCD 목록이 뇌(I6·G45)와 심장(I2·I4·I5) 두 계열에 **모두** 걸쳐 있는가.

    sub_ok 가 원래 막으려던 것은 5대질환수술비처럼 마스터가 두 계열 코드를 한 목록에
    묶어 둔 담보다. 목록이 한 계열만 담고 있으면 좁힐 이유가 없다(v8.51).
    """
    key = tuple(codes)
    if key in _SPAN: return _SPAN[key]
    c3 = set()
    for e in codes:
        e = e.strip().lstrip('!')
        m = RNG.match(e)
        if m:
            c3.update('%s%02d' % (m.group(1), i) for i in range(int(m.group(2)), int(m.group(4)) + 1))
        else:
            c3.add(e.split('.')[0])
    _SPAN[key] = any(_BRAIN3(c) for c in c3) and any(_HEART3(c) for c in c3)
    return _SPAN[key]


def sub_ok(r, kcd):
    """세부급부/하위그룹 라벨이 뇌·심장 질병군을 가리키면 그 계열 코드에만 지급.

    담보의 약관 KCD 목록이 두 계열에 걸쳐 있을 때만 좁힌다(v8.51). 그 전에는 담보명만 보고
    좁혀서, 약관 목록이 한 계열만 담은 담보까지 깎였다 — 중증질환자(심장질환) 산정특례
    진단비가 I01·I05~I09·I30~I39·I71·Q20~Q26 등에서, (뇌혈관질환) 산정특례가 I72.0·I77.0·
    Q28·S06 에서 0원으로 계산되던 문제.
    """
    codes = r.get('codes') or []
    if not spans_brain_heart(codes): return True
    lab = ((r.get('sub') or '') + (r.get('benefit') or '') + r.get('name', '')).replace(' ', '')
    brain = any(k in lab for k in ('뇌졸중', '뇌혈관', '뇌출혈', '뇌경색'))
    # '심장질환' 만 찾으면 「5대질환(심장,뇌혈관,…)수술비」 가 뇌 전용으로 읽혀 심장 코드가
    # 전부 막혔다 — 담보명에 '심장' 만 적힌 경우도 심장 계열 표시로 본다(v8.51)
    heart = any(k in lab for k in ('심장', '허혈성', '심근경색', '협심증'))
    if brain and not heart: return _BRAIN3(kcd)
    if heart and not brain: return _HEART3(kcd)
    return True
def kcd_ok(mode, r, sc, nm, o=None):
    """mode : major / sim / major_or_sim / codes / codes_listed / g131 / group / hc / none
       o    : 규칙 opt — 'grp' 가 있으면 담보명에서 찾지 않고 그 그룹표를 쓴다(v8.25)"""
    kcd = sc['kcd']
    if mode in (None, 'none'): return True
    if mode == 'hc':                                        # 약관 별표의 진료행위(수가)코드 ∩ 사례 단계의 수가코드(v8.14)
        if not r.get('hc'):                                 # 목록이 비어 있으면 조용히 0 이 아니라 사유를 남긴다(v8.61)
            log('수가코드없음', r['name'], no_master_why(r, '약관 별표 진료행위(수가)코드 목록')); return False
        return bool(set(r['hc']) & set(sc['tags'].get('hc') or []))
    if mode == 'major': return itc.cancer_cls(kcd) == 'major'
    if mode == 'sim': return itc.cancer_cls(kcd) in ('cis', 'bord', 'thy', 'skin')
    if mode == 'major_or_sim': return bool(itc.cancer_cls(kcd))
    # 암(유사암제외)·기타피부암·갑상선암 — 세기조절·양성자·중입자·표적·면역·암재활 약관의 대상(제자리암 D00~D09·경계성종양 D37~D48 은 아님)(v8.63)
    if mode == 'major_thy_skin': return itc.cancer_cls(kcd) in ('major', 'thy', 'skin')
    if mode == 'by_name_cancer':                            # 세부보장명이 대상 암을 정하는 담보(항암방사선·약물치료비Ⅱ · 2026-10-31 개정안) : 기타피부암 → skin · 갑상선암 → thy · 그 밖(암(유사암제외)) → major
        want = 'skin' if '기타피부암' in nm else ('thy' if '갑상선암' in nm else 'major')
        return itc.cancer_cls(kcd) == want
    if mode == 'g131':
        # 세부보장 레코드(마스터 [○○] 자식 · 설계서가 (○○) 괄호로 적어 그 자식에 매칭된 담보)에 약관 KCD 목록이 있으면 그 목록이 우선(v8.62).
        # 전에는 라벨이 있으면 그룹표(g131.json · 소유자 정리 엑셀의 '다빈도64대' 통합표)로 판정해, 케어프리 131대(다빈도62대)·통합간편 130대(다빈도61대)
        # 별표와 다른 코드(J35 편도염 · N60~N64 유방 은 다른 세부보장 · M50·M51 추간판장애는 62대에만)가 섞였다. 약관 별표(마스터)가 맞다.
        if r.get('codes') and (r.get('sub_rec') or re.search(r'\[[^\]]+\]\s*$', r['name'])): return code_hit(r['codes'], kcd)
        key = g131_key(r.get('benefit') or r.get('sub') or '')
        if key: return code_hit(G131[key], kcd) and not (G131X.get(key) and code_hit(G131X[key], kcd))
        # 130대질병수술비[○○]처럼 세부급부 라벨 없이 담보명에 질병군이 붙은 담보는 특약 마스터의 약관 KCD 목록으로 판정한다.
        # 전에는 사례가 선언한 질병군(grp)으로만 맞춰서, 뇌경색·심근경색 사례에 [특정31대질병] 1,000만원이 붙고
        # 편도염·담석증 등에는 [다빈도61대질병]이 빠졌다(사례 grp 는 131대 이름 '다빈도62대')(v8.55).
        # 131대질병수술비(○○)처럼 괄호형 담보는 마스터 목록이 131대 전체(부모) 목록이라 질병군을 가를 수 없으므로 종전대로 둔다.
        if r.get('codes') and re.search(r'\[[^\]]+\]\s*$', r['name']): return code_hit(r['codes'], kcd)
        return grp_hit(nm, sc, r)
    if mode == 'group':
        key = (o or {}).get('grp')                          # 규칙이 그룹표를 직접 지정한 경우
        if not key:
            # 담보명에 들어 있는 그룹명 중 가장 긴 것 — '10대특정암(전이포함)'이 '10대특정암'보다 우선(v8.8)
            _n = nm.replace(' ', '')
            key = max((g for g in KCDG if not g.startswith('_') and g.replace(' ', '') in _n), key=len, default=None)   # 그룹명 띄어쓰기 무시(v8.12)
        lst = KCDG.get(key) if key else None
        if not lst:
            log('KCD없음', r['name'], f'{key or "세부급부"} 분류표가 규칙표에 없어 지급 판정 제외 (약관 별표 보강 필요)'); return False
        return code_hit(lst, kcd)
    if mode == 'codes_listed':
        # 약관이 대상 질병을 정해 둔 검사비 담보(예 3대질환 MRI촬영검사비 = 암·유사암·뇌혈관·허혈성심장)인데
        # 규칙에 질병 조건이 없어 어떤 질병이든 잡히던 것을 막는다. 마스터에 목록이 없는 담보는 종전대로(v8.53).
        if not r.get('codes'):
            log('검토필요', r['name'],
                '특약 마스터에 약관 KCD 목록이 없어 질병 조건 없이 계산 — 약관에 대상 질병 제한이 있는지 확인 필요')
            return True
        return sub_ok(r, kcd) and code_hit(r['codes'], kcd)
    if mode == 'codes':
        if not sub_ok(r, kcd): return False
        if r.get('codes'): return code_hit(r['codes'], kcd)
        if grp_hit(nm, sc, r): return True
        log('KCD없음', r['name'], no_master_why(r, '약관 KCD 목록'))
        return False
    return False

# ══ 구조별 지급 계산 ═══════════════════════════════════════════════
def _acts(sc, with_done=False):
    a = set(sc['tags'].get('acts') or [])
    if with_done: a |= set(sc['tags'].get('done') or [])
    for ev in sc.get('itc_events') or []:
        if len(ev) > 3: a.update(ev[3])
    if sc['tags'].get('surg'): a.add('surg')
    # 전신마취 — 사례에 anes=1 이 적힌 단계만 본다. 마취시간 anes_h(시간 · 사례의 가정값)가 4·6시간 이상이면
    # 그 구간 행위(anes4 · anes6)도 받은 것으로 본다. 약관(종합병원 전신마취치료비 3종 제2조①) : 마취시간은
    # 전신마취치료 1회당 기준이고 2회 이상 받아도 더하지 않는다 → 단계(수술) 하나씩 따로 판정한다(v8.61).
    if sc['tags'].get('anes'):
        a.add('anes')
        _h = sc['tags'].get('anes_h') or 0
        if _h >= 4: a.add('anes4')
        if _h >= 6: a.add('anes6')
    if 'immune' in a: a.add('target')      # 면역항암 치료 시 표적항암약물허가치료 합산(약관)
    return a

def h_dx(r, o, sc, nm, t):
    tg = sc['tags']
    dx = tg.get('dx')
    if o.get('reg'):                                            # 산정특례 등록 조건부 진단비(v8.61)
        ok, dx = special_reg(r, sc, nm, dx)
        if not ok: return []
    if not dx and o.get('cause') != '상해': return []
    if o.get('fam') and DXFAM.get(dx) not in o['fam']: return []
    if o.get('cause') and tg.get('cause') != o['cause']: return []
    if bool(tg.get('recur')) != (o.get('stage') == 'recur'): return []     # 재진단 단계에서는 재진단암 진단비만, 첫 진단 단계에서는 그 밖의 진단비만(v8.12)
    if not kcd_ok(o.get('kcd'), r, sc, nm, o): return []
    freq = 'year' if '연간1회한' in nm else o.get('freq', 'once')      # 산정특례 진단비(연간1회한) 등 담보명이 연 1회로 정한 것(v8.61)
    return [(r['man'], o.get('why', '진단확정'), o.get('group', '진단비'), freq)]

def h_surg(r, o, sc, nm, t):
    tg = sc['tags']; j = tg.get('surg')
    if 'surg' not in _acts(sc): return []
    cause = t['cause'] or o.get('cause')
    if cause and tg.get('cause', '질병') != cause: return []
    if not hosp_ok(t['hosp'], tg.get('hosp')): return []
    if o.get('grade') == '1-5':
        if not t['gj']: return []
        if t['gkind'] and t['gkind'] != tg.get('cause', '질병'): return []
        j5 = surg5_grade(j, sc['kcd'])                   # 정수 또는 분류표 항목번호(v8.6)
        if j5 is None:
            log('검토필요', r['name'], '1-5종 수술분류표에 없는 항목 %s — 계산 제외' % j); return []
        if t['gj'] != j5: return []
        if o.get('plus') and tg.get('surg_cnt', 1) < 2: return []
    elif o.get('grade') == '1-7':
        g7 = surg7_grade(tg.get('surg7'))                # 정수 또는 분류표 수술코드(v8.5)
        if g7 is None:
            log('검토필요', r['name'], ('1-7종 수술분류표에 없는 수술코드 %s — 계산 제외' % tg.get('surg7')) if tg.get('surg7')
                else '1-7종 수술분류표 종 구분이 사례에 없어 계산 제외')
            return []
        if t['gj'] and t['gj'] != g7: return []
    elif o.get('new'):                                # 신수술비[기본]·[주요수술] — 사례 수술코드(ADRG)로만 판정 (v8.70)
        code = str(tg.get('surg7') or '').upper()
        lab0 = re.sub(GOJI, '', r['name']).split(']')[-1].replace(' ', '')          # 세부보장 글자 : 대괄호 뒤 괄호 '(입원, 수술코드당 연간3회한)' · '(개복, …)'
        if not re.search(r'입원|통원|장기이식|개두|개흉|개복|각막|경피적', lab0):
            log('검토필요', r['name'], '신수술비 부모 행 — 세부보장(입원/통원 · 수술종류) 행만 계산'); return []
        if not code:
            log('검토필요', r['name'], '신수술분류표 판정에 쓸 수술코드(ADRG)가 사례에 없어 계산 제외'); return []
        if o['new'] == 'basic':
            if code not in _NEWSURG_BASIC:
                log('검토필요', r['name'], '신수술분류표[기본]에 없는 수술코드 %s — 계산 제외' % code); return []
            adm = 'out' if tg.get('adm') == 'out' else 'in'        # 사례 가정 : 적지 않으면 2일 이상 입원 수술
            if ('입원' in lab0) != (adm == 'in'): return []
            _type = '입원' if adm == 'in' else '통원'
        else:
            typ = (NEWSURG.get('major') or {}).get(cause or '질병', {}).get(code)
            if not typ:
                log('검토필요', r['name'], '%s 신수술분류표[주요수술]에 없는 수술코드 %s — 계산 제외' % (cause or '질병', code)); return []
            want = next((v for k, v in NEWSURG_TYPE_KEY if k in lab0), None)
            if want != typ: return []
            _type = typ
        why = o.get('why', '수술 1회').replace('{code}', code).replace('{type}', _type)
        return [(r['man'], why, o.get('group', '수술비'), o.get('freq', 'each'))]
    elif not j: return []
    if 'cancer' in (o.get('ex') or []) and is_cancer(sc['kcd']): return []
    for g in t['ex']:                                   # 특정N대질병 제외 담보 — N 에 맞는 제외 목록으로(v8.50)
        lst = KCDG.get('특정%s대질병' % g)
        if not lst:
            log('검토필요', r['name'], '특정%s대질병 제외목록이 규칙표에 없음 — 특정5대질병 기준으로 판정' % g); lst = FIVE_MAJOR
        # 대장 용종·양성신생물 내시경 절제(사례 태그 five_major)는 특정5대·6대의 ① 항 — 특정2대에는 없다
        if (g in ('5', '6') and tg.get('five_major')) or code_hit(lst, sc['kcd']): return []
    if not kcd_ok(o.get('kcd'), r, sc, nm, o): return []
    # 관혈/비관혈로 나뉜 담보(5대질환수술비[관혈]·[비관혈], 32대질병관혈수술비) — 한 번의 수술은 둘 중 하나다.
    # 전에는 둘 다 지급되어 뇌·심장 수술마다 1,000만원(비관혈 가입금액)이 더 붙었다(v8.55)
    lab = r['name'].replace(' ', '')
    if '관혈' in lab:
        op = surg_open(tg)
        if op is None:
            log('검토필요', r['name'], '관혈·비관혈 구분이 사례에 없어 계산 제외'); return []
        if op != ('비관혈' not in lab): return []
    _jj = t['gj'] or (surg7_grade(tg.get('surg7')) if o.get('grade') == '1-7' else surg5_grade(j, sc['kcd'])) or ''
    _gl = (r.get('benefit') or r.get('sub') or (re.search(r'[\[(]([^\[\]()]+)[\])]\s*$', r['name']) or [None, ''])[1] or '').strip()
    why = o.get('why', '수술 1회').replace('{j}', str(_jj)).replace('{g}', _gl).strip()   # (v8.63) 1-7종 부모 행 사유에 1-5종 종이 찍히던 것 · 130대[○○] 질병군 이름 빠짐
    freq = 'year' if '연간1회한' in lab else o.get('freq', 'each')     # 약관이 연간 1회로 정한 수술비(v8.55)
    return [(r['man'], why, o.get('group', '수술비'), freq)]

def h_day(r, o, sc, nm, t):
    tg = sc['tags']; mode = o.get('mode', 'day')
    if t['cause'] and tg.get('cause') != t['cause']: return []
    if t.get('ex_hosp') and tg.get('hosp') == t['ex_hosp']: return []
    if not hosp_ok(t['hosp'], tg.get('hosp')): return []
    if t['room'] and tg.get('room') != t['room']: return []
    if o.get('need_surg') and not tg.get('surg'): return []
    if not kcd_ok(o.get('kcd'), r, sc, nm, o): return []
    if mode == 'daycare':                                # 낮병동 입원(급여) 1일당 — 사례 태그 daycare 일수(v8.12)
        n = tg.get('daycare', 0)
        if not n: return []
        n = min(n, t['limit'] or n)
        return [(r['man'] * n, '낮병동 입원 %d일 × %d만원' % (n, r['man']), o.get('group', '입원일당'), 'each')]
    if mode == 'visit':
        n = tg.get('visits', 0)
        if not n: return []
        n = min(n, t['limit'] or n)
        return [(r['man'] * n, '통원 %d회 × %d만원' % (n, r['man']), o.get('group', '통원일당'), 'each')]
    if mode == 'icu' or t['icu']:
        d = tg.get('icu', 0)
        if not d: return []
        return [(r['man'] * d, '중환자실 %d일' % d, o.get('group', '입원일당'), 'each')]
    days = tg.get('days', 0)
    if not days: return []
    if t['minday'] and days < t['minday']: return []
    d = min(days, t['limit'] or days)
    if t['minday'] and t['minday'] > 1: d = max(0, min(days - t['minday'] + 1, t['limit'] or days))
    if not d: return []
    return [(r['man'] * d, '입원 %d일 × %d만원' % (d, r['man']), o.get('group', '입원일당'), 'each')]

_EXAM_KEYS = [(r'내시경', 'x_endo'), (r'MRI', 'x_mri'), (r'(?<![A-Z])CT', 'x_ct'), (r'PET|양전자', 'x_pet'), (r'초음파', 'x_us'),
              (r'생검|조직병리', 'x_bio'), (r'단일유전자', 'x_gene'), (r'NGS', 'x_ngs')]
def _tx_parts(r, o, sc, nm, t):
    """약관 지급금액표가 치료 「구분」마다 지급률을 따로 정한 담보 — 건선특정치료비(v8.88 · rules.json tx_psoriasis opt.parts)
       · 광선치료(hc_listed) : 마스터 수가코드(약관 제4조) 시술을 받고 연간 치료일수(사례 tags.psor_light_days)가 min_days 이상
       · 약물·주사제치료 : 대상 약제 연간 처방일수(tags.psor_drug_days)가 min_drug_days 이상이거나 주사제 처방(tags.psor_inj)이 min_inj 이상
       구분마다 가입금액 × rate% · 각각 연간 1회. 급여 치료만(비급여 단계 제외). 일수를 모르는 사례는 추정하지 않고 지급 제외 + 로그."""
    tg = sc['tags']
    if tg.get('nc'): return []
    if t['cause'] and tg.get('cause') != t['cause']: return []
    if not kcd_ok(o.get('kcd'), r, sc, nm, o): return []
    out = []
    for p in o['parts']:
        if p.get('hc_listed'):
            if not (set(r.get('hc') or []) & set(tg.get('hc') or [])): continue
            d = tg.get('psor_light_days')
            if d is None:
                log('검토필요', r['name'], '%s : 연간 치료일수가 사례에 없어 지급 판정 제외(약관 연간 %d일 이상)' % (p['label'], p.get('min_days', 0))); continue
            if d < p.get('min_days', 0): continue
        else:
            dd, inj = tg.get('psor_drug_days') or 0, tg.get('psor_inj') or 0
            if not ((p.get('min_drug_days') and dd >= p['min_drug_days']) or (p.get('min_inj') and inj >= p['min_inj'])): continue
        out.append((r['man'] * p['rate'] / 100.0, '%s · 가입금액의 %s%% · 연간 1회' % (p['label'], format(p['rate'], 'g')), o.get('group', '치료비'), 'year'))
    return out

def h_tx(r, o, sc, nm, t):
    tg = sc['tags']
    if o.get('parts'): return _tx_parts(r, o, sc, nm, t)
    need = set(o.get('acts') or [])
    if o.get('by_benefit'):                                   # 세부급부명으로 치료행위·암종 결정 (26종 항암방사선및약물치료비 등)
        b = (r.get('benefit') or '')
        if not b: log('검토필요', r['name'], '세부급부(암종·치료)가 없는 부모 담보 — 계산 제외'); return []
        need = {'rad'} if '방사선' in b else ({'chemo'} if '약물' in b else need)
        inner = re.search(r'치료비\((.+)\)$', b)
        raw = inner.group(1) if inner else b
        codes = c13_codes(raw)                                    # 약관 별표 「암종별(13종)」 분류표 우선(v8.8)
        if not codes:                                             # 표에 없는 암종명은 기존 코드 사전으로 보조 판정
            kinds = re.split(r'과|및|,|·', re.sub(r'\(전이포함\)', '', raw))
            codes = [c for k in kinds for kk, cs in SYN.items() if kk == k.strip() for c in cs]
        if not codes:
            log('KCD없음', r['name'], f'세부급부 암종 "{raw}"이 약관 별표 「암종별(13종)」 분류표·코드 사전에 없어 계산 제외'); return []
        if not code_hit(codes, sc['kcd']): return []
    # 약관 별표 1-7종 수술분류표의 **수술구분**으로 가리는 담보(예 '뇌동맥류수술' = B011~B018).
    # 담보명·설명문에서 질병코드를 만들지 않고, 사례 단계에 적힌 수술코드가 그 구분에 드는지만 본다(v8.39).
    if o.get('surg7_grp') and surg7_group(tg.get('surg7')) != o['surg7_grp']: return []
    # 같은 규칙 안에서도 약관이 대상 범위를 적는 방식이 다르다(v8.53).
    #   「암 내시경검사」  = 급여 제2부 제2장 제4절 내시경 **구간 전체** → 치료행위 키만 봐도 같다
    #   「암 특정생검조직병리검사Ⅱ」·「암 특정단일유전자검사」 = 제4조가 **진료행위코드를 낱낱이 열거**
    #        (침생검(심부) C8511~C8514 등) → 목록에 없는 검사(내시경 겸자생검·림프절·피부 생검)는 대상이 아니다
    # 그래서 마스터에 수가코드 목록이 실린 담보만 그 목록과 대조한다. 목록이 없는 담보는 종전대로.
    if o.get('hc_listed') and (r.get('hc') or []):
        if not (set(r['hc']) & set(tg.get('hc') or [])): return []
    # 검사비 : 담보명이 검사 종류를 정했으면 그 검사를 받은 단계에서만(v8.63). 전에는 암 검사 8종·일반 검사 7종이 행위 키를
    # 함께 써서 CT 만 받은 단계에 MRI 검사비·PET 검사비가, MRI 만 받은 단계에 내시경 검사비가 붙었다.
    # 방사선·약물을 한 규칙으로 보는 담보(tx_chemo_rad)의 세부보장이 한쪽만 정했으면 그 치료만(v8.63) — 또128·또간92
    # 통합항암방사선약물치료비[항암방사선치료비(…)] 가 약물치료 단계에, [항암약물치료비(…)] 가 방사선 단계에도 붙었다.
    if o.get('split_by_label'):
        lab = re.sub(r'\s', '', (r.get('benefit') or r.get('sub') or '') or (re.search(r'\[([^\[\]]+)\]$', nm) or [None, ''])[1])
        if re.search(r'항암방사선치료비?', lab): need = {'rad'}       # 정보계 · 설계서 라벨은 「(급여, 항암방사선치료, 암(유사암제외))」처럼 「치료」로 끝난다(v8.89)
        elif re.search(r'항암약물치료비?', lab): need = {'chemo'}
    if o.get('exam_by_name'):
        ek = {k for pat, k in _EXAM_KEYS if re.search(pat, nm)}
        if ek: need = ek
    if need and not (need & _acts(sc)): return []
    if o.get('not_acts') and set(o['not_acts']) & set(_acts(sc)): return []   # 서로 배타적인 세부보장(특정표적 ↔ 특정면역)(v8.63)
    allneed = set(o.get('acts_all') or [])          # 둘 다 받아야 지급되는 담보(예: 혈전용해 + 기계적혈전제거술)
    if allneed and not allneed <= _acts(sc, True): return []
    if o.get('need_cnt') and tg.get('tx_cnt', 0) < o['need_cnt']: return []
    if o.get('circ_cnt'):                           # 특정순환계질환 통합치료 생활비 — 약관 제2조③ 「연간 특정순환계질환 통합치료횟수」(v8.75)
        m = re.search(r'(\d)회이상', re.sub(r'\s', '', nm + (r.get('benefit') or '') + (r.get('sub') or '')))
        if not m: log('검토필요', r['name'], '담보명에 「N회이상」이 없어 연간 통합치료횟수 기준을 알 수 없음 — 계산 제외'); return []
        ev = sc.get('itc_events') or []
        n = (1 if 'thromb' in _acts(sc, True) else 0)                                                       # 혈전용해치료 연간 1회한
        n += sum(1 for e in ev if len(e) > 3 and 'surg' in e[3]) or (1 if tg.get('surg') else 0)             # 수술 1회당
        n += 1 if (tg.get('icu') or 0) >= 4 and hosp_ok('종합', tg.get('hosp')) else 0                       # 종합병원 중환자실 4일이상 연간 1회한
        if o['circ_cnt'] == 'II':                       # 특정순환계질환 통합치료비Ⅱ(연간 주요치료Ⅱ N회이상) — 주요치료Ⅱ 7항목 : 위 셋 + CRRT · 인공호흡기(12시간초과) · 저체온요법 · 부분체외순환(각 연간 1회) (개정안 2026-10-31 별첨7 §5)
            n += sum(1 for k in ('crrt', 'vent', 'hypo', 'ecmo') if k in _acts(sc, True))
        if n < int(m.group(1)): return []
    nd = o.get('need_drug')
    m2 = re.search(r'[\[(](\d)종(?:및\d종)?이상', nm)                       # [1종이상]·(2종및3종이상) 담보명 표기 우선
    if m2: nd = int(m2.group(1))
    if nd and tg.get('drug', 0) < nd: return []                                 # 연간 약물종류 개수 조건
    _hc_step = bool(o.get('hc_listed') and set(r.get('hc') or []) & set(tg.get('hc') or []))   # 약관 수가코드 시술을 받은 단계(v8.63)
    if not need and not tg.get('dx') and o.get('kcd') != 'hc' and not _hc_step: return []     # 수가코드 담보는 진단 단계가 아니어도 해당 시술이 있으면 지급(v8.14)
    # 비급여(전액본인부담) 전용 담보는 그 치료의 비용이 비급여일 때만 지급한다(약관 '비급여(전액본인부담 포함)
    # ○○치료의 정의' — 진료비 세부내역서의 해당 비용이 비급여·전액본인부담인 경우). 급여 치료 예시에는 넣지 않는다.
    if re.search(r'비급여|전액본인부담', nm) and not tg.get('nc'): return []
    # 급여 항암치료비(담보명 '(급여')는 비급여 치료 단계(양성자·중입자·비급여 표적·면역)에서는 지급하지 않는다 — 약관 제4조 급여 정의(v8.63)
    if o.get('covered_only') and re.search(r'\(급여', nm) and not re.search(r'비급여', nm) and tg.get('nc'): return []
    if t['cause'] and tg.get('cause') != t['cause']: return []
    if not hosp_ok(t['hosp'], tg.get('hosp')): return []
    # 담보명·세부급부 라벨이 암 구분을 못박은 담보는 그 구분의 암에만(v8.61) — 유사암 전용 / 유사암제외 / 갑상선암 / 기타피부암
    if not cancer_scope_ok(nm, sc['kcd']) or not cancer_scope_ok(r.get('sub') or r.get('benefit') or '', sc['kcd']): return []
    if not kcd_ok(o.get('kcd'), r, sc, nm, o): return []
    freq = o.get('freq', 'year')
    if '계속받는' in nm or '연간1회한' in nm: freq = 'year'
    elif '최초1회한' in nm: freq = 'once'
    # 「(2종및3종이상)」 세부보장은 2종이상·3종이상 두 구분을 각각 연간 1회 지급(통240·케298 제3조③ · 약관 예시 3종 → 가입금액 2배)(v8.63)
    if re.search(r'2종및3종이상', nm) and tg.get('drug', 0) >= 3:
        return [(r['man'], '연간 약물종류 2종이상 구분', o.get('group', '치료비'), freq), (r['man'], '연간 약물종류 3종이상 구분', o.get('group', '치료비'), freq)]
    why = o.get('why', '약관 대상 치료')
    if freq == 'year' and o.get('freq') == 'once': why = why.replace('최초 1회', '연간 1회')
    elif freq == 'once' and o.get('freq', 'year') == 'year': why = why.replace('연간 1회', '최초 1회').replace('연 1회', '최초 1회')
    # 「계속받는」 연간형이 두번째 해부터 지급률을 낮추는 담보(계속받는 표적항암약물허가치료비Ⅲ : 첫번째 100% · 두번째 이후 10% — 통185 · 케337 제2조①②)
    # 첫 지급 줄은 가입금액 그대로, 「반복(연 1회)」 집계에는 repeat(가입금액 × 지급률)를 쓴다(v8.89)
    if freq == 'year' and o.get('repeat_rate') is not None and '계속받는' in nm:
        rr = o['repeat_rate']
        return [(r['man'], '%s · 첫번째 100%% · 두번째 해부터 가입금액의 %s%%' % (why, format(rr, 'g')), o.get('group', '치료비'), freq, {'repeat': r['man'] * rr / 100.0})]
    return [(r['man'], why, o.get('group', '치료비'), freq)]

def h_point2(r, o, sc, nm, t):
    """최대두배받는2대질환치료비(포인트적립형) — 통106·케179 제2조·제5조(v8.65)
    사례에서 받은 2대질환치료로 2대질환치료포인트를 매기고, 담보명의 점수 구간(1·2·3·4점이상)에 이르면
    그 구간의 지급률(약관 제2조 표 · rules.json opt.rate, 계약일부터 1년 경과 후 기준)만큼 최초 1회 지급.
      · 치료군(뇌혈관질환치료 / 허혈성심장질환치료 / 중환자실입원)별로 가장 높은 1회만 · 군별 점수를 합산(제5조 ①②)
      · 뇌·심장 치료군 : 비관혈수술·혈전용해치료 1점, 관혈수술 2점 — 관혈 여부는 surg_open(사례 1-5종 항목)
      · 중환자실입원 : 1회 입원 4일 이상 1점, 8일 이상 2점(제3조 ①) — 사례 tags.icu(일수)
    KCD 는 특약 마스터 codes(약관 별표 2대질환)만 본다. 관혈·비관혈을 모르는 수술은 점수에서 빼고 로그."""
    tg = sc['tags']
    if not kcd_ok('codes', r, sc, nm, o): return []
    m = re.search(r'(\d)점이상', (r.get('benefit') or '') + nm)
    if not m:
        log('검토필요', r['name'], '점수 구간(1~4점이상)이 담보명에 없어 계산 제외'); return []
    k = int(m.group(1)); rate = (o.get('rate') or {}).get(str(k))
    if rate is None:
        log('검토필요', r['name'], '%d점이상 지급률이 규칙표에 없어 계산 제외' % k); return []
    a = _acts(sc); dz = 0
    if 'thromb' in a: dz = 1
    if 'surg' in a:
        op = surg_open(tg)
        if op is None: log('검토필요', r['name'], '관혈·비관혈 구분이 사례에 없어 수술 점수 제외')
        else: dz = max(dz, 2 if op else 1)
    d = tg.get('icu', 0) or 0
    ic = 2 if d >= 8 else (1 if d >= 4 else 0)
    pts = min(4, dz + ic)
    if pts < k: return []
    amt = r['man'] * rate / 100.0
    why = '2대질환치료포인트 %d점(치료 %d점 + 중환자실 %d점) → %d점이상 구간 · 가입금액의 %s%% · 최초 1회' % (pts, dz, ic, k, format(rate, 'g'))
    return [(amt, why, o.get('group', '치료비'), 'once')]

HANDLER = {'dx': h_dx, 'surg': h_surg, 'day': h_day, 'tx': h_tx, 'point2': h_point2}

# ══ 진입점 ═════════════════════════════════════════════════════════
def pay_lines(riders, sc):
    """riders : 설계 담보 목록(dict : name, man, cat, codes, benefit, sub, itc)
       sc     : {'kcd','tags',...}  →  [{'name','amt','why','group','no','freq'}]"""
    out = []
    sc.setdefault('itc_events', [])
    # 사례 단계가 비급여(전액본인부담)인지 태그로 옮긴다 — 지금까지는 통합치료비 엔진만 이 표시를 보고
    # 일반 치료비 담보는 못 봐서, '비급여 암 주요치료비'가 급여 치료 예시에도 더해지고 있었다(v8.27)
    if any((e[4] or {}).get('nc') for e in sc['itc_events'] if len(e) > 4):
        sc['tags'] = dict(sc['tags']); sc['tags']['nc'] = 1
    for r in riders:
        try:
            if (r.get('man') or 0) <= 0: continue
            n = r['name']; nm = nname(n)
            # 설계서 · 정보계가 세부보장을 둥근 괄호로 적은 담보(「통합항암방사선약물치료비(최대8회한)(급여, 항암방사선치료, 암(유사암제외))」)는
            # 매칭된 마스터 세부보장 레코드의 이름(「…[항암방사선치료비(급여,암(유사암제외))]」)으로 규칙을 판정한다 — 둥근 괄호면 규칙표가
            # 세부보장을 못 읽어 특약 전체(부모 규칙)로 계산해 다른 칸에도 금액이 들어갔다(통합항암방사선약물치료비 · 표적항암약물허가치료비Ⅲ · 통합전이암진단비)(v8.89)
            if r.get('mname') and '[' in r['mname'] and '[' not in nm: nm = nname(r['mname'])
            if excluded(r, sc['kcd']): continue         # 약관 제외코드(보상하지 않는 질병)에 해당 — 지급 없음(v8.7)
            # 1) 통합치료비 — 약관 지급금액표 엔진에 위임
            if r.get('itc'):
                if not sc.get('itc_events'): continue
                # 담보명이 원인을 못박은 통합치료비(질병 통합치료비·상해 통합치료비)는 그 원인일 때만(v8.27)
                _t = tokens(nm); _c = _t['cause']
                if _c and sc['tags'].get('cause') != _c: continue
                # 담보명이 병원 종별을 못박은 통합치료비(상급종합병원,권역심뇌혈관질환센터 특정순환계질환 통합치료비 · 암중점치료기관형)는
                # 그 종별 이상에서 받은 치료만(통110 제1조①~③)(v8.63). 전에는 병원급 사례에도 금액표 전액이 붙었다.
                if _t['hosp'] and not hosp_ok(_t['hosp'], sc['tags'].get('hosp')): continue
                evs = []
                for e in sc['itc_events']:
                    # 사례 단계에 1-5종 표시(j)가 없는 수술은 사례의 1-5종 분류표 항목(tags.surg)으로 종을 정한다(v8.63) —
                    # 질병 통합치료비·암전후 통합치료비의 「수술(1-5종)」 항목이 j 가 없어 0 이던 것(개두술·관상동맥우회술·암 개복수술 등)
                    if len(e) > 3 and 'surg' in (e[3] or []) and not ((e[4] if len(e) > 4 else None) or {}).get('j'):
                        _j = surg5_grade(sc['tags'].get('surg'), sc['kcd'])
                        if isinstance(_j, int):
                            e = list(e[:4]) + [dict((e[4] if len(e) > 4 else None) or {}, j=_j)]
                    evs.append(e)
                # 6시간 이상 전신마취 단계(anes_h ≥ 6)면 「종합병원 전신마취치료(6시간이상)(급여)」 항목도 받은 것으로 본다(v8.61)
                if ('anes6' in _acts(sc) and hosp_ok('종합', sc['tags'].get('hosp'))       # 「종합병원」 항목 — 병원·의원 전신마취는 대상 아님
                        and not any(len(e) > 3 and 'anes6' in (e[3] or []) for e in evs)):
                    evs.append(['치료', '전신마취(6시간이상)', '', ['anes6']])
                # 항목 한정 면책 — 질병 통합치료비(통139·케233 제16조③)·암전후 통합치료비(케N397 제22조②③)는 아래 질병 치료의
                # 전신마취(6시간이상) 항목만 지급하지 않는다. 특약 전체 제외가 아니므로 그 항목만 0 으로 두고 로그를 남긴다.
                xk = {k for k, g in ITC_ITEM_X.get(r['itc'], {}).items() if code_hit(KCDG.get(g) or [], sc['kcd'])}
                if xk and any(len(e) > 3 and set(e[3] or []) & xk for e in evs):
                    log('면책', n, '약관 항목 한정 면책 질병(%s) — 전신마취치료(6시간이상) 항목 제외' % sc['kcd'])
                # 「종합병원 중환자실치료」 항목은 종합병원 이상에서만(통109 제4조⑥ 등 · 병원·의원 중환자실은 대상 아님)(v8.63)
                # 사유를 면책과 따로 남긴다 — 전에는 병원급 사례에서 이 항목을 뺄 때도 「전신마취 면책」 문구가 찍혔다
                if not hosp_ok('종합', sc['tags'].get('hosp')):
                    if (itc.cover(itc.RM[r['itc']], sc['kcd']) != 'no' and any(it['k'] == 'icu' for it in itc.IT[itc.RM[r['itc']]['ty']])
                            and any(len(e) > 3 and 'icu' in (e[3] or []) for e in evs)):
                        log('병원종별', n, '「종합병원 중환자실치료」 항목은 종합병원 이상에서만 지급 — 사례 병원(%s)이라 0' % (sc['tags'].get('hosp') or '미지정'))
                    xk = xk | {'icu'}
                try:
                    res = itc.calc_rider(r['itc'], r['man'], sc['kcd'], {'e': evs}, sc.get('within1y', False), skip_keys=xk)
                except KeyError:
                    log('금액표없음', n, '가입금액 %s만원이 약관 지급금액표에 없어 계산 제외 (설계 금액 확인 필요)' % r['man'])
                    continue
                for l in res['lines']:                    # 약관 수가코드 목록 밖의 검사 → 0원 + 사유(v8.61)
                    if l.get('why') == 'def':
                        log('수가코드제외', n, '%s 0원 — %s' % (itc.item_label(r['itc'], l['i']),
                            l.get('nor') or '약관이 정한 수가코드에 해당하지 않음'))
                if res['total'] > 0:
                    det = ' · '.join('%s %s' % (itc.item_label(r['itc'], l['i']), format(l['amt'], ',.0f'))
                                     for l in res['lines'] if l['amt'] > 0)
                    ea = sum(l['amt'] for l in res['lines'] if l['amt'] > 0
                             and itc.IT[itc.RM[r['itc']]['ty']][l['i']]['p'] == 'o')
                    out.append({'name': n, 'amt': res['total'], 'why': det + ('  (연간 한도 적용)' if res['capped'] else ''),
                                'group': '통합치료비', 'no': r.get('no'), 'freq': 'year',
                                'each': min(ea, res['cap']), 'rule': 'itc', 'itc': r['itc']})
                continue
            # 2) 통합생활지원비 — 산정특례 등록·치료 항목마다 월 단위 지급(가입금액 = 월간 한도)
            if ls_id(n):
                lines, capped = ls_lines(r, sc)
                if lines:
                    _sp = sum(a for _l, a, g in lines if g == '산정특례')
                    out.append({'name': n, 'amt': sum(a for _l, a, _g in lines), 'group': '통합생활지원비',
                                'why': ' · '.join('%s %s' % (l, format(a, ',.0f')) for l, a, _g in lines)
                                       + ('  (월간 한도 적용)' if capped else ''),
                                'no': r.get('no'), 'freq': 'year', 'rule': 'ls_monthly',
                                # 산정특례는 '등록당' 지급 — 한 사례에서 두 단계에 걸쳐 세지 않도록 따로 싣는다
                                'sp': _sp, 'ls_rest': [(l, a) for l, a, g in lines if g != '산정특례']})
                continue
            # 3) 규칙표 판정
            rule = classify(nm)                          # nm = 세부보장 둥근 괄호 표기는 마스터 이름으로 바꾼 것(v8.89)
            if rule is None:
                log('미분류', n, '규칙표에 해당 담보 유형이 없어 계산 제외 (rules.json 보강 필요)')
                continue
            if rule['kind'] == 'itc_unknown':            # 금액표 미연동 통합치료비 — 정액 치료비로 오계산되지 않게 제외(v8.3)
                if nm not in INJ_KNOWN and noren(nm) not in INJ_KNOWN:
                    log('금액표없음', n, '약관 지급금액표(product_data.json RIDERS)에 없는 통합치료비 — 계산 제외 (금액표 보강 필요)')
                continue
            if rule['kind'] == 'skip' and (rule.get('opt') or {}).get('log'):
                log('조건부', n, rule['opt']['log']); continue   # 병기·상태 조건이 붙어 사례로 단정할 수 없는 담보(v8.21)
            h = HANDLER.get(rule['kind'])
            if h is None: continue                       # care·life·nonmed·skip = 사례 계산 대상 아님
            for item in h(r, rule.get('opt') or {}, sc, nm, tokens(nm)):
                amt, why, grp, freq = item[:4]; extra = item[4] if len(item) > 4 else {}   # 5번째 : 줄에 덧붙일 값(repeat = 두번째 해부터의 연간 금액)(v8.89)
                if amt > 0:
                    if r.get('matched') is False:        # 설계서 담보가 특약 마스터에 없는데(설계 상품 약관이 데이터에 없음) 규칙표로 지급 계산됨 — 근거를 남긴다(v8.61)
                        log('마스터없음', n, '특약 마스터(약관 데이터 : %s)에 없는 담보인데 규칙표 %s 로 계산됨 — 근거 : %s. 해당 상품 약관으로 확인 필요'
                            % ('·'.join(DB_PRODUCTS) or 'db.json', rule['id'], ((rule.get('opt') or {}).get('note') or rule.get('label') or '-').rstrip('. ')))
                    out.append(dict({'name': n, 'amt': amt, 'why': why, 'group': grp, 'no': r.get('no'),
                                     'freq': freq, 'rule': rule['id']}, **extra))
        except Exception as ex:                          # 어떤 담보가 와도 생성이 중단되지 않게 한다
            log('오류', r.get('name', '?'), '%s: %s' % (type(ex).__name__, ex))
    return out

def total(lines): return sum(l['amt'] for l in lines)
def total_by(lines, mode):
    """mode: 'first' 최초 지급 / 'year' 반복(연간 1회) / 'each' 수술할 때마다"""
    s = 0
    for l in lines:
        if mode == 'first': s += l['amt']
        elif mode == 'year': s += l.get('repeat', l['amt']) if l.get('freq') != 'once' else 0   # repeat = 두번째 해부터의 연간 금액(v8.89)
        else: s += l.get('each', l['amt'] if l.get('freq') == 'each' else 0)
    return s

def audit(riders):
    """설계 담보 전체를 규칙표에 대조한 결과 — 인계·운영 점검용"""
    by, un = {}, []
    for r in riders:
        if r.get('itc'):
            by['itc'] = by.get('itc', 0) + 1; continue
        rule = classify(r['name'])
        if rule is None:
            un.append(r['name']); by['미분류'] = by.get('미분류', 0) + 1
        else:
            by[rule['kind']] = by.get(rule['kind'], 0) + 1
    return {'담보수': len(riders), '구조별': by, '미분류': un, '규칙수': len(RULES), '인식': recog(riders)}
